/*========================================================*/
/**
 * @file   fill.h
 * @author Joel FALCOU
 * @date   Tue July 14 13:23:13 2002
 * 
 * @brief  en-tete de fill.c
 * 
 * Ce fichier contient le code des differentes versions
 * de l'op�ration de remplissage de tableaux.
 *
 */
/*========================================================*/

#ifndef __FILL_H__INCLUDED__
#define __FILL_H__INCLUDED__

void AVfillu8( CAMLG4_ARGUMENTS* arg );
void AVfills8( CAMLG4_ARGUMENTS* arg );
void AVfillu16( CAMLG4_ARGUMENTS* arg );
void AVfills16( CAMLG4_ARGUMENTS* arg );
void AVfills32( CAMLG4_ARGUMENTS* arg );
void AVfillf32( CAMLG4_ARGUMENTS* arg );

#endif
