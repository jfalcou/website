/*========================================================*/
/**
 * @file   mulv.h
 * @author Joel FALCOU
 * @date   Tue May 14 13:33:30 2002
 * 
 * @brief  En-tete de mulv.c
 * 
 * Ce fichier definit les fonctions de multiplication
 * vecteur-vecteur implementees dans sub.c
 *
 */
/*========================================================*/

#ifndef __MULV_H__INCLUDED__
#define __MULV_H__INCLUDED__

void  AVmulvu8  ( CAMLG4_ARGUMENTS* arg );
void  AVmulvs8  ( CAMLG4_ARGUMENTS* arg );
void  AVmulvu16 ( CAMLG4_ARGUMENTS* arg );
void  AVmulvs16 ( CAMLG4_ARGUMENTS* arg );
void  AVmulvs32 ( CAMLG4_ARGUMENTS* arg );
void  AVmulvf32 ( CAMLG4_ARGUMENTS* arg );

#endif
