/*========================================================*/
/**
 * @file   mask_even.c
 * @author Joel FALCOU
 * @date   Tue May 14 13:37:13 2002
 * 
 * @brief  Source de mask_even.h
 * 
 * Ce fichier contient le code des differentes versions
 * du masquage vectoriel.
 *
 */
/*========================================================*/

#include <stdio.h>
#include <stdlib.h>

#include "camlg4_internal.h"
#include "altivec_common.h"
#include "mask_even.h"

void  AVmask_evenu8  ( CAMLG4_ARGUMENTS* arg )
{
  long nb_iter, i, j;
  register vector unsigned char val;
  unsigned char v;
  register long n,m;

  v = *((int*)(arg->vector3));
  val = generic_splat_u8(&v);

  n = *((int*)arg->vector2);
  m = 1 + ((arg->size)/n);

  EVAL_VECTOR_SIZE( unsigned char );

  for( i = 0; i < nb_iter; ++i )
  {
    RESULTAT( arg->result, i, 0, unsigned char ) = val;
    RESULTAT( arg->result, i, 1, unsigned char ) = val;   
    RESULTAT( arg->result, i, 2, unsigned char ) = val;
    RESULTAT( arg->result, i, 3, unsigned char ) = val;     
  }
  
  for( j = 0; j < m; j++ )
  {
    *(((unsigned char*)arg->result+j*n+n-1)) = *((unsigned char*)arg->vector1+j*n+n-1);
  }
}

void  AVmask_evens8  ( CAMLG4_ARGUMENTS* arg )
{
  long nb_iter, i, j;
  register vector signed char val;
  signed char v;
  register long n,m;

  v = *((int*)(arg->vector3));
  val = generic_splat_s8(&v);

  n = *((int*)arg->vector2);
  printf("debug : n = %d\tp = %d\n", n, v);
  fflush(stdout);

  m = 1 + ((arg->size)/n);

  EVAL_VECTOR_SIZE( signed char );

  for( i = 0; i < nb_iter; ++i )
  {
    RESULTAT( arg->result, i, 0, signed char ) = val;
    RESULTAT( arg->result, i, 1, signed char ) = val;   
    RESULTAT( arg->result, i, 2, signed char ) = val;
    RESULTAT( arg->result, i, 3, signed char ) = val;     
  }
  
  for( j = 0; j < m; j++ )
  {
    *(((signed char*)arg->result+j*n)) = *((signed char*)arg->vector1+j*n);
  }
}

void  AVmask_evenu16 ( CAMLG4_ARGUMENTS* arg )
{
  long nb_iter, i, j;
  register vector unsigned short val;
  unsigned short v;
  register long n,m;

  v = *((int*)(arg->vector3));
  val = generic_splat_u16(&v);

  n = *((int*)arg->vector2);
  printf("debug : n = %d\tp = %d\n", n, v);
  fflush(stdout);

  m = 1 + ((arg->size)/n);

  EVAL_VECTOR_SIZE( unsigned short );

  for( i = 0; i < nb_iter; ++i )
  {
    RESULTAT( arg->result, i, 0, unsigned short ) = val;
    RESULTAT( arg->result, i, 1, unsigned short ) = val;   
    RESULTAT( arg->result, i, 2, unsigned short ) = val;
    RESULTAT( arg->result, i, 3, unsigned short ) = val;     
  }
  
  for( j = 0; j < m; j++ )
  {
    *(((unsigned short*)arg->result+j*n)) = *((unsigned short*)arg->vector1+j*n);
  }
}

void  AVmask_evens16 ( CAMLG4_ARGUMENTS* arg )
{
  long nb_iter, i, j;
  register vector signed short val;
  signed short v;
  register long n,m;

  v = *((int*)(arg->vector3));
  val = generic_splat_s16(&v);

  n = *((int*)arg->vector2);
  printf("debug : n = %d\tp = %d\n", n, v);
  fflush(stdout);

  m = 1 + ((arg->size)/n);

  EVAL_VECTOR_SIZE( signed short );

  for( i = 0; i < nb_iter; ++i )
  {
    RESULTAT( arg->result, i, 0, signed short ) = val;
    RESULTAT( arg->result, i, 1, signed short ) = val;   
    RESULTAT( arg->result, i, 2, signed short ) = val;
    RESULTAT( arg->result, i, 3, signed short ) = val;     
  }
  
  for( j = 0; j < m; j++ )
  {
    *(((signed short*)arg->result+j*n)) = *((signed short*)arg->vector1+j*n);
  }
}

void  AVmask_evens32 ( CAMLG4_ARGUMENTS* arg )
{
  long nb_iter, i, j;
  register vector signed long val;
  signed long v;
  register long n,m;

  v = *((int*)(arg->vector3));
  val = generic_splat_s32(&v);

  n = *((int*)arg->vector2);
  printf("debug : n = %d\tp = %d\n", n, v);
  fflush(stdout);

  m = 1 + ((arg->size)/n);

  EVAL_VECTOR_SIZE( signed long );

  for( i = 0; i < nb_iter; ++i )
  {
    RESULTAT( arg->result, i, 0, signed long ) = val;
    RESULTAT( arg->result, i, 1, signed long ) = val;   
    RESULTAT( arg->result, i, 2, signed long ) = val;
    RESULTAT( arg->result, i, 3, signed long ) = val;     
  }
  
  for( j = 0; j < m; j++ )
  {
    *(((signed long*)arg->result+j*n)) = *((signed long*)arg->vector1+j*n);
  }
}

void  AVmask_evenf32 ( CAMLG4_ARGUMENTS* arg )
{
  long nb_iter, i, j;
  register vector float val;
  float v;
  register long n,m;

  v = *((float*)(arg->vector3));
  val = generic_splat_f32(&v);

  n = *((int*)arg->vector2);
  printf("debug : n = %d\tp = %d\n", n, v);
  fflush(stdout);

  m = 1 + ((arg->size)/n);

  EVAL_VECTOR_SIZE( float );

  for( i = 0; i < nb_iter; ++i )
  {
    RESULTAT( arg->result, i, 0, float ) = val;
    RESULTAT( arg->result, i, 1, float ) = val;   
    RESULTAT( arg->result, i, 2, float ) = val;
    RESULTAT( arg->result, i, 3, float ) = val;     
  }
  
  for( j = 0; j < m; j++ )
  {
    *(((float*)arg->result+j*n)) = *((float*)arg->vector1+j*n);
  }
}
