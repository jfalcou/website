/*
  Exercice 2 - Fonction d'ordre supérieur

  Q1 - Implémentez un template de fonction 'compose' permettant de construire
  la composition de deux fonctions arbitraires à un paramètre.

  Q2 - Implémentez un template de fonction 'set1st' permettant de construire
  à partir d'une fonction à deux paramètres, une fonction à seul parametres
  en figeant la valeur du premier parametre de la fonction initiale à 0.
  Ainsi set1st(f)(x)  est equivalent à f(0,x).

  Q3 - Implémentez un template de fonction 'set2nd' permettant de construire
  à partir d'une fonction à deux paramètres, une fonction à seul parametres
  en figeant la valeur du deuxieme parametre de la fonction initiale à 0.
  Ainsi set2nd(f)(x)  est equivalent à f(x,0).

  Q4 - Modifiez set1st et set2nd pour permettre de choisir la valeur du
  paramètre figé. Ainsi set1st(f, 8)(x) est equivalent à f(8,x)

*/

#include <iostream>

int main(int, char **) {}
