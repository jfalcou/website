/*========================================================*/
/**
 * @file   mulv.c
 * @author Joel FALCOU
 * @date   Tue May 14 13:37:13 2002
 * 
 * @brief  Source de mulv.h
 * 
 * Ce fichier contient le code des differentes versions
 * de la multiplication vecteur-vecteur.
 *
 */
/*========================================================*/

#include <stdio.h>
#include <stdlib.h>

#include "camlg4_internal.h"
#include "altivec_common.h"
#include "mulv.h"

void  AVmulvu8  ( CAMLG4_ARGUMENTS* arg )
{
  long  nb_iter, i;
  register vector unsigned short  tampon1h_1, tampon1l_1;
  register vector unsigned char   tampon1_1 , tampon1_2 , tampon1_3 , tampon1_4;
  register vector unsigned char   tampon2_1 , tampon2_2 , tampon2_3 , tampon2_4;
  register vector unsigned char   tampon_1 , tampon_2;

  EVAL_VECTOR_SIZE( unsigned char );

  for( i = 0; i < nb_iter; ++i )
  {      
    LOAD_REGISTER( tampon1_1, i, 0, unsigned char, arg->vector1 );
    LOAD_REGISTER( tampon1_2, i, 1, unsigned char, arg->vector1 );
    LOAD_REGISTER( tampon1_3, i, 2, unsigned char, arg->vector1 );
    LOAD_REGISTER( tampon1_4, i, 3, unsigned char, arg->vector1 );
    
    LOAD_REGISTER( tampon2_1, i, 0, unsigned char, arg->vector2 );
    LOAD_REGISTER( tampon2_2, i, 1, unsigned char, arg->vector2 );
    LOAD_REGISTER( tampon2_3, i, 2, unsigned char, arg->vector2 );
    LOAD_REGISTER( tampon2_4, i, 3, unsigned char, arg->vector2 );
    
    tampon1h_1 = vec_mule( tampon1_1, tampon2_1 );
    tampon1l_1 = vec_mulo( tampon1_1, tampon2_1 );
    tampon_1   = vec_pack( tampon1h_1, tampon1h_1);
    tampon_2   = vec_pack( tampon1l_1, tampon1l_1);
    RESULTAT( arg->result, i, 0, unsigned char ) = (vector unsigned char)vec_mergel( tampon_1, tampon_2 );

    tampon1h_1 = vec_mule( tampon1_2, tampon2_2 );
    tampon1l_1 = vec_mulo( tampon1_2, tampon2_2 );
    tampon_1  = vec_pack( tampon1h_1, tampon1h_1);
    tampon_2  = vec_pack( tampon1l_1, tampon1l_1);
    RESULTAT( arg->result, i, 1, unsigned char ) = (vector unsigned char)vec_mergel( tampon_1, tampon_2 );

    tampon1h_1 = vec_mule( tampon1_3, tampon2_3 );
    tampon1l_1 = vec_mulo( tampon1_3, tampon2_3 );
    tampon_1  = vec_pack( tampon1h_1, tampon1h_1);
    tampon_2  = vec_pack( tampon1l_1, tampon1l_1);
    RESULTAT( arg->result, i, 2, unsigned char ) = (vector unsigned char)vec_mergel( tampon_1, tampon_2 );

    tampon1h_1 = vec_mule( tampon1_4, tampon2_4 );
    tampon1l_1 = vec_mulo( tampon1_4, tampon2_4 );
    tampon_1  = vec_pack( tampon1h_1, tampon1h_1);
    tampon_2  = vec_pack( tampon1l_1, tampon1l_1);
    RESULTAT( arg->result, i, 3, unsigned char ) = (vector unsigned char)vec_mergel( tampon_1, tampon_2 );
  } 
}

void  AVmulvs8  ( CAMLG4_ARGUMENTS* arg )
{
  long  nb_iter, i;
  register vector signed short  tampon1h_1, tampon1l_1;
  register vector signed char   tampon1_1 , tampon1_2 , tampon1_3 , tampon1_4;
  register vector signed char   tampon2_1 , tampon2_2 , tampon2_3 , tampon2_4;
  register vector signed char   tampon_1 , tampon_2;

  EVAL_VECTOR_SIZE( signed char );

  for( i = 0; i < nb_iter; ++i )
  {      
    LOAD_REGISTER( tampon1_1, i, 0, signed char, arg->vector1 );
    LOAD_REGISTER( tampon1_2, i, 1, signed char, arg->vector1 );
    LOAD_REGISTER( tampon1_3, i, 2, signed char, arg->vector1 );
    LOAD_REGISTER( tampon1_4, i, 3, signed char, arg->vector1 );
    
    LOAD_REGISTER( tampon2_1, i, 0, signed char, arg->vector2 );
    LOAD_REGISTER( tampon2_2, i, 1, signed char, arg->vector2 );
    LOAD_REGISTER( tampon2_3, i, 2, signed char, arg->vector2 );
    LOAD_REGISTER( tampon2_4, i, 3, signed char, arg->vector2 );
    
    tampon1h_1 = vec_mule( tampon1_1, tampon2_1 );
    tampon1l_1 = vec_mulo( tampon1_1, tampon2_1 );
    tampon_1   = vec_pack( tampon1h_1, tampon1h_1);
    tampon_2   = vec_pack( tampon1l_1, tampon1l_1);
    RESULTAT( arg->result, i, 0, signed char ) = (vector signed char)vec_mergel( tampon_1, tampon_2 );

    tampon1h_1 = vec_mule( tampon1_2, tampon2_2 );
    tampon1l_1 = vec_mulo( tampon1_2, tampon2_2 );
    tampon_1  = vec_pack( tampon1h_1, tampon1h_1);
    tampon_2  = vec_pack( tampon1l_1, tampon1l_1);
    RESULTAT( arg->result, i, 1, signed char ) = (vector signed char)vec_mergel( tampon_1, tampon_2 );

    tampon1h_1 = vec_mule( tampon1_3, tampon2_3 );
    tampon1l_1 = vec_mulo( tampon1_3, tampon2_3 );
    tampon_1  = vec_pack( tampon1h_1, tampon1h_1);
    tampon_2  = vec_pack( tampon1l_1, tampon1l_1);
    RESULTAT( arg->result, i, 2, signed char ) = (vector signed char)vec_mergel( tampon_1, tampon_2 );

    tampon1h_1 = vec_mule( tampon1_4, tampon2_4 );
    tampon1l_1 = vec_mulo( tampon1_4, tampon2_4 );
    tampon_1  = vec_pack( tampon1h_1, tampon1h_1);
    tampon_2  = vec_pack( tampon1l_1, tampon1l_1);
    RESULTAT( arg->result, i, 3, signed char ) = (vector signed char)vec_mergel( tampon_1, tampon_2 );
  } 
}

void  AVmulvu16 ( CAMLG4_ARGUMENTS* arg )
{
  long nb_iter, i;
  register vector unsigned short tampon1_1 , tampon1_2 , tampon1_3 , tampon1_4;
  register vector unsigned short tampon2_1 , tampon2_2 , tampon2_3 , tampon2_4;
  register vector unsigned short TL        , TH1       , TH2;
  register vector unsigned short val       , sixteen;

  EVAL_VECTOR_SIZE( unsigned short );

  sixteen = vec_splat_u16(-8);

  for( i = 0; i < nb_iter; ++i )
  {          
    LOAD_REGISTER( tampon1_1, i, 0, unsigned short, arg->vector1 );
    LOAD_REGISTER( tampon1_2, i, 1, unsigned short, arg->vector1 );
    LOAD_REGISTER( tampon1_3, i, 2, unsigned short, arg->vector1 );
    LOAD_REGISTER( tampon1_4, i, 3, unsigned short, arg->vector1 );

    LOAD_REGISTER( tampon2_1, i, 0, unsigned short, arg->vector2 );
    LOAD_REGISTER( tampon2_2, i, 1, unsigned short, arg->vector2 );
    LOAD_REGISTER( tampon2_3, i, 2, unsigned short, arg->vector2 );
    LOAD_REGISTER( tampon2_4, i, 3, unsigned short, arg->vector2 );

    TL  = vec_mulo( (vector unsigned char)tampon1_1, (vector unsigned char)tampon2_1);
    val = vec_rl(tampon2_1, sixteen);
    TH1 = vec_mulo( (vector unsigned char)tampon1_1, (vector unsigned char)val);
    TH2 = vec_mule( (vector unsigned char)tampon1_1, (vector unsigned char)val);
    TH1 = vec_add(TH1,TH2);
    TH1 = vec_sl( TH1, sixteen);
    
    RESULTAT( arg->result, i, 0, unsigned short ) = vec_add( TH1,TL );

    TL  = vec_mulo( (vector unsigned char)tampon1_2, (vector unsigned char)tampon2_2);
    val = vec_rl(tampon2_2, sixteen);
    TH1 = vec_mulo( (vector unsigned char)tampon1_2, (vector unsigned char)val);
    TH2 = vec_mule( (vector unsigned char)tampon1_2, (vector unsigned char)val);
    TH1 = vec_add(TH1,TH2);
    TH1 = vec_sl( TH1, sixteen);

    RESULTAT( arg->result, i, 1, unsigned short ) = vec_add( TH1,TL );

    TL  = vec_mulo( (vector unsigned char)tampon1_3, (vector unsigned char)tampon2_3);
    val = vec_rl(tampon2_3, sixteen);
    TH1 = vec_mulo( (vector unsigned char)tampon1_3, (vector unsigned char)val);
    TH2 = vec_mule( (vector unsigned char)tampon1_3, (vector unsigned char)val);
    TH1 = vec_add(TH1,TH2);
    TH1 = vec_sl( TH1, sixteen);

    RESULTAT( arg->result, i, 2, unsigned short ) = vec_add( TH1,TL );

    TL  = vec_mulo( (vector unsigned char)tampon1_4, (vector unsigned char)tampon2_4);
    val = vec_rl(tampon2_4, sixteen);
    TH1 = vec_mulo( (vector unsigned char)tampon1_4, (vector unsigned char)val);
    TH2 = vec_mule( (vector unsigned char)tampon1_4, (vector unsigned char)val);
    TH1 = vec_add(TH1,TH2);
    TH1 = vec_sl( TH1, sixteen);

    RESULTAT( arg->result, i, 3, unsigned short ) = vec_add( TH1,TL );
  }
}

void  AVmulvs16 ( CAMLG4_ARGUMENTS* arg )
{
  long nb_iter, i;

  register vector unsigned short  TL      , TH1      , TH2;
  register vector bool short      sign1   , sign2    , rsign;
  register vector signed short    T1      , tampon1_1, tampon1_2, tampon1_3 , tampon1_4;
  register vector signed short    T       , tampon2_1, tampon2_2, tampon2_3 , tampon2_4, swap;
  register vector unsigned short  sixteen;

  sixteen = vec_splat_u16(-8);

  EVAL_VECTOR_SIZE( signed short );

  /*        ATTENTION GROSSE FEINTE !!      */
  /*                                        */
  /* A*B  = (sign(A)*sign(B))*abs(A)*abs(B) */
  /*                                        */
  /* C'est affreux mais ca  marche !        */

  for( i = 0; i < nb_iter; ++i )
  {          
    LOAD_REGISTER( tampon1_1, i, 0, signed short, arg->vector1 );
    LOAD_REGISTER( tampon1_2, i, 1, signed short, arg->vector1 );
    LOAD_REGISTER( tampon1_3, i, 2, signed short, arg->vector1 );
    LOAD_REGISTER( tampon1_4, i, 3, signed short, arg->vector1 );

    LOAD_REGISTER( tampon1_1, i, 0, signed short, arg->vector2 );
    LOAD_REGISTER( tampon1_2, i, 1, signed short, arg->vector2 );
    LOAD_REGISTER( tampon1_3, i, 2, signed short, arg->vector2 );
    LOAD_REGISTER( tampon1_4, i, 3, signed short, arg->vector2 );

    sign1     = vec_cmpgt( s16_zero, tampon1_1 );
    sign2     = vec_cmpgt( s16_zero, tampon2_1 );
    rsign     = vec_xor( sign1, sign2 );

    tampon1_1 = vec_sel( tampon1_1, vec_sub(s16_zero,tampon1_1), sign1 );
    tampon2_1 = vec_sel( tampon2_1, vec_sub(s16_zero,tampon2_1), sign2 );
    swap      = vec_rl( tampon2_1,sixteen);

    TL    = vec_mulo( (vector unsigned char)tampon1_1, (vector unsigned char)tampon2_1);
    TH1   = vec_mulo( (vector unsigned char)tampon1_1, (vector unsigned char)swap);
    TH2   = vec_mule( (vector unsigned char)tampon1_1, (vector unsigned char)swap);
    TH1   = vec_add(TH1,TH2);
    TH1   = vec_sl( TH1, sixteen);
    T     = (vector signed short)vec_add( TH1,TL );

    RESULTAT( arg->result, i, 0, signed short ) = vec_sel( T, vec_sub(s16_zero,T), rsign);       

    sign1     = vec_cmpgt( s16_zero, tampon1_2 );
    sign2     = vec_cmpgt( s16_zero, tampon2_2 );
    rsign     = vec_xor( sign1, sign2 );

    tampon1_1 = vec_sel( tampon1_2, vec_sub(s16_zero,tampon1_1), sign1 );
    tampon2_1 = vec_sel( tampon2_2, vec_sub(s16_zero,tampon2_1), sign2 );
    swap      = vec_rl( tampon2_2,sixteen);

    TL    = vec_mulo( (vector unsigned char)tampon1_2, (vector unsigned char)tampon2_2);
    TH1   = vec_mulo( (vector unsigned char)tampon1_2, (vector unsigned char)swap);
    TH2   = vec_mule( (vector unsigned char)tampon1_2, (vector unsigned char)swap);
    TH1   = vec_add(TH1,TH2);
    TH1   = vec_sl( TH1, sixteen);
    T     = (vector signed short)vec_add( TH1,TL );

    RESULTAT( arg->result, i, 1, signed short ) = vec_sel( T, vec_sub(s16_zero,T), rsign); 

    sign1     = vec_cmpgt( s16_zero, tampon1_3 );
    sign2     = vec_cmpgt( s16_zero, tampon2_3 );
    rsign     = vec_xor( sign1, sign2 );

    tampon1_1 = vec_sel( tampon1_3, vec_sub(s16_zero,tampon1_3), sign1 );
    tampon2_1 = vec_sel( tampon2_3, vec_sub(s16_zero,tampon2_3), sign2 );
    swap      = vec_rl( tampon2_3,sixteen);

    TL    = vec_mulo( (vector unsigned char)tampon1_3, (vector unsigned char)tampon2_3);
    TH1   = vec_mulo( (vector unsigned char)tampon1_3, (vector unsigned char)swap);
    TH2   = vec_mule( (vector unsigned char)tampon1_3, (vector unsigned char)swap);
    TH1   = vec_add(TH1,TH2);
    TH1   = vec_sl( TH1, sixteen);
    T     = (vector signed short)vec_add( TH1,TL );

    RESULTAT( arg->result, i, 2, signed short ) = vec_sel( T, vec_sub(s16_zero,T), rsign); 

    sign1     = vec_cmpgt( s16_zero, tampon1_4 );
    sign2     = vec_cmpgt( s16_zero, tampon2_4 );
    rsign     = vec_xor( sign1, sign2 );

    tampon1_1 = vec_sel( tampon1_4, vec_sub(s16_zero,tampon1_4), sign1 );
    tampon2_1 = vec_sel( tampon2_4, vec_sub(s16_zero,tampon2_4), sign2 );
    swap      = vec_rl( tampon2_4,sixteen);

    TL    = vec_mulo( (vector unsigned char)tampon1_4, (vector unsigned char)tampon2_4);
    TH1   = vec_mulo( (vector unsigned char)tampon1_4, (vector unsigned char)swap);
    TH2   = vec_mule( (vector unsigned char)tampon1_4, (vector unsigned char)swap);
    TH1   = vec_add(TH1,TH2);
    TH1   = vec_sl( TH1, sixteen);
    T     = (vector signed short)vec_add( TH1,TL );

    RESULTAT( arg->result, i, 3, signed short ) = vec_sel( T, vec_sub(s16_zero,T), rsign);   
  }
}

void  AVmulvs32 ( CAMLG4_ARGUMENTS* arg )
{
  long nb_iter, i;
  register vector float tampon1_1, tampon1_2, tampon1_3, tampon1_4;
  register vector float tampon2_1, tampon2_2, tampon2_3, tampon2_4;
  register vector float temp1    , temp2    , temp3    , temp4;

  EVAL_VECTOR_SIZE( signed long );

  for( i = 0; i < nb_iter; ++i )
  {    
    FLOAD_REGISTER( tampon1_1, i, 0, signed long, arg->vector1 );
    FLOAD_REGISTER( tampon1_2, i, 1, signed long, arg->vector1 );
    FLOAD_REGISTER( tampon2_1, i, 0, signed long, arg->vector2 );
    FLOAD_REGISTER( tampon2_2, i, 1, signed long, arg->vector2 );

    temp1 = vec_madd( tampon1_1, tampon2_1, f32_zero );
    temp2 = vec_madd( tampon1_2, tampon2_2, f32_zero );

    RESULTAT( arg->result,  i, 0, long ) = vec_cts( temp1, 0 );
    RESULTAT( arg->result,  i, 1, long ) = vec_cts( temp2, 0 );

    FLOAD_REGISTER( tampon1_3, i, 2, signed long, arg->vector1 );
    FLOAD_REGISTER( tampon1_4, i, 3, signed long, arg->vector1 );    
    FLOAD_REGISTER( tampon2_3, i, 2, signed long, arg->vector2 );
    FLOAD_REGISTER( tampon2_4, i, 3, signed long, arg->vector2 );
   
    temp3 = vec_madd( tampon1_3, tampon2_2, f32_zero );
    temp4 = vec_madd( tampon1_4, tampon2_2, f32_zero );

    RESULTAT( arg->result,  i, 2, long ) = vec_cts( temp3, 0 );
    RESULTAT( arg->result,  i, 3, long ) = vec_cts( temp4, 0 );   
  }
}

void  AVmulvf32 ( CAMLG4_ARGUMENTS* arg )
{
  long nb_iter, i;
  register vector float tampon1_1, tampon1_2, tampon1_3, tampon1_4;
  register vector float tampon2_1, tampon2_2, tampon2_3, tampon2_4; 

  EVAL_VECTOR_SIZE( float );

  for( i = 0; i < nb_iter; ++i )
  {
    LOAD_REGISTER( tampon1_1, i, 0, float, arg->vector1 );
    LOAD_REGISTER( tampon1_2, i, 1, float, arg->vector1 );
    LOAD_REGISTER( tampon2_1, i, 0, float, arg->vector2 );
    LOAD_REGISTER( tampon2_2, i, 1, float, arg->vector2 );

    RESULTAT( arg->result,  i, 2, float ) = vec_madd( tampon1_3, tampon2_3, f32_zero );
    RESULTAT( arg->result,  i, 3, float ) = vec_madd( tampon1_4, tampon2_4, f32_zero );   

    LOAD_REGISTER( tampon1_3, i, 2, float, arg->vector1 );
    LOAD_REGISTER( tampon1_4, i, 3, float, arg->vector1 );    
    LOAD_REGISTER( tampon2_3, i, 2, float, arg->vector2 );
    LOAD_REGISTER( tampon2_4, i, 3, float, arg->vector2 );

    RESULTAT( arg->result,  i, 0, float ) = vec_madd( tampon1_1, tampon2_1, f32_zero );
    RESULTAT( arg->result,  i, 1, float ) = vec_madd( tampon1_2, tampon2_2, f32_zero );
  }
}
