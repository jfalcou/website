#pragma once

#include "types.hpp"

#include <ostream>

// Declaration of operator<< for fraction_t and number_t.
// You must define them in printing.cpp.

std::ostream &operator<<(std::ostream &, fraction_t const &);

std::ostream &operator<<(std::ostream &, number_t const &);
