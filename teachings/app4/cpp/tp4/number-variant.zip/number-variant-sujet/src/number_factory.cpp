#include "number_factory.hpp"
#include "types.hpp"

#include <sstream>

// Implementez ici
// number_t number_factory(std::string const &kind, std::string const &text)

/*...Compléter ici ...*/
