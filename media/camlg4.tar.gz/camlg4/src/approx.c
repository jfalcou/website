/*========================================================*/
/**
 * @file   approx.c
 * @author Joel FALCOU
 * @date   Tue May 14 13:37:13 2002
 * 
 * @brief  Source de approx.h
 * 
 * Ce fichier contient le code des differentes 
 * fonctions de calculs approches vectoriels.
 *
 */
/*========================================================*/

#include <stdio.h>
#include <stdlib.h>

#include "camlg4_internal.h"
#include "altivec_common.h"
#include "approx.h"

void  AVrecf32     ( CAMLG4_ARGUMENTS* arg )
{
  long nb_iter, i;
  register vector float tampon_1, tampon_2, tampon_3, tampon_4;
  register vector float temp_1  , temp_2  , temp_3  , temp_4;
  register vector float rec_1   , rec_2   , rec_3   , rec_4;

  EVAL_VECTOR_SIZE( float );
  
  for( i = 0; i < nb_iter; ++i )
  { 
    LOAD_REGISTER( tampon_1, i, 0, float, arg->vector1 );
    LOAD_REGISTER( tampon_2, i, 1, float, arg->vector1 );    
    LOAD_REGISTER( tampon_3, i, 2, float, arg->vector1 );
    LOAD_REGISTER( tampon_4, i, 3, float, arg->vector1 );

    rec_1  = vec_re( tampon_1 );
    rec_2  = vec_re( tampon_2 );
    rec_3  = vec_re( tampon_3 );
    rec_4  = vec_re( tampon_4 );

    temp_1 = vec_nmsub(rec_1, tampon_1, f32_one);
    temp_2 = vec_nmsub(rec_2, tampon_2, f32_one);
    temp_3 = vec_nmsub(rec_3, tampon_3, f32_one);
    temp_4 = vec_nmsub(rec_4, tampon_4, f32_one);

    RESULTAT( arg->result, i, 0, float ) = vec_madd( rec_1, temp_1, rec_1 );
    RESULTAT( arg->result, i, 1, float ) = vec_madd( rec_2, temp_2, rec_2 );
    RESULTAT( arg->result, i, 3, float ) = vec_madd( rec_4, temp_4, rec_4 );
    RESULTAT( arg->result, i, 2, float ) = vec_madd( rec_3, temp_3, rec_3 );
  }
}

void  AVrecsqrtf32 ( CAMLG4_ARGUMENTS* arg )
{
  long nb_iter, i;
  register vector float tampon_1, tampon_2, tampon_3, tampon_4;
  register vector float temp1_1 , temp1_2 , temp1_3 , temp1_4;
  register vector float temp2_1 , temp2_2 , temp2_3 , temp2_4;
  register vector float rec_1   , rec_2   , rec_3   , rec_4;
  register vector float est_1   , est_2   , est_3   , est_4;
  register vector float minus   , half;

  half  = vec_ctf( vec_splat_s32( 1 ), 1);
  minus = (vector float)( vec_sl( vec_splat_u32(-1), vec_splat_u32(-1) ));

  EVAL_VECTOR_SIZE( float );

  for( i = 0; i < nb_iter; ++i )
  {
    LOAD_REGISTER( tampon_1, i, 0, float, arg->vector1 );
    LOAD_REGISTER( tampon_2, i, 1, float, arg->vector1 );
    LOAD_REGISTER( tampon_3, i, 2, float, arg->vector1 );
    LOAD_REGISTER( tampon_4, i, 3, float, arg->vector1 );
    
    rec_1 = vec_rsqrte( tampon_1 );
    rec_2 = vec_rsqrte( tampon_2 );
    rec_3 = vec_rsqrte( tampon_3 );
    rec_4 = vec_rsqrte( tampon_4 );
    
    est_1   = vec_madd( rec_1, rec_1, minus );
    temp2_1 = vec_madd( rec_1, half, minus );
    temp1_1 = vec_nmsub( tampon_1, est_1, f32_one );

    est_2   = vec_madd( rec_2, rec_2, minus );
    temp2_2 = vec_madd( rec_2, half, minus );
    temp1_2 = vec_nmsub( tampon_2, est_2, f32_one );

    est_3   = vec_madd( rec_3, rec_3, minus );
    temp2_3 = vec_madd( rec_3, half, minus );
    temp1_3 = vec_nmsub( tampon_3, est_3, f32_one );
 
    est_4   = vec_madd( rec_4, rec_4, minus );
    temp2_4 = vec_madd( rec_4, half, minus );
    temp1_4 = vec_nmsub( tampon_4, est_4, f32_one );

    RESULTAT( arg->result, i, 0, float ) = vec_madd( temp1_1, temp2_1, rec_1);
    RESULTAT( arg->result, i, 1, float ) = vec_madd( temp1_2, temp2_2, rec_2);
    RESULTAT( arg->result, i, 2, float ) = vec_madd( temp1_3, temp2_3, rec_3);
    RESULTAT( arg->result, i, 3, float ) = vec_madd( temp1_4, temp2_4, rec_4);
  }
}
