/************************************************************************/
/*!
    @author Original Code Sample from Erik Staats, NWG.
            FWCamAkiz was written by Adrian Daerr

    Copyright (c) 2002 Adrian Daer & Université Paris VII "Denis Diderot" (France).									 
    Copyright (c) 2004 Joel Falcou & Université Clermont-Ferrand II "Blaise Pascal" (France).									 
    All rights reserved.																						 
    																																 
    This file is part of the C+FOX Library.  This
    library is free software; you can redistribute it and/or modify
    it under the terms of the GNU Lesser General Public License as
    published by the Free Software Foundation; either version 2.1,
    or (at your option) any later version.
    																						 
    This library is distributed in the hope that it will be useful,	 
    but WITHOUT ANY WARRANTY; without even the implied warranty of	 
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the		 
    GNU Lesser General Public License for more details.							 
    																																 
    You should have received a copy of the GNU Lesser General				 
    Public License along with this library; see the file COPYING.		 
    If not, send mail to the developers of C+FOX										 
    																																 
    As a special exception, you may use this file as part of a free	 
    software library without restriction. Specifically, if other		 
    files instantiate templates or use macros or inline functions		 
    from this file, or you compile this file and link it with other	 
    files to produce an executable, this file does not by itself		 
    cause the resulting executable to be covered by the GNU Lesser	 
    General Public License.  This exception does not however				 
    invalidate any other reasons why the executable file might be		 
    covered by the GNU Lesser General Public License.
*/
/************************************************************************/

#include <iostream>
#include <cfox/misc/constants.h>
#include <cfox/misc/exception.h>
#include <cfox/device/FWController.h>

using namespace cfox;

/************************************************************************/
/*!
    @method    FWController 
    @abstract   FWController base constructor
    @discussion FWController constructor uses
    a Device Dictionary to find out video device
    on the Firewire bus. From there, it builds an
    internal list of services attached to those
    devices.
*/
/************************************************************************/
FWController::FWController()
{
    mach_port_t  masterPort;
    
    if( kIOReturnSuccess == IOMasterPort( MACH_PORT_NULL, &masterPort ) )
    {
        findUnit(masterPort);
    }
    else
    {
        throw InvalidIOMasterPort();
    }
}

/************************************************************************/
/*!
    @method   ~FWController()  
    @abstract   FWController base destructor
    @discussion Release all memory used by
    the Firewire object and channel. After
    being destroyed, FWController must have
    set all firewire device into a clean
    state for other applications to use them. 
*/
/************************************************************************/
FWController::~FWController() 
{
    if( mCFPlugInInterface ) IODestroyPlugInInterface(mCFPlugInInterface);
}

/************************************************************************/
/*!
    @method     acquireService
    @abstract   FWController main access onto services
    @discussion acquireService allows client to
    control a specific Firewire device found on the
    bus by referencing them by their service ID.
    acquireService performs all the needed initialisation
    of the base device service, letting the client the choice
    on how to hndle IRM and other device options. 
*/
/************************************************************************/
FWDevice::device_ref_t FWController::acquireService( size_t idx, IOFireWireLibDCLCommandPoolRef& dcl, DCLCommandStruct**& udcl )
{
    SInt32                  score;
    IOFireWireLibDeviceRef  resultInterface = 0;
    ComponentResult         result = noErr;
   
    result = IOCreatePlugInInterfaceForService( mDevices[idx].service, kIOFireWireLibTypeID, 
                                                kIOCFPlugInInterfaceID, &mCFPlugInInterface, &score);
    
    if( result == kIOReturnSuccess )
    {
        HRESULT err = (*mCFPlugInInterface)->QueryInterface(mCFPlugInInterface,
                                                            CFUUIDGetUUIDBytes(kIOFireWireDeviceInterfaceID_v2),(void**) &resultInterface);
                                                            
        if( S_OK == err )
        {
            mDevices[idx].interface = resultInterface;
            prepareDCL(idx,dcl,udcl);
            
            (*resultInterface)->Open(resultInterface);
        }
        else
        {
            throw QueryInterfaceFailed();
        }
    }
    else
    {
        throw InterfacePlugInCreationFailed();
    }
 
    (*resultInterface)->AddCallbackDispatcherToRunLoop(resultInterface, CFRunLoopGetCurrent() );
    (*resultInterface)->AddIsochCallbackDispatcherToRunLoop(resultInterface,CFRunLoopGetCurrent());

    return resultInterface;
}

/************************************************************************/
/*!
    @method     releaseService
    @abstract   FWController method to clean up open services. MUST be called
    for each services used trough acquireServices.
*/
/************************************************************************/
void FWController::releaseService( size_t idx )
{
    if( idx < mDevices.size() )
    {
        if( mDevices[idx].dclCommandStruct) delete[] mDevices[idx].dclCommandStruct;
        if( mDevices[idx].dclCommandPool)   (*(mDevices[idx].dclCommandPool))->Release(mDevices[idx].dclCommandPool) ;
        if( mDevices[idx].interface ) 
        {
            (*(mDevices[idx].interface))->Close(mDevices[idx].interface) ;
            (*(mDevices[idx].interface))->Release(mDevices[idx].interface) ;
        }
    }
    else
    {
        throw InvalidServiceRequested();
    }    
}

/************************************************************************/
/*!
    @method     getUnitInfo
    @abstract   Firewire Unit Information retriever
    @discussion Retrieves the Unit Directory and Unit Directory ID
    from a Firewire device on the bus. This identification is needed
    to retrieve the device base address.
*/
/************************************************************************/
void FWController::getUnitInfo( size_t idx, UInt32& adress )
{
    IOFireWireLibConfigDirectoryRef ud   = 0; 
    IOFireWireLibConfigDirectoryRef udid = 0;
    FWAddress                       baseAddress;
    CFStringRef                     text;
            
    ud = (*mDevices[idx].interface)->GetConfigDirectory(mDevices[idx].interface,CFUUIDGetUUIDBytes(kIOFireWireConfigDirectoryInterfaceID));
    
    if( !ud )
    {
        throw NotEnoughMemory();
    }
    else
    {
        (*ud)->GetKeyValue_ConfigDirectory(ud, kConfigUnitDependentInfoKey, &udid, CFUUIDGetUUIDBytes(kIOFireWireConfigDirectoryInterfaceID), nil);
        (*udid)->GetKeyOffset_FWAddress(udid, 0x00, &baseAddress, &text);

        mDevices[idx].address = baseAddress.addressLo;
        adress = mDevices[idx].address;
    }
  
    if( udid )  (*udid)->Release(udid);
    if( ud   )  (*ud)->Release(ud);
}

/************************************************************************/
/*!
    @method     findUnit
    @abstract   Search for valid Camera device on the bus
    @discussion Identify camera device on the Firewire bus.
    This identification allows FWController to sort annymous 
    firewire device between camera and non-camera devices. 
*/
/************************************************************************/
void FWController::findUnit( mach_port_t masterPort )
{
    // ----------------------------------------------------------
    // Build Matching Dictionary
    // ----------------------------------------------------------
    CFMutableDictionaryRef  dict = IOServiceMatching( "IOFireWireUnit" );
    UInt32                  value ;
    CFNumberRef             cfValue ;
    
    value    = kFWCCMSpecID;
    cfValue  = CFNumberCreate(kCFAllocatorDefault, kCFNumberSInt32Type, &value) ;
    CFDictionaryAddValue(dict, CFSTR("Unit_Spec_ID"), cfValue) ;
    CFRelease(cfValue) ;

    if( dict )
    {
        // ----------------------------------------------------------
        // Iterates trough services and add them to master list
        // ----------------------------------------------------------    
        io_service_t    service;
        FWDevice        device;
        io_iterator_t   iterator;
        
        if( kIOReturnSuccess == IOServiceGetMatchingServices( masterPort, dict, &iterator ) )
        {
            service = IOIteratorNext( iterator );
            
            while( service != NULL )
            {
                device.service = service;
                mDevices.push_back(device);
                service = IOIteratorNext( iterator );
            }
        }
        else
        {
            throw NoServicesFound();
        }
    }
    else
    {
        throw InvalidServiceDictionary();
    }
}

/************************************************************************/
/*!
    @method     prepareDCL
    @abstract   DCL Command and Structure initializer
    @discussion Allocate and create the DCL Command Pool and
    Structure for the DCL programm of the camera.
*/
/************************************************************************/
void FWController::prepareDCL( size_t idx,  IOFireWireLibDCLCommandPoolRef& dcl, DCLCommandStruct**& udcl )
{
    IOFireWireLibDeviceRef  i = mDevices[idx].interface;

    mDevices[idx].dclCommandPool = (*i)->CreateDCLCommandPool( i, kDCLProgramSize, CFUUIDGetUUIDBytes(kIOFireWireDCLCommandPoolInterfaceID));
    dcl = mDevices[idx].dclCommandPool;
    
    if( mDevices[idx].dclCommandPool )
    {
        mDevices[idx].dclCommandStruct = new (DCLCommandStruct*)[kMaxTransferDCLs] ;
        udcl = mDevices[idx].dclCommandStruct;
    }
    else
    {
        throw NotEnoughMemory();
    }
}

/************************************************************************/
/*!
    @method     getService
    @abstract   Service access
    @discussion Send a pointer to a given Firewire IO Service from the bus.
*/
/************************************************************************/
FWDevice::service_t FWController::getService( size_t idx )  const   
{ 
    if(idx < mDevices.size() )
    {
        return mDevices[idx].service;
    }
    else
    {
        throw InvalidServiceRequested();
    }
}

/************************************************************************/
/*!
    @method     getServicesAmount
    @abstract   Service enumeration
    @discussion Retrieve the total number of available DC device found.
*/
/************************************************************************/
size_t              FWController::getServicesAmount() const   
{ 
    return mDevices.size();       
}