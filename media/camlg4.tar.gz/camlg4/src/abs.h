/*========================================================*/
/**
 * @file   abs.h
 * @author Joel FALCOU
 * @date   Tue May 14 13:33:30 2002
 * 
 * @brief  En-tete de abs.c
 * 
 * Ce fichier definit les fonctions Valeur Absolu 
 * vectorielle implementees dans abs.c
 */
/*========================================================*/

#ifndef __ABS_H__INCLUDED__
#define __ABS_H__INCLUDED__

void  AVabss8  ( CAMLG4_ARGUMENTS* arg );
void  AVabss16 ( CAMLG4_ARGUMENTS* arg );
void  AVabss32 ( CAMLG4_ARGUMENTS* arg );
void  AVabsf32 ( CAMLG4_ARGUMENTS* arg );

#endif
