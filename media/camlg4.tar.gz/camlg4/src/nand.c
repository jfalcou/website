/*========================================================*/
/**
 * @file   nand.c
 * @author Joel FALCOU 
 * @date   Wed May 15 16:24:02 2002
 * 
 * @brief  source de nand.h
 * 
 * Ce fichier implemente les fonctions de Non Et Logique
 * vectoriel.
 *
 */
/*========================================================*/

#include <stdio.h>
#include <stdlib.h>

#include "camlg4_internal.h"
#include "altivec_common.h"
#include "nand.h"

void  AVnandu8  ( CAMLG4_ARGUMENTS* arg )
{
  long nb_iter, i;
  register vector unsigned char tampon1_1, tampon1_2, tampon1_3, tampon1_4;
  register vector unsigned char tampon2_1, tampon2_2, tampon2_3, tampon2_4;
  register vector unsigned char tmp1     , tmp2     , tmp3     , tmp4;
  register vector unsigned char vrai;
                  unsigned char true;

  true = 0xFF;
  vrai = generic_splat_u8( &true );

  EVAL_VECTOR_SIZE( unsigned char );
  
  for( i = 0; i < nb_iter; ++i )
  {    
    LOAD_REGISTER( tampon1_1, i, 0, unsigned char, arg->vector1 );
    LOAD_REGISTER( tampon2_1, i, 0, unsigned char, arg->vector2 );
    LOAD_REGISTER( tampon1_2, i, 1, unsigned char, arg->vector1 );
    LOAD_REGISTER( tampon2_2, i, 1, unsigned char, arg->vector2 );
    LOAD_REGISTER( tampon1_3, i, 2, unsigned char, arg->vector1 );
    LOAD_REGISTER( tampon2_3, i, 2, unsigned char, arg->vector2 );
    LOAD_REGISTER( tampon1_4, i, 3, unsigned char, arg->vector1 );    
    LOAD_REGISTER( tampon2_4, i, 3, unsigned char, arg->vector2 );

    tmp1 = vec_and( tampon1_1, tampon2_1 );
    tmp2 = vec_and( tampon1_2, tampon2_2 );
    tmp3 = vec_and( tampon1_3, tampon2_3 );
    tmp4 = vec_and( tampon1_4, tampon2_4 );

    RESULTAT( arg->result, i, 0, unsigned char ) = vec_andc( vrai, tmp1 );
    RESULTAT( arg->result, i, 1, unsigned char ) = vec_andc( vrai, tmp2 );
    RESULTAT( arg->result, i, 2, unsigned char ) = vec_andc( vrai, tmp3 );
    RESULTAT( arg->result, i, 3, unsigned char ) = vec_andc( vrai, tmp4 );
  }
}

void  AVnands8  ( CAMLG4_ARGUMENTS* arg )
{
  long nb_iter, i;
  register vector signed char tampon1_1, tampon1_2, tampon1_3, tampon1_4;
  register vector signed char tampon2_1, tampon2_2, tampon2_3, tampon2_4;
  register vector signed char tmp1     , tmp2     , tmp3     , tmp4;
  register vector signed char vrai;
                  signed char true;

  true = 0xFF;
  vrai = generic_splat_s8( &true );

  EVAL_VECTOR_SIZE( signed char );
  
  for( i = 0; i < nb_iter; ++i )
  {    
    LOAD_REGISTER( tampon1_1, i, 0, signed char, arg->vector1 );
    LOAD_REGISTER( tampon2_1, i, 0, signed char, arg->vector2 );
    LOAD_REGISTER( tampon1_2, i, 1, signed char, arg->vector1 );
    LOAD_REGISTER( tampon2_2, i, 1, signed char, arg->vector2 );
    LOAD_REGISTER( tampon1_3, i, 2, signed char, arg->vector1 );
    LOAD_REGISTER( tampon2_3, i, 2, signed char, arg->vector2 );
    LOAD_REGISTER( tampon1_4, i, 3, signed char, arg->vector1 );    
    LOAD_REGISTER( tampon2_4, i, 3, signed char, arg->vector2 );

    tmp1 = vec_and( tampon1_1, tampon2_1 );
    tmp2 = vec_and( tampon1_2, tampon2_2 );
    tmp3 = vec_and( tampon1_3, tampon2_3 );
    tmp4 = vec_and( tampon1_4, tampon2_4 );

    RESULTAT( arg->result, i, 0, signed char ) = vec_andc( vrai, tmp1 );
    RESULTAT( arg->result, i, 1, signed char ) = vec_andc( vrai, tmp2 );
    RESULTAT( arg->result, i, 2, signed char ) = vec_andc( vrai, tmp3 );
    RESULTAT( arg->result, i, 3, signed char ) = vec_andc( vrai, tmp4 );
  }
}

void  AVnandu16 ( CAMLG4_ARGUMENTS* arg )
{
  long nb_iter, i;
  register vector unsigned short tampon1_1, tampon1_2, tampon1_3, tampon1_4;
  register vector unsigned short tampon2_1, tampon2_2, tampon2_3, tampon2_4;
  register vector unsigned short tmp1     , tmp2     , tmp3     , tmp4;
  register vector unsigned short vrai;
                  unsigned short true;

  true = 0xFFFF;
  vrai = generic_splat_u16( &true );

  EVAL_VECTOR_SIZE( unsigned short );
  
  for( i = 0; i < nb_iter; ++i )
  {    
    LOAD_REGISTER( tampon1_1, i, 0, unsigned short, arg->vector1 );
    LOAD_REGISTER( tampon2_1, i, 0, unsigned short, arg->vector2 );
    LOAD_REGISTER( tampon1_2, i, 1, unsigned short, arg->vector1 );
    LOAD_REGISTER( tampon2_2, i, 1, unsigned short, arg->vector2 );
    LOAD_REGISTER( tampon1_3, i, 2, unsigned short, arg->vector1 );
    LOAD_REGISTER( tampon2_3, i, 2, unsigned short, arg->vector2 );
    LOAD_REGISTER( tampon1_4, i, 3, unsigned short, arg->vector1 );    
    LOAD_REGISTER( tampon2_4, i, 3, unsigned short, arg->vector2 );

    tmp1 = vec_and( tampon1_1, tampon2_1 );
    tmp2 = vec_and( tampon1_2, tampon2_2 );
    tmp3 = vec_and( tampon1_3, tampon2_3 );
    tmp4 = vec_and( tampon1_4, tampon2_4 );

    RESULTAT( arg->result, i, 0, unsigned short ) = vec_andc( vrai, tmp1 );
    RESULTAT( arg->result, i, 1, unsigned short ) = vec_andc( vrai, tmp2 );
    RESULTAT( arg->result, i, 2, unsigned short ) = vec_andc( vrai, tmp3 );
    RESULTAT( arg->result, i, 3, unsigned short ) = vec_andc( vrai, tmp4 );
  }
}

void  AVnands16 ( CAMLG4_ARGUMENTS* arg )
{
  long nb_iter, i;
  register vector signed short tampon1_1, tampon1_2, tampon1_3, tampon1_4;
  register vector signed short tampon2_1, tampon2_2, tampon2_3, tampon2_4;
  register vector signed short tmp1     , tmp2     , tmp3     , tmp4;
  register vector signed short vrai;
                  signed short true;

  true = 0xFFFF;
  vrai = generic_splat_s16( &true );

  EVAL_VECTOR_SIZE( signed short );
  
  for( i = 0; i < nb_iter; ++i )
  {    
    LOAD_REGISTER( tampon1_1, i, 0, signed short, arg->vector1 );
    LOAD_REGISTER( tampon2_1, i, 0, signed short, arg->vector2 );
    LOAD_REGISTER( tampon1_2, i, 1, signed short, arg->vector1 );
    LOAD_REGISTER( tampon2_2, i, 1, signed short, arg->vector2 );
    LOAD_REGISTER( tampon1_3, i, 2, signed short, arg->vector1 );
    LOAD_REGISTER( tampon2_3, i, 2, signed short, arg->vector2 );
    LOAD_REGISTER( tampon1_4, i, 3, signed short, arg->vector1 );    
    LOAD_REGISTER( tampon2_4, i, 3, signed short, arg->vector2 );

    tmp1 = vec_and( tampon1_1, tampon2_1 );
    tmp2 = vec_and( tampon1_2, tampon2_2 );
    tmp3 = vec_and( tampon1_3, tampon2_3 );
    tmp4 = vec_and( tampon1_4, tampon2_4 );

    RESULTAT( arg->result, i, 0, signed short ) = vec_andc( vrai, tmp1 );
    RESULTAT( arg->result, i, 1, signed short ) = vec_andc( vrai, tmp2 );
    RESULTAT( arg->result, i, 2, signed short ) = vec_andc( vrai, tmp3 );
    RESULTAT( arg->result, i, 3, signed short ) = vec_andc( vrai, tmp4 );
  }
}

void  AVnands32 ( CAMLG4_ARGUMENTS* arg )
{
  long nb_iter, i;
  register vector signed long tampon1_1, tampon1_2, tampon1_3, tampon1_4;
  register vector signed long tampon2_1, tampon2_2, tampon2_3, tampon2_4;
  register vector signed long tmp1     , tmp2     , tmp3     , tmp4;
  register vector signed long vrai;
                  signed long true;

  true = 0xFFFFFFFF;
  vrai = generic_splat_s32( &true );

  EVAL_VECTOR_SIZE( signed long );
  
  for( i = 0; i < nb_iter; ++i )
  {    
    LOAD_REGISTER( tampon1_1, i, 0, signed long, arg->vector1 );
    LOAD_REGISTER( tampon2_1, i, 0, signed long, arg->vector2 );
    LOAD_REGISTER( tampon1_2, i, 1, signed long, arg->vector1 );
    LOAD_REGISTER( tampon2_2, i, 1, signed long, arg->vector2 );
    LOAD_REGISTER( tampon1_3, i, 2, signed long, arg->vector1 );
    LOAD_REGISTER( tampon2_3, i, 2, signed long, arg->vector2 );
    LOAD_REGISTER( tampon1_4, i, 3, signed long, arg->vector1 );    
    LOAD_REGISTER( tampon2_4, i, 3, signed long, arg->vector2 );

    tmp1 = vec_and( tampon1_1, tampon2_1 );
    tmp2 = vec_and( tampon1_2, tampon2_2 );
    tmp3 = vec_and( tampon1_3, tampon2_3 );
    tmp4 = vec_and( tampon1_4, tampon2_4 );

    RESULTAT( arg->result, i, 0, signed long ) = vec_andc( vrai, tmp1 );
    RESULTAT( arg->result, i, 1, signed long ) = vec_andc( vrai, tmp2 );
    RESULTAT( arg->result, i, 2, signed long ) = vec_andc( vrai, tmp3 );
    RESULTAT( arg->result, i, 3, signed long ) = vec_andc( vrai, tmp4 );
  }
}
