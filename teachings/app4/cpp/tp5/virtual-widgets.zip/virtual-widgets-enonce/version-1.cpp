#include <iostream>
#include <memory>
#include <string>
#include <vector>

struct canvas_t {
  virtual void draw(int x, int y, char t) = 0;
  virtual ~canvas_t() = default;
};

struct blittable_t {
  /* A compléter... */
};

using blittable_ptr_t = std::unique_ptr<blittable_t>;

/* A compléter... */

int main() {
  ascii_art_t drawing(25, 9);

  drawing.add(std::make_unique<button_t>(3, 3, "Hello World!", '~'));
  drawing.add(button_t(3, 6, "Hello World!", '~'));
  drawing.display(std::cout);
}
