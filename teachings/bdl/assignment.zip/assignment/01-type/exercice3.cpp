/*
  Exercise 3 - Manipulating fixed-size arrays (do not use std::vector)

  Q1 - Use std::array to define an array of 3 elements of type double.

  Q2 - Use std::array to define an array of 3 elements, each of which is an
  array of 3 doubles (i.e., a 3x3 matrix).

  Q3 - Define a type alias named vec3 for the std::array<double, 3> type.

  Q4 - Using this type, create a variable v that contains the vector:

  | 2.5 |
  | 0.6 |
  | 1.1 |

  Q5 - Define a type alias named mat33 for a 3x3 matrix of doubles.

  Q6 - Using this type, create a variable m containing the matrix:

  | 1 2 1 |
  | 2 4 6 |
  | 1 2 0 |

  Q7 - Compute the product of matrix m and vector v and store it in a
  vec3 named res.

  Q8 - Verify your result.
*/

#include <array>
#include <iostream>

int main(int, char **) {
  // Q1

  // Q2

  // Q3

  // Q4

  // Q5

  // Q6

  // Q7
  vec3 res = {};

  // Q8
  std::cout << res[0] << "\n";
  std::cout << res[1] << "\n";
  std::cout << res[2] << "\n";

  return 0;
}
