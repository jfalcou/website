/*========================================================*/
/**
 * @file   mask_odd.h
 * @author Joel FALCOU
 * @date   Tue May 14 13:33:30 2002
 * 
 * @brief  En-tete de mask_odd.c
 * 
 * Ce fichier definit les fonctions de masquage
 * vectoriel implementees dans mask_odd.c
 */
/*========================================================*/

#ifndef __MASK_ODD_H__INCLUDED__
#define __MASK_ODD_H__INCLUDED__

void  AVmask_oddu8  ( CAMLG4_ARGUMENTS* arg );
void  AVmask_odds8  ( CAMLG4_ARGUMENTS* arg );
void  AVmask_oddu16 ( CAMLG4_ARGUMENTS* arg );
void  AVmask_odds16 ( CAMLG4_ARGUMENTS* arg );
void  AVmask_odds32 ( CAMLG4_ARGUMENTS* arg );
void  AVmask_oddf32 ( CAMLG4_ARGUMENTS* arg );

#endif
