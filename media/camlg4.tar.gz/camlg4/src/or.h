/*========================================================*/
/**
 * @file   or.h
 * @author Joel FALCOU
 * @date   Wed May 15 12:55:52 2002
 * 
 * @brief  En Tete de or.c
 * 
 * Ce fichier definit les fonctions Ou Logiques
 * vectoriels implementees dans or.c
 * 
 */
/*========================================================*/

#ifndef __OR_H__INCLUDED__
#define __OR_H__INCLUDED__

void  AVoru8  ( CAMLG4_ARGUMENTS* arg );
void  AVors8  ( CAMLG4_ARGUMENTS* arg );
void  AVoru16 ( CAMLG4_ARGUMENTS* arg );
void  AVors16 ( CAMLG4_ARGUMENTS* arg );
void  AVors32 ( CAMLG4_ARGUMENTS* arg );

#endif
