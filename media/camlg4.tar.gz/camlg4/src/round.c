/*========================================================*/
/**
 * @file   round.c
 * @author Joel FALCOU
 * @date   Tue May 14 13:37:13 2002
 * 
 * @brief  Source de round.h
 * 
 * Ce fichier contient le code des differentes 
 * fonctions de calculs d'arrondis vectoriels.
 *
 */
/*========================================================*/

#include <stdio.h>
#include <stdlib.h>

#include "camlg4_internal.h"
#include "altivec_common.h"
#include "round.h"

void  AVroundf32 ( CAMLG4_ARGUMENTS* arg )
{
  long nb_iter, i;
  register vector float tampon_1, tampon_2, tampon_3, tampon_4;

  EVAL_VECTOR_SIZE( float );

  for( i = 0; i < nb_iter; ++i )
  {  
    LOAD_REGISTER( tampon_1, i, 0, float, arg->vector1 );
    LOAD_REGISTER( tampon_2, i, 1, float, arg->vector1 );
    LOAD_REGISTER( tampon_3, i, 2, float, arg->vector1 );
    LOAD_REGISTER( tampon_4, i, 3, float, arg->vector1 );

    RESULTAT( arg->result, i, 0, float ) = vec_round( tampon_1 );
    RESULTAT( arg->result, i, 1, float ) = vec_round( tampon_2 );
    RESULTAT( arg->result, i, 2, float ) = vec_round( tampon_3 );
    RESULTAT( arg->result, i, 3, float ) = vec_round( tampon_4 );   
  }
}

void  AVtruncf32 ( CAMLG4_ARGUMENTS* arg )
{
  long nb_iter, i;
  register vector float tampon_1, tampon_2, tampon_3, tampon_4;

  EVAL_VECTOR_SIZE( float );

  for( i = 0; i < nb_iter; ++i )
  {    
    LOAD_REGISTER( tampon_1, i, 0, float, arg->vector1 );
    LOAD_REGISTER( tampon_2, i, 1, float, arg->vector1 );
    LOAD_REGISTER( tampon_3, i, 2, float, arg->vector1 );
    LOAD_REGISTER( tampon_4, i, 3, float, arg->vector1 );
   
    RESULTAT( arg->result, i, 0, float ) = vec_trunc( tampon_1 );
    RESULTAT( arg->result, i, 1, float ) = vec_trunc( tampon_2 );
    RESULTAT( arg->result, i, 2, float ) = vec_trunc( tampon_3 );
    RESULTAT( arg->result, i, 3, float ) = vec_trunc( tampon_4 );   
  }
}

void  AVceilf32  ( CAMLG4_ARGUMENTS* arg )
{
  long nb_iter, i;
  register vector float tampon_1, tampon_2, tampon_3, tampon_4;

  EVAL_VECTOR_SIZE( float );

  for( i = 0; i < nb_iter; ++i )
  {    
    LOAD_REGISTER( tampon_1, i, 0, float, arg->vector1 );
    LOAD_REGISTER( tampon_2, i, 1, float, arg->vector1 );
    LOAD_REGISTER( tampon_3, i, 2, float, arg->vector1 );
    LOAD_REGISTER( tampon_4, i, 3, float, arg->vector1 );

    RESULTAT( arg->result, i, 0, float ) = vec_ceil( tampon_1 );
    RESULTAT( arg->result, i, 1, float ) = vec_ceil( tampon_2 );
    RESULTAT( arg->result, i, 2, float ) = vec_ceil( tampon_3 );
    RESULTAT( arg->result, i, 3, float ) = vec_ceil( tampon_4 );   
  }
}

void  AVfloorf32 ( CAMLG4_ARGUMENTS* arg )
{
  long nb_iter, i;
  register vector float tampon_1, tampon_2, tampon_3, tampon_4;

  EVAL_VECTOR_SIZE( float );

  for( i = 0; i < nb_iter; ++i )
  {
    LOAD_REGISTER( tampon_1, i, 0, float, arg->vector1 );
    LOAD_REGISTER( tampon_2, i, 1, float, arg->vector1 );
    LOAD_REGISTER( tampon_3, i, 2, float, arg->vector1 );
    LOAD_REGISTER( tampon_4, i, 3, float, arg->vector1 );
    
    RESULTAT( arg->result, i, 0, float ) = vec_floor( tampon_1 );
    RESULTAT( arg->result, i, 1, float ) = vec_floor( tampon_2 );
    RESULTAT( arg->result, i, 2, float ) = vec_floor( tampon_3 );
    RESULTAT( arg->result, i, 3, float ) = vec_floor( tampon_4 );   
  }
}
