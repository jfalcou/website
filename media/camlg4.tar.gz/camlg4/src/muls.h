/*========================================================*/
/**
 * @file   muls.h
 * @author Joel FALCOU
 * @date   Tue May 14 13:33:30 2002
 * 
 * @brief  En-tete de muls.c
 * 
 * Ce fichier definit les fonctions de multiplication
 * vecteur-scalaore implementees dans sub.c
 *
 */
/*========================================================*/

#ifndef __MULS_H__INCLUDED__
#define __MULS_H__INCLUDED__

void  AVmulsu8  ( CAMLG4_ARGUMENTS* arg );
void  AVmulss8  ( CAMLG4_ARGUMENTS* arg );
void  AVmulsu16 ( CAMLG4_ARGUMENTS* arg );
void  AVmulss16 ( CAMLG4_ARGUMENTS* arg );
void  AVmulss32 ( CAMLG4_ARGUMENTS* arg );
void  AVmulsf32 ( CAMLG4_ARGUMENTS* arg );

#endif
