# Virtual widgets

In this exercise, you will start with a widget structure to implement
a GUI that will be displayed in the console. The initial structure is provided,
and you must follow the instructions to improve it.

At each stage, a new hint is provided to give you an idea of
the API that will be expected. It will then be up to you to implement it.

**You must add tests for each step.**

##
Version 0 - Starting point

The structure is provided in `version-0.cpp`. You have several types to complete:

- `canvas_t`, an interface for anything that can be drawn on
- `box_t`, a rectangle to be drawn on a canvas
- `label_t`, a label to draw on a canvas
- `button_t`, a button to draw on a canvas (combination of `box_t` and `label_t`)

The main function does nothing special except create a button, a canvas, and draw
the button on the canvas (from a function **in the button**).

Sample output:

```
---------------------------
|                         |
|                         |
|                         |
|   ~~~~~~~~~~~~~~~~      |
|   ~ Hello World! ~      |
|   ~~~~~~~~~~~~~~~~      |
|                         |
|                         |
|                         |
---------------------------
```

**Add tests for this step.**

## Version 1 - `blittable_t` interface

1.  Add a virtual `blittable_t` interface. Any object inheriting from this
    interface must implement a `blit` function that takes a canvas as input
    to draw on it.

2.  In the `ascii_art_t` type, add storage for polymorphic objects
    inheriting from `blittable_t` to store the objects to be drawn on the canvas.
    It must be possible to add objects with `add` via a `unique_ptr` or
    directly by passing an object by transfer.
    The `display` function of `ascii_art_t` must draw each object
    in the order in which it was added.

**Add tests for this step.**

## ## Version 2 - Type `group_t`

1.  Add a type `group_t` that inherits from `blittable_t`, which allows you to
    store and draw multiple objects added with the `add` method.
    The `add` method of `ascii_art_t` now only transfers objects
    to the `add` method of `group_t`.

    **You should be able to create a `group_t`
    containing `group_t`s (to be tested).**

2.  Rewrite button using `group_t`.

**Add tests for this step.**
