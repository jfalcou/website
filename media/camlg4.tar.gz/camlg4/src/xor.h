/*========================================================*/
/**
 * @file   xor.h
 * @author Joel FALCOU
 * @date   Wed May 15 12:55:52 2002
 * 
 * @brief  En Tete de xor.c
 * 
 * Ce fichier definit les fonctions Ou Exclusif Logique
 * vectoriels implementees dans xor.c
 * 
 */
/*========================================================*/

#ifndef __XOR_H__INCLUDED__
#define __XOR_H__INCLUDED__

void  AVxoru8  ( CAMLG4_ARGUMENTS* arg );
void  AVxors8  ( CAMLG4_ARGUMENTS* arg );
void  AVxoru16 ( CAMLG4_ARGUMENTS* arg );
void  AVxors16 ( CAMLG4_ARGUMENTS* arg );
void  AVxors32 ( CAMLG4_ARGUMENTS* arg );

#endif
