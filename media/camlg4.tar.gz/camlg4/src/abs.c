/*========================================================*/
/**
 * @file   abs.c
 * @author Joel FALCOU
 * @date   Tue May 14 13:37:13 2002
 * 
 * @brief  Source de abs.h
 * 
 * Ce fichier contient le code des differentes versions
 * de la valeur absolue vectorielle.
 *
 */
/*========================================================*/

#include <stdio.h>
#include <stdlib.h>

#include "altivec_common.h"
#include "camlg4_internal.h"
#include "abs.h"

void  AVabss8  ( CAMLG4_ARGUMENTS* arg )
{
  long nb_iter, i;
  register vector signed char tampon_1, tampon_2, tampon_3, tampon_4;

  EVAL_VECTOR_SIZE( signed char );

  for( i = 0; i < nb_iter; ++i )
  {    
    LOAD_REGISTER( tampon_1, i, 0, signed char, arg->vector1 );
    LOAD_REGISTER( tampon_2, i, 1, signed char, arg->vector1 );
    LOAD_REGISTER( tampon_3, i, 2, signed char, arg->vector1 );
    LOAD_REGISTER( tampon_4, i, 3, signed char, arg->vector1 );

    RESULTAT( arg->result, i, 0, signed char ) = vec_abs( tampon_1 );
    RESULTAT( arg->result, i, 1, signed char ) = vec_abs( tampon_2 );
    RESULTAT( arg->result, i, 2, signed char ) = vec_abs( tampon_3 );
    RESULTAT( arg->result, i, 3, signed char ) = vec_abs( tampon_4 );   
  }
}

void  AVabss16 ( CAMLG4_ARGUMENTS* arg )
{
  long nb_iter, i;
  register vector signed short tampon_1, tampon_2, tampon_3, tampon_4;

  EVAL_VECTOR_SIZE( signed short );

  for( i = 0; i < nb_iter; ++i )
  {
    LOAD_REGISTER( tampon_1, i, 0, signed short, arg->vector1 );
    LOAD_REGISTER( tampon_2, i, 1, signed short, arg->vector1 );
    LOAD_REGISTER( tampon_3, i, 2, signed short, arg->vector1 );
    LOAD_REGISTER( tampon_4, i, 3, signed short, arg->vector1 );

    RESULTAT( arg->result, i, 0, signed short ) = vec_abs( tampon_1 );
    RESULTAT( arg->result, i, 1, signed short ) = vec_abs( tampon_2 );
    RESULTAT( arg->result, i, 2, signed short ) = vec_abs( tampon_3 );
    RESULTAT( arg->result, i, 3, signed short ) = vec_abs( tampon_4 );       
  }
}

void  AVabss32 ( CAMLG4_ARGUMENTS* arg )
{
  long nb_iter, i;
  register vector signed long tampon_1, tampon_2, tampon_3, tampon_4;

  EVAL_VECTOR_SIZE( signed long );

  for( i = 0; i < nb_iter; ++i )
  {
    LOAD_REGISTER( tampon_1, i, 0, signed long, arg->vector1 );
    LOAD_REGISTER( tampon_2, i, 1, signed long, arg->vector1 );
    LOAD_REGISTER( tampon_3, i, 2, signed long, arg->vector1 );
    LOAD_REGISTER( tampon_4, i, 3, signed long, arg->vector1 );

    RESULTAT( arg->result, i, 0, signed long ) = vec_abs( tampon_1 );
    RESULTAT( arg->result, i, 1, signed long ) = vec_abs( tampon_2 );
    RESULTAT( arg->result, i, 2, signed long ) = vec_abs( tampon_3 );
    RESULTAT( arg->result, i, 3, signed long ) = vec_abs( tampon_4 );       
  }
}

void  AVabsf32 ( CAMLG4_ARGUMENTS* arg )
{
  long nb_iter, i;
  register vector float tampon_1, tampon_2, tampon_3, tampon_4;

  EVAL_VECTOR_SIZE( float );
  
  for( i = 0; i < nb_iter; ++i )
  {
    LOAD_REGISTER( tampon_1, i, 0, float, arg->vector1 );
    LOAD_REGISTER( tampon_2, i, 1, float, arg->vector1 );
    LOAD_REGISTER( tampon_3, i, 2, float, arg->vector1 );
    LOAD_REGISTER( tampon_4, i, 3, float, arg->vector1 );

    RESULTAT( arg->result, i, 0, float ) = vec_abs( tampon_1 );
    RESULTAT( arg->result, i, 1, float ) = vec_abs( tampon_2 );
    RESULTAT( arg->result, i, 2, float ) = vec_abs( tampon_3 );
    RESULTAT( arg->result, i, 3, float ) = vec_abs( tampon_4 );       
  }
}
