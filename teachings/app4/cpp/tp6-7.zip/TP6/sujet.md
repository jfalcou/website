# APP4 - C++ - TP 6 - 4H

# Partie 1

1) Faire l'exercice 1 (énnoncé dans exercice_01.cpp).

2) Faire l'exercice 2 (énnoncé dans exercice_02.cpp).

# Partie 2

## CRTP & Variadic Function (Parameter Pack) & Adaptor

Compiler avec les options suivantes (ou équivalentes) :
`-Wall -Wextra -Wpedantic -Wconversion -std=c++20`

### Curiously Recurring Template Pattern (CRTP)

On part du code suivant :

```c++
#include <memory>
#include <iostream>

class mother_t
{
public:
  virtual void fct() const { std::cout << "mother_t" << std::endl; }
  std::unique_ptr<mother_t> clone() const
  {
    return std::make_unique<mother_t>();
  }
};

class daughter_t : public mother_t
{
public:
  virtual void fct() const { std::cout << "daughter_t" << std::endl; }
  std::unique_ptr<mother_t> clone() const
  {
    return std::make_unique<daughter_t>();
  }
};

int main()
{
  auto p1 = std::make_unique<mother_t>();
  p1->fct();
  std::unique_ptr<mother_t> p2 = std::make_unique<daughter_t>();
  p2->fct();
  auto r = p2->clone();
  r->fct();
}
```

On veut que la fonction `.fct()` de la classe `mother_t` affiche « mother_t » et `.fct()` de la classe `daughter_t` affiche « daughter_t ».

1. Quel est le type de p ? de p1 ? Quels sont les trois affichages voulus ?
2. Que retourne la fonction .clone() de mother_t ? et daughter_t ? Pourquoi ?
3. Donner l'implémentation des fonctions .clone().
4. Pourquoi une redéfinition de .clone() est nécessaire ? Comment générer automatiquement la fonction .clone() ?
5. Écrire une classe template cloneable qui prend deux types (base_t et derived_t)
et qui implémente la fonction .clone(). On sait que derived_t héritera cloneable :
c'est-à-dire que cloneable peut être caster (avec static_cast) en derived_t.
6. De quelle(s) classe(s) hérite mother_t ? et daughter_t ?
7. Avec ce code, quelle est l'erreur de compilation ?
Résoudre le souci avec le mot clé using : http://en.cppreference.com/w/cpp/language/using_declaration

### Affichage Avec local::print (bonus)

La fonction printf du langage C a (au moins) deux inconvénients : il faut préciser le type à afficher et il n'est pas possible de gérer les types utilisateurs.

L'utilisation de l'opérateur `<<` entre un `std::ostream` et ce que l'on veut afficher permet de régler ces soucis.


On souhaite écrire une fonction `local::print` qui permettrait d'écrire ce code :

```c++
local::print("Use", ' ', std::string("local::print"), " to print: ",
42, " + ", 21.73, " = ", 42 + 21.73, '\n');
```

Pour écrire une telle fonction, il faudra utiliser un parameter pack : http://en.cppreference.com/w/cpp/language/parameter_pack

1. Écrire une fonction `local::fprint` qui prend un `std::ostream` et qui "force" l'affichage avec std::flush dans le flux.
2. Écrire une fonction `local::fprint` qui prend un `std::ostream`, un T const & et un parameter *pack* `args_t const & ...`
3. Écrire la fonction `local::print`.
