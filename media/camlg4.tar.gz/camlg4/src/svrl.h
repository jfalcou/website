/*========================================================*/
/**
 * @file   svrl.h
 * @author Joel FALCOU
 * @date   Tue July 14 13:23:13 2002
 * 
 * @brief  En-t�te de svrl.c
 * 
 * Ce fichier contient le code des differentes versions
 * de l'op�ration de d�calage �l�ments par �l�ments vectorielle.
 *
 */
/*========================================================*/

#ifndef __SVRL_H__INCLUDED__
#define __SVRL_H__INCLUDED__

void AVsvru8( CAMLG4_ARGUMENTS* arg );
void AVsvrs8( CAMLG4_ARGUMENTS* arg );
void AVsvru16( CAMLG4_ARGUMENTS* arg );
void AVsvrs16( CAMLG4_ARGUMENTS* arg );
void AVsvrs32( CAMLG4_ARGUMENTS* arg );
void AVsvrf32( CAMLG4_ARGUMENTS* arg );

void AVsvlu8( CAMLG4_ARGUMENTS* arg );
void AVsvls8( CAMLG4_ARGUMENTS* arg );
void AVsvlu16( CAMLG4_ARGUMENTS* arg );
void AVsvls16( CAMLG4_ARGUMENTS* arg );
void AVsvls32( CAMLG4_ARGUMENTS* arg );
void AVsvlf32( CAMLG4_ARGUMENTS* arg );

#endif
