/*========================================================*/
/**
 * @file   and.c
 * @author Joel FALCOU
 * @date   Tue May 14 13:37:13 2002
 * 
 * @brief  Source de and.h
 * 
 * Ce fichier cotient le code des differentes versions
 * du Et Logique vectorielle.
 *
 */
/*========================================================*/

#include <stdio.h>
#include <stdlib.h>

#include "camlg4_internal.h"
#include "altivec_common.h"
#include "and.h"

void  AVandu8  ( CAMLG4_ARGUMENTS* arg )
{
  long nb_iter, i;
  register vector unsigned char tampon1_1,tampon1_2,tampon1_3,tampon1_4;
  register vector unsigned char tampon2_1,tampon2_2,tampon2_3,tampon2_4;
 
  EVAL_VECTOR_SIZE( unsigned char );
  
  for( i = 0; i < nb_iter; ++i )
  {
      LOAD_REGISTER( tampon1_1, i, 0, unsigned char, arg->vector1 );
      LOAD_REGISTER( tampon1_2, i, 1, unsigned char, arg->vector1 );
      LOAD_REGISTER( tampon2_1, i, 0, unsigned char, arg->vector2 );
      LOAD_REGISTER( tampon2_2, i, 1, unsigned char, arg->vector2 );

      RESULTAT( arg->result,  i, 0, unsigned char ) = vec_and( tampon1_1, tampon2_1 );
      RESULTAT( arg->result,  i, 1, unsigned char ) = vec_and( tampon1_2, tampon2_2 );  

      LOAD_REGISTER( tampon1_3, i, 2, unsigned char, arg->vector1 );
      LOAD_REGISTER( tampon1_4, i, 3, unsigned char, arg->vector1 );
      LOAD_REGISTER( tampon2_3, i, 2, unsigned char, arg->vector2 );
      LOAD_REGISTER( tampon2_4, i, 3, unsigned char, arg->vector2 );

      RESULTAT( arg->result,  i, 2, unsigned char ) = vec_and( tampon1_3, tampon2_3 );
      RESULTAT( arg->result,  i, 3, unsigned char ) = vec_and( tampon1_4, tampon2_4 );       
  }
}

void  AVands8  ( CAMLG4_ARGUMENTS* arg )
{
  long nb_iter, i;
  register vector signed char tampon1_1,tampon1_2,tampon1_3,tampon1_4;
  register vector signed char tampon2_1,tampon2_2,tampon2_3,tampon2_4;
 
  EVAL_VECTOR_SIZE( signed char );
  
    for( i = 0; i < nb_iter; ++i )
    {    
      LOAD_REGISTER( tampon1_1, i, 0, signed char, arg->vector1 );
      LOAD_REGISTER( tampon1_2, i, 1, signed char, arg->vector1 );
      LOAD_REGISTER( tampon2_1, i, 0, signed char, arg->vector2 );
      LOAD_REGISTER( tampon2_2, i, 1, signed char, arg->vector2 );
     
      RESULTAT( arg->result,  i, 0, signed char ) = vec_and( tampon1_1, tampon2_1 );
      RESULTAT( arg->result,  i, 1, signed char ) = vec_and( tampon1_2, tampon2_2 );  

      LOAD_REGISTER( tampon1_3, i, 2, signed char, arg->vector1 );
      LOAD_REGISTER( tampon1_4, i, 3, signed char, arg->vector1 );
      LOAD_REGISTER( tampon2_3, i, 2, signed char, arg->vector2 );
      LOAD_REGISTER( tampon2_4, i, 3, signed char, arg->vector2 );

      RESULTAT( arg->result,  i, 2, signed char ) = vec_and( tampon1_3, tampon2_3 );
      RESULTAT( arg->result,  i, 3, signed char ) = vec_and( tampon1_4, tampon2_4 );   
    }
}

void  AVandu16 ( CAMLG4_ARGUMENTS* arg )
{
  long nb_iter, i;
  register vector unsigned short tampon1_1,tampon1_2,tampon1_3,tampon1_4;
  register vector unsigned short tampon2_1,tampon2_2,tampon2_3,tampon2_4;
 
  EVAL_VECTOR_SIZE( unsigned short );
  
  for( i = 0; i < nb_iter; ++i )
  {
    LOAD_REGISTER( tampon1_1, i, 0, unsigned short, arg->vector1 );
    LOAD_REGISTER( tampon1_2, i, 1, unsigned short, arg->vector1 );
    LOAD_REGISTER( tampon2_1, i, 0, unsigned short, arg->vector2 );
    LOAD_REGISTER( tampon2_2, i, 1, unsigned short, arg->vector2 );

    RESULTAT( arg->result,  i, 0, unsigned short ) = vec_and( tampon1_1, tampon2_1 );
    RESULTAT( arg->result,  i, 1, unsigned short ) = vec_and( tampon1_2, tampon2_2 );  

    LOAD_REGISTER( tampon1_3, i, 2, unsigned short, arg->vector1 );
    LOAD_REGISTER( tampon1_4, i, 3, unsigned short, arg->vector1 );
    LOAD_REGISTER( tampon2_3, i, 2, unsigned short, arg->vector2 );
    LOAD_REGISTER( tampon2_4, i, 3, unsigned short, arg->vector2 );
    
    RESULTAT( arg->result,  i, 2, unsigned short ) = vec_and( tampon1_3, tampon2_3 );
    RESULTAT( arg->result,  i, 3, unsigned short ) = vec_and( tampon1_4, tampon2_4 );       
  }
}

void  AVands16 ( CAMLG4_ARGUMENTS* arg )
{
  long nb_iter, i;
  register vector signed short tampon1_1,tampon1_2,tampon1_3,tampon1_4;
  register vector signed short tampon2_1,tampon2_2,tampon2_3,tampon2_4;

  EVAL_VECTOR_SIZE( signed short );

  for( i = 0; i < nb_iter; ++i )
  {    
      LOAD_REGISTER( tampon1_1, i, 0, signed short, arg->vector1 );
      LOAD_REGISTER( tampon1_2, i, 1, signed short, arg->vector1 );
      LOAD_REGISTER( tampon2_1, i, 0, signed short, arg->vector2 );
      LOAD_REGISTER( tampon2_2, i, 1, signed short, arg->vector2 );

      RESULTAT( arg->result,  i, 0, signed short ) = vec_and( tampon1_1, tampon2_1 );
      RESULTAT( arg->result,  i, 1, signed short ) = vec_and( tampon1_2, tampon2_2 );  

      LOAD_REGISTER( tampon1_3, i, 2, signed short, arg->vector1 );
      LOAD_REGISTER( tampon1_4, i, 3, signed short, arg->vector1 );
      LOAD_REGISTER( tampon2_3, i, 2, signed short, arg->vector2 );
      LOAD_REGISTER( tampon2_4, i, 3, signed short, arg->vector2 );
      
      RESULTAT( arg->result,  i, 2, signed short ) = vec_and( tampon1_3, tampon2_3 );
      RESULTAT( arg->result,  i, 3, signed short ) = vec_and( tampon1_4, tampon2_4 );   
  }
}

void  AVands32 ( CAMLG4_ARGUMENTS* arg )
{
  long nb_iter, i;
  register vector signed long tampon1_1,tampon1_2,tampon1_3,tampon1_4;
  register vector signed long tampon2_1,tampon2_2,tampon2_3,tampon2_4;

  EVAL_VECTOR_SIZE( signed long );

  for( i = 0; i < nb_iter; ++i )
  {
    LOAD_REGISTER( tampon1_1, i, 0, signed long, arg->vector1 );
    LOAD_REGISTER( tampon1_2, i, 1, signed long, arg->vector1 );    
    LOAD_REGISTER( tampon2_1, i, 0, signed long, arg->vector2 );
    LOAD_REGISTER( tampon2_2, i, 1, signed long, arg->vector2 );

    RESULTAT( arg->result,  i, 0, signed long ) = vec_and( tampon1_1, tampon2_1 );
    RESULTAT( arg->result,  i, 1, signed long ) = vec_and( tampon1_2, tampon2_2 );  

    LOAD_REGISTER( tampon1_3, i, 2, signed long, arg->vector1 );
    LOAD_REGISTER( tampon1_4, i, 3, signed long, arg->vector1 );
    LOAD_REGISTER( tampon2_3, i, 2, signed long, arg->vector2 );
    LOAD_REGISTER( tampon2_4, i, 3, signed long, arg->vector2 );
    
    RESULTAT( arg->result,  i, 2, signed long ) = vec_and( tampon1_3, tampon2_3 );
    RESULTAT( arg->result,  i, 3, signed long ) = vec_and( tampon1_4, tampon2_4 );       
  }
}
