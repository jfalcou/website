/*========================================================*/
/**
 * @file   not.h
 * @author Joel FALCOU
 * @date   Wed May 15 16:23:16 2002
 * 
 * @brief  en-tete de not.c
 * 
 * Ce fichier declare les fonction de Non Logique
 * vectoriel.
 *
 */
/*========================================================*/

#ifndef __NOT_H__INCLUDED__
#define __NOT_H__INCLUDED__

void  AVnotu8  ( CAMLG4_ARGUMENTS* arg );
void  AVnots8  ( CAMLG4_ARGUMENTS* arg );
void  AVnotu16 ( CAMLG4_ARGUMENTS* arg );
void  AVnots16 ( CAMLG4_ARGUMENTS* arg );
void  AVnots32 ( CAMLG4_ARGUMENTS* arg );

#endif
