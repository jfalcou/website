/*
  Exercise 3 - Point cloud

  Q1 - Implement a structure that represents a weighted 3D point (3D point
  with an associated real weight).

  Q2 - Implement the stream extraction and insertion operators for this
  structure.

  Q3 - Look up std::getline and use it to read a text file containing an
  arbitrary number of weighted points. This function should take the filename
  as a parameter and return a std::vector of weighted 3D points.

  Q4 - Implement a function that calculates the distance between two weighted
  points.

  Q5 - Implement a function that returns the point farthest from a given
  reference point among all points stored in a std::vector.

  Q6 - Implement a function that returns the point closest to a given
  reference point among all points stored in a std::vector.

  Q7 - Implement a function that computes the barycenter (centroid) of a
  set of points stored in a std::vector.
  Q8 - Implement a function that computes the distance between the point
  closest to the barycenter and the point farthest from the barycenter.

  Each function should be tested in isolation to ensure correct behavior.
*/

#include <iostream>

int main(int, char **) {}
