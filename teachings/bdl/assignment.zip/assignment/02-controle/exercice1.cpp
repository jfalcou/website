/*
  Exercise 1 - RNG

  Q1 - Get a random integer value between 0 and RAND_MAX. Consult the
  documentation for std::rand to learn how to do this.

  Q2 - Convert that integer to a floating-point value in the interval [1, 20].

  Q3 - Similarly, fill the vector `data` with random floating-point values
  between 1 and 20.

  Q4 - Print the contents of the vector after it has been filled.

  Q5 - Write the code needed to traverse `data` and insert into a results
  container the indices of values that are greater than 15.

  Q6 - Print the results container and check your results.

*/

#include <cmath>
#include <ctime>
#include <iostream>
#include <vector>

int main(int, char **) {
  std::srand(std::time(nullptr));

  std::vector<float> data(20);

  // Q1

  // Q2

  // Q3

  // Q4

  return 0;
}
