#pragma once

#include <complex>
#include <variant>

// Represents the fraction n/d
struct fraction_t {
  double n;
  double d;

  // Explicit conversion operator to double
  inline explicit operator double() const { return n / d; }
};

// Polymorphic type to represent a number.

using number_t = /*...Compléter ici ...*/;
