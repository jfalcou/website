/*
  Exercise 4 - Retrieving command-line options

  The integer variable argc contains the number of values passed on the
  command line. The char* pointer argv contains the list of values passed on
  the command line. For example, if you run this program as:

     ./exo4  test 42 "la la"

  argc will be 4 and argv will contain 4 strings:

    - argv[0] : "./exo4"
    - argv[1] : "test"
    - argv[2] : "42"
    - argv[3] : "la la" (note: quotes are not part of argv)

  Notice that the pointer argv + argc points one past the end of the list of
  arguments.

  In this exercise we will use std::vector and std::string to manipulate these
  values conveniently.

  Q1 - Construct a variable name of type std::string from argv[0]. Print its
  contents. Is the value coherent with your executable name?

  Q2 - std::vector has a constructor that copies data from a pointer to the
  beginning and a pointer to the end. Use that constructor to build a
  std::vector<std::string> named args containing the command-line arguments
  except for the program name.

  Q3 - Verify that args.size() equals argc - 1 by printing the result of the
  comparison.

  Q4 - Using the provided code to read an integer from stdin, print the N-th
  argument stored in args. What happens if the provided N is greater than
  args.size()?
*/

#include <iostream>
#include <string>
#include <vector>

int main(int argc, char **argv) {
  // Q1

  // Q2

  // Q3

  // Q4
  int n;
  std::cout << "Element to display:\n";
  std::cin >> n;

  return 0;
}
