/*
  Exercice 2 - Manipulation de chaines de caractères

  Q1 - Construisez une variable de type chaine contenant 10 symboles '#'

  Q2 - Construisez une variable de type chaine contenant deux symboles '#'
  séparés par 8 espaces

  Q3 - En vous aidant des variables ci-dessus, affichez le motif suivant :

  ##########
  #        #
  #        #
  #        #
  ##########

  Q4 - En vous aidant du code précédent, construisez une variable de type chaine
  de caractère contenant ce motif et affichez-la.
*/

#include <iostream>
#include <string>

int main(int, char **) {
  // Q1

  // Q2

  // Q3

  // Q4

  return 0;
}
