/*
  Exercise 2 - String manipulation

  Q1 - Create a std::string that contains 10 '#' characters.

  Q2 - Create a std::string that contains two '#' characters separated by
  8 spaces.

  Q3 - Using the strings you created above, print the following pattern:

  ##########
  #        #
  #        #
  #        #
  ##########

  Q4 - Using the code from the previous question, construct a single
  std::string that contains the entire pattern and print it.
*/

#include <iostream>
#include <string>

int main(int, char **) {
  // Q1

  // Q2

  // Q3

  // Q4

  return 0;
}
