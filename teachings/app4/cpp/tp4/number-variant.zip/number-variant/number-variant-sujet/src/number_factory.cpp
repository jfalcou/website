#include "number_factory.hpp"
#include "types.hpp"

#include <sstream>

// I implement here
// number_t number_factory(std::string const &kind, std::string const &text)

/*...Fill in here ...*/
