/*========================================================*/
/**
     @file  internal.h
     @brief En-tete  de la bibliotheque CAMLG4.

     Ce fichier d'en-tete contient les definitions 
     des fonctions et des macros internes de la  
     bibliotheque CAMLG4.
 */
/*========================================================*/

#ifndef __INTERNAL_H__INCLUDED__
#define __INTERNAL_H__INCLUDED__

/*========================================================*/
/*                                                        */
/*             Structure de donnees internes.             */
/*                                                        */
/*========================================================*/

/*========================================================*/
/**
 *  @struct av_argument_t
 *  @brief Structure de passage des arguments vectoriels.
 *
 *  Cette stucture permet d'homogeneiser les prototypes
 *  des fonctions Altivec internes. En outre, elle simplifie
 *  l'interfacage avec le stub Caml.
 * 
 */
/*========================================================*/

struct av_argument_t
{
  void*  vector1;   /*< Premier argument vectoriel.   */
  void*  vector2;   /*< Deuxieme argument vectoriel.  */
  void*  vector3;   /*< Troisieme argument vectoriel. */
  void*  result;    /*< Resultat vectoriel.           */
  long   size;      /*< Taille des arguments.         */
};

/*========================================================*/
/**
 * @typedef CAMLG4_ARGUMENTS
 * @brief Type definissant les arguments vectoriels.
 *
 * Ce type est utilisable pour declare simplement une 
 * variable de type av_argument_t.
 * 
 */
/*========================================================*/

typedef struct av_argument_t         CAMLG4_ARGUMENTS;

/*========================================================*/
/*                                                        */
/*                    Macros internes.                    */
/*                                                        */
/*========================================================*/

#define RESULTAT( V, I, J, T )           *( (vector T*)(V) + (4*I + J) )

#define UNPACK_SIGNED( S, H, L )         H = vec_unpackh( S ); \
                                         L = vec_unpackl( S )

#define UNPACK_UNSIGNED( S, H, L, Z, T ) H = (vector T)vec_mergeh( Z, S );   \
                                         L = (vector T)vec_mergel( Z, S )
                                         
#define LOAD_REGISTER(  V, N, O, T, S )  V = vec_ld( (4*N + O)*vec_step(vector T)*sizeof(T), (T*)S )
#define FLOAD_REGISTER( V, N, O, T, S )  V = vec_ctf( vec_ld( (4*N + O)*vec_step(vector T)*sizeof(T), (T*)S ), 0)

#define EVAL_VECTOR_SIZE( T )            nb_iter  = ( ((arg->size)*sizeof(T) & ~63 ) + 64 ) / ((vec_step(vector T) * sizeof(T) * 4))

#define ALLOC_RESULT_ARRAY( S, T )       arg.result = (void*)memalign( 16, ((S*sizeof(T) & ~63 ) + 64 ))

#endif
