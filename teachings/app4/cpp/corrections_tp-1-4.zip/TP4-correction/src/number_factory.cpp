#include "number_factory.hpp"
#include "types.hpp"

#include <sstream>

// Implementez
// number_t number_factory(std::string const &kind, std::string const &text)
// ici

/**c*/
number_t number_factory(std::string const &kind, std::string const &text) {
  if (kind == "real") {
    std::istringstream iss(text);
    double ret;
    iss >> ret;
    return ret;
  }

  if (kind == "complex") {
    std::istringstream iss(text);
    double real;
    double imag;
    iss >> real >> imag;
    return std::complex<double>(real, imag);
  }

  if (kind == "integer") {
    std::istringstream iss(text);
    int ret;
    iss >> ret;
    return ret;
  }

  if (kind == "fraction") {
    std::istringstream iss(text);
    fraction_t ret;
    iss >> ret.n >> ret.d;
    return ret;
  }

  return {};
}
/*c**/
