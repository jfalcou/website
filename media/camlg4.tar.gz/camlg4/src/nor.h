 /*========================================================*/
/**
 * @file   nor.h
 * @author Joel FALCOU
 * @date   Tue May 14 13:33:30 2002
 * 
 * @brief  En-tete de nor.c
 * 
 * Ce fichier definit les fonctions Non Ou Logique 
 * vectorielle implementees dans nor.c
 */
/*========================================================*/

#ifndef __NOR_H__INCLUDED__
#define __NOR_H__INCLUDED__

void  AVnoru8  ( CAMLG4_ARGUMENTS* arg );
void  AVnors8  ( CAMLG4_ARGUMENTS* arg );
void  AVnoru16 ( CAMLG4_ARGUMENTS* arg );
void  AVnors16 ( CAMLG4_ARGUMENTS* arg );
void  AVnors32 ( CAMLG4_ARGUMENTS* arg );

#endif
