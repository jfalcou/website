/*========================================================*/
/**
 * @file   mask_even.h
 * @author Joel FALCOU
 * @date   Tue May 14 13:33:30 2002
 * 
 * @brief  En-tete de mask_even.c
 * 
 * Ce fichier definit les fonctions de masquage
 * vectoriel implementees dans mask_even.c
 */
/*========================================================*/

#ifndef __MASK_EVEN_H__INCLUDED__
#define __MASK_EVEN_H__INCLUDED__

void  AVmask_evenu8  ( CAMLG4_ARGUMENTS* arg );
void  AVmask_evens8  ( CAMLG4_ARGUMENTS* arg );
void  AVmask_evenu16 ( CAMLG4_ARGUMENTS* arg );
void  AVmask_evens16 ( CAMLG4_ARGUMENTS* arg );
void  AVmask_evens32 ( CAMLG4_ARGUMENTS* arg );
void  AVmask_evenf32 ( CAMLG4_ARGUMENTS* arg );

#endif
