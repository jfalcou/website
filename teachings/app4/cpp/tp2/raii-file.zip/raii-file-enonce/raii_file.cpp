#include <cstdio>
#include <iostream>

#include "raii_file.hpp"

int main(int, char const *[]) {
  { // Ecriture
    raii_file some_file("okok.txt", "w");
    std::fprintf(some_file, "okok");
  }

  { // Lecture
    raii_file some_file("okok.txt", "r");
  }

  std::cout << "Tests raii_file.cpp passés.\n";
}
