/*========================================================*/
/**
 * @file   approx.h
 * @author Joel FALCOU
 * @date   Tue May 14 13:33:30 2002
 * 
 * @brief  En-tete de approx.c
 * 
 * Ce fichier definit les fonctions de calcul
 * approches vectoriels implementes dans approx.c
 */
/*========================================================*/

#ifndef __APPROX_H__INCLUDED__
#define __APPROX_H__INCLUDED__

void  AVrecf32     ( CAMLG4_ARGUMENTS* arg );
void  AVrecsqrtf32 ( CAMLG4_ARGUMENTS* arg );

#endif
