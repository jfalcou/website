#include <iostream>
#include <memory>
#include <string>
#include <vector>

struct canvas_t {
  virtual void draw(int x, int y, char t) = 0;
  virtual ~canvas_t() = default;
};

struct box_t {

  /* A compléter... */
  int x0, y0, x1, y1;
  char texture;
};

struct label_t {

  /* A compléter... */
  int x0, y0;
  std::string text;
};

struct button_t {

  /* A compléter... */
  label_t text;
  box_t shape;
};

struct ascii_art_t : public canvas_t {

  /* A compléter... */

private:
  std::vector<char> storage;
  int width, height;
};

int main() {
  button_t b(3, 3, "Hello World!", '~');
  ascii_art_t drawing(25, 9);

  b.blit(drawing);

  drawing.display(std::cout);

  return 0;
}
