/*========================================================*/
/**
 * @file   muls.c
 * @author Joel FALCOU
 * @date   Tue May 14 13:37:13 2002
 * 
 * @brief  Source de muls.h
 * 
 * Ce fichier contient le code des differentes versions
 * de la multiplication vecteur-scalaire.
 *
 */
/*========================================================*/

#include <stdio.h>
#include <stdlib.h>

#include "camlg4_internal.h"
#include "altivec_common.h"
#include "muls.h"

void  AVmulsu8  ( CAMLG4_ARGUMENTS* arg )
{
  long  nb_iter, i;
  register vector unsigned short  tampon1h_1, tampon1l_1;
  register vector unsigned char   tampon1_1 , tampon1_2 , tampon1_3 , tampon1_4;
  register vector unsigned char   tampon2_1 , tampon2_2;
  register vector unsigned char  value;
  unsigned char val;

  EVAL_VECTOR_SIZE( unsigned char );

  val = *( (int*)(arg->vector2) );
  value = generic_splat_u8( &val );

  for( i = 0; i < nb_iter; ++i )
  {      
    LOAD_REGISTER( tampon1_1, i, 0, unsigned char, arg->vector1 );
    LOAD_REGISTER( tampon1_2, i, 1, unsigned char, arg->vector1 );
    LOAD_REGISTER( tampon1_3, i, 2, unsigned char, arg->vector1 );
    LOAD_REGISTER( tampon1_4, i, 3, unsigned char, arg->vector1 );
    
    tampon1h_1 = vec_mule( tampon1_1, value );
    tampon1l_1 = vec_mulo( tampon1_1, value );
    tampon2_1  = vec_pack( tampon1h_1, tampon1h_1);
    tampon2_2  = vec_pack( tampon1l_1, tampon1l_1);
    RESULTAT( arg->result, i, 0, unsigned char ) = (vector unsigned char)vec_mergel( tampon2_1, tampon2_2 );

    tampon1h_1 = vec_mule( tampon1_2, value );
    tampon1l_1 = vec_mulo( tampon1_2, value );
    tampon2_1  = vec_pack( tampon1h_1, tampon1h_1);
    tampon2_2  = vec_pack( tampon1l_1, tampon1l_1);
    RESULTAT( arg->result, i, 1, unsigned char ) = (vector unsigned char)vec_mergel( tampon2_1, tampon2_2 );

    tampon1h_1 = vec_mule( tampon1_3, value );
    tampon1l_1 = vec_mulo( tampon1_3, value );
    tampon2_1  = vec_pack( tampon1h_1, tampon1h_1);
    tampon2_2  = vec_pack( tampon1l_1, tampon1l_1);
    RESULTAT( arg->result, i, 2, unsigned char ) = (vector unsigned char)vec_mergel( tampon2_1, tampon2_2 );

    tampon1h_1 = vec_mule( tampon1_4, value );
    tampon1l_1 = vec_mulo( tampon1_4, value );
    tampon2_1  = vec_pack( tampon1h_1, tampon1h_1);
    tampon2_2  = vec_pack( tampon1l_1, tampon1l_1);
    RESULTAT( arg->result, i, 3, unsigned char ) = (vector unsigned char)vec_mergel( tampon2_1, tampon2_2 );
  }
}

void  AVmulss8  ( CAMLG4_ARGUMENTS* arg )
{
  long  nb_iter, i;
  register vector signed short  tampon1h_1, tampon1l_1;
  register vector signed char   tampon1_1 , tampon1_2 , tampon1_3 , tampon1_4;
  register vector signed char   tampon2_1 , tampon2_2;
  register vector signed char  value;
  signed char val;

  EVAL_VECTOR_SIZE( signed char );

  val = *( (int*)(arg->vector2) );
  value = generic_splat_s8( &val );

  for( i = 0; i < nb_iter; ++i )
  {      
    LOAD_REGISTER( tampon1_1, i, 0, signed char, arg->vector1 );
    LOAD_REGISTER( tampon1_2, i, 1, signed char, arg->vector1 );
    LOAD_REGISTER( tampon1_3, i, 2, signed char, arg->vector1 );
    LOAD_REGISTER( tampon1_4, i, 3, signed char, arg->vector1 );
    
    tampon1h_1 = vec_mule( tampon1_1, value );
    tampon1l_1 = vec_mulo( tampon1_1, value );
    tampon2_1  = vec_pack( tampon1h_1, tampon1h_1);
    tampon2_2  = vec_pack( tampon1l_1, tampon1l_1);
    RESULTAT( arg->result, i, 0, signed char ) = (vector signed char)vec_mergel( tampon2_1, tampon2_2 );

    tampon1h_1 = vec_mule( tampon1_2, value );
    tampon1l_1 = vec_mulo( tampon1_2, value );
    tampon2_1  = vec_pack( tampon1h_1, tampon1h_1);
    tampon2_2  = vec_pack( tampon1l_1, tampon1l_1);
    RESULTAT( arg->result, i, 1, signed char ) = (vector signed char)vec_mergel( tampon2_1, tampon2_2 );

    tampon1h_1 = vec_mule( tampon1_3, value );
    tampon1l_1 = vec_mulo( tampon1_3, value );
    tampon2_1  = vec_pack( tampon1h_1, tampon1h_1);
    tampon2_2  = vec_pack( tampon1l_1, tampon1l_1);
    RESULTAT( arg->result, i, 2, signed char ) = (vector signed char)vec_mergel( tampon2_1, tampon2_2 );

    tampon1h_1 = vec_mule( tampon1_4, value );
    tampon1l_1 = vec_mulo( tampon1_4, value );
    tampon2_1  = vec_pack( tampon1h_1, tampon1h_1);
    tampon2_2  = vec_pack( tampon1l_1, tampon1l_1);
    RESULTAT( arg->result, i, 3, signed char ) = (vector signed char)vec_mergel( tampon2_1, tampon2_2 );
  }
}

void  AVmulsu16 ( CAMLG4_ARGUMENTS* arg )
{
  long nb_iter, i;
  register vector unsigned short tampon_1  , tampon_2  , tampon_3  , tampon_4;
  register vector unsigned short TL        , TH1       , TH2;
  register vector unsigned short lowval    , highval   , sixteen;
	          unsigned short val;

  EVAL_VECTOR_SIZE( unsigned short );

  val = *( (int*)(arg->vector2) );

  sixteen = vec_splat_u16(-8);
  lowval  = generic_splat_u16( &val );
  highval = vec_rl(lowval, sixteen);

  for( i = 0; i < nb_iter; ++i )
  {          
    LOAD_REGISTER( tampon_1, i, 0, unsigned short, arg->vector1 );
    LOAD_REGISTER( tampon_2, i, 1, unsigned short, arg->vector1 );
    LOAD_REGISTER( tampon_3, i, 2, unsigned short, arg->vector1 );
    LOAD_REGISTER( tampon_4, i, 3, unsigned short, arg->vector1 );

    TL  = vec_mulo( (vector unsigned char)tampon_1, (vector unsigned char)lowval);
    TH1 = vec_mulo( (vector unsigned char)tampon_1, (vector unsigned char)highval);
    TH2 = vec_mule( (vector unsigned char)tampon_1, (vector unsigned char)highval);
    TH1 = vec_add(TH1,TH2);
    TH1 = vec_sl( TH1, sixteen);
    
    RESULTAT( arg->result, i, 0, unsigned short ) = vec_add( TH1,TL );

    TL  = vec_mulo( (vector unsigned char)tampon_2, (vector unsigned char)lowval);
    TH1 = vec_mulo( (vector unsigned char)tampon_2, (vector unsigned char)highval);
    TH2 = vec_mule( (vector unsigned char)tampon_2, (vector unsigned char)highval);
    TH1 = vec_add(TH1,TH2);
    TH1 = vec_sl( TH1, sixteen);

    RESULTAT( arg->result, i, 1, unsigned short ) = vec_add( TH1,TL );

    TL  = vec_mulo( (vector unsigned char)tampon_3, (vector unsigned char)lowval);
    TH1 = vec_mulo( (vector unsigned char)tampon_3, (vector unsigned char)highval);
    TH2 = vec_mule( (vector unsigned char)tampon_3, (vector unsigned char)highval);
    TH1 = vec_add(TH1,TH2);
    TH1 = vec_sl( TH1, sixteen);

    RESULTAT( arg->result, i, 2, unsigned short ) = vec_add( TH1,TL );

    TL  = vec_mulo( (vector unsigned char)tampon_4, (vector unsigned char)lowval);
    TH1 = vec_mulo( (vector unsigned char)tampon_4, (vector unsigned char)highval);
    TH2 = vec_mule( (vector unsigned char)tampon_4, (vector unsigned char)highval);
    TH1 = vec_add(TH1,TH2);
    TH1 = vec_sl( TH1, sixteen);

    RESULTAT( arg->result, i, 3, unsigned short ) = vec_add( TH1,TL );
  }
}

void  AVmulss16 ( CAMLG4_ARGUMENTS* arg )
{
  long nb_iter, i;

  register vector unsigned short  TL      , TH1      , TH2;
  register vector bool short      sign    , signv    , rsign;
  register vector signed short    T1      , tampon_1, tampon_2, tampon_3 , tampon_4;
  register vector signed short    value   , svalue  , T;
  register vector unsigned short  sixteen;
  signed short val;

  val    = *( (int*)(arg->vector2) );
  value  = generic_splat_s16( &val );

  sixteen = vec_splat_u16(-8);

  EVAL_VECTOR_SIZE( signed short );


  /*        ATTENTION GROSSE FEINTE !!      */
  /*                                        */
  /* A*B  = (sign(A)*sign(B))*abs(A)*abs(B) */
  /*                                        */
  /* C'est affreux mais ca  marche !        */

  signv = vec_cmpgt( s16_zero, value ); 

  value  = vec_sel( value, vec_sub(s16_zero,value), signv);
  svalue = vec_rl(value,sixteen);

  for( i = 0; i < nb_iter; ++i )
  {          
    LOAD_REGISTER( tampon_1, i, 0, signed short, arg->vector1 );
    LOAD_REGISTER( tampon_2, i, 1, signed short, arg->vector1 );
    LOAD_REGISTER( tampon_3, i, 2, signed short, arg->vector1 );
    LOAD_REGISTER( tampon_4, i, 3, signed short, arg->vector1 );

    sign     = vec_cmpgt( s16_zero, tampon_1 );
    rsign    = vec_xor( sign, signv );
    tampon_1 = vec_sel( tampon_1, vec_sub(s16_zero,tampon_1), sign );

    TL    = vec_mulo( (vector unsigned char)tampon_1, (vector unsigned char)value);
    TH1   = vec_mulo( (vector unsigned char)tampon_1, (vector unsigned char)svalue);
    TH2   = vec_mule( (vector unsigned char)tampon_1, (vector unsigned char)svalue);
    TH1   = vec_add(TH1,TH2);
    TH1   = vec_sl( TH1, sixteen);
    T     = (vector signed short)vec_add( TH1,TL );

    RESULTAT( arg->result, i, 0, signed short ) = vec_sel( T, vec_sub(s16_zero,T), rsign);       
  
    sign     = vec_cmpgt( s16_zero, tampon_1 );
    rsign    = vec_xor( sign, signv );
    tampon_1 = vec_sel( tampon_1, vec_sub(s16_zero,tampon_1), sign );

    TL    = vec_mulo( (vector unsigned char)tampon_2, (vector unsigned char)value);
    TH1   = vec_mulo( (vector unsigned char)tampon_2, (vector unsigned char)svalue);
    TH2   = vec_mule( (vector unsigned char)tampon_2, (vector unsigned char)svalue);
    TH1   = vec_add(TH1,TH2);
    TH1   = vec_sl( TH1, sixteen);
    T     = (vector signed short)vec_add( TH1,TL );

    RESULTAT( arg->result, i, 1, signed short ) = vec_sel( T, vec_sub(s16_zero,T), rsign);

    sign     = vec_cmpgt( s16_zero, tampon_1 );
    rsign    = vec_xor( sign, signv );
    tampon_1 = vec_sel( tampon_1, vec_sub(s16_zero,tampon_1), sign );

    TL    = vec_mulo( (vector unsigned char)tampon_3, (vector unsigned char)value);
    TH1   = vec_mulo( (vector unsigned char)tampon_3, (vector unsigned char)svalue);
    TH2   = vec_mule( (vector unsigned char)tampon_3, (vector unsigned char)svalue);
    TH1   = vec_add(TH1,TH2);
    TH1   = vec_sl( TH1, sixteen);
    T     = (vector signed short)vec_add( TH1,TL );

    RESULTAT( arg->result, i, 2, signed short ) = vec_sel( T, vec_sub(s16_zero,T), rsign);

    sign     = vec_cmpgt( s16_zero, tampon_1 );
    rsign    = vec_xor( sign, signv );
    tampon_1 = vec_sel( tampon_1, vec_sub(s16_zero,tampon_1), sign );

    TL    = vec_mulo( (vector unsigned char)tampon_4, (vector unsigned char)value);
    TH1   = vec_mulo( (vector unsigned char)tampon_4, (vector unsigned char)svalue);
    TH2   = vec_mule( (vector unsigned char)tampon_4, (vector unsigned char)svalue);
    TH1   = vec_add(TH1,TH2);
    TH1   = vec_sl( TH1, sixteen);
    T     = (vector signed short)vec_add( TH1,TL );

    RESULTAT( arg->result, i, 3, signed short ) = vec_sel( T, vec_sub(s16_zero,T), rsign); 
  }
}

void  AVmulss32 ( CAMLG4_ARGUMENTS* arg )
{
  long nb_iter, i;
  register vector float tampon1_1,tampon1_2,tampon1_3,tampon1_4;
  register vector float temp1    ,temp2    ,temp3    ,temp4;
  register vector float tampon2;
  register signed long  val;
           float        fval;

  val = *( (int*)(arg->vector2) );
  fval = (float)val;

  EVAL_VECTOR_SIZE( signed long );

  tampon2 = generic_splat_f32( &fval );

  for( i = 0; i < nb_iter; ++i )
  {     
    FLOAD_REGISTER( tampon1_1, i, 0, signed long, arg->vector1 );
    FLOAD_REGISTER( tampon1_2, i, 1, signed long, arg->vector1 );
    FLOAD_REGISTER( tampon1_3, i, 2, signed long, arg->vector1 );
    FLOAD_REGISTER( tampon1_4, i, 3, signed long, arg->vector1 );

    temp1 = vec_madd( tampon1_1, tampon2, f32_zero );
    temp2 = vec_madd( tampon1_2, tampon2, f32_zero );
    temp3 = vec_madd( tampon1_3, tampon2, f32_zero );
    temp4 = vec_madd( tampon1_4, tampon2, f32_zero );

    RESULTAT( arg->result, i, 0, long ) = vec_cts( temp1, 0 );
    RESULTAT( arg->result, i, 1, long ) = vec_cts( temp2, 0 );
    RESULTAT( arg->result, i, 2, long ) = vec_cts( temp3, 0 );
    RESULTAT( arg->result, i, 3, long ) = vec_cts( temp4, 0 );   
  }
}

void  AVmulsf32 ( CAMLG4_ARGUMENTS* arg )
{
  long nb_iter, i;
  register vector float tampon1_1,tampon1_2,tampon1_3,tampon1_4;
  register vector float tampon2;

  EVAL_VECTOR_SIZE( float );

  tampon2 = generic_splat_f32( (float*)(arg->vector2) );

  for( i = 0; i < nb_iter; ++i )
  {
    LOAD_REGISTER( tampon1_1, i, 0, float, arg->vector1 );
    LOAD_REGISTER( tampon1_2, i, 1, float, arg->vector1 );
    LOAD_REGISTER( tampon1_3, i, 2, float, arg->vector1 );
    LOAD_REGISTER( tampon1_4, i, 3, float, arg->vector1 );
    
    RESULTAT( arg->result, i, 0, float ) = vec_madd( tampon1_1, tampon2, f32_zero );
    RESULTAT( arg->result, i, 1, float ) = vec_madd( tampon1_2, tampon2, f32_zero );
    RESULTAT( arg->result, i, 2, float ) = vec_madd( tampon1_3, tampon2, f32_zero );
    RESULTAT( arg->result, i, 3, float ) = vec_madd( tampon1_4, tampon2, f32_zero );  
  }
}
