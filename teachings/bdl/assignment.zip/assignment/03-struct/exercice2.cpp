/*
  Exercise 2 - 2D array

  We want to implement a dynamically sized 2D array. We will store the 2D
  array as a standard dynamic array (1D contiguous storage). Given the width
  and height, the linear index n of an element at coordinates (i,j) is:

    n = i*width + j

  Q1 - Propose a structure `array2D` that follows this specification.

  Q2 - Overload the operator() to access the element at (i,j).

  Q3 - Overload the stream insertion operator so that you can print your
  2D arrays.

  Q4 - Provide a function that returns the sum of all elements in the array.

  Q5 - Implement member functions begin() and end() so that your structure
  can be used in range-based for loops.
*/

#include <iostream>

int main(int, char **) {}
