/*========================================================*/
/**
 * @file   camlg4.c
 * @author Joel FALCOU
 * @date   Fri May  3 13:51:36 2002
 * @brief Source de la bibliotheque CAMLG4.
 *
 *  Ce fichier source contient l'implementation 
 *  des fonctions de stubs de la bibliotheque 
 *  CAMLG4 qui seront exportees vers l'interface
 *  Objective Caml. 
 */
/*========================================================*/

#include <stdio.h>
#include <stdlib.h>

#include <caml/mlvalues.h>
#include <caml/memory.h>
#include <caml/fail.h>
#include <caml/bigarray.h>

#include "camlg4_internal.h"

#include "abs.h"
#include "add.h"
#include "sub.h"
#include "muls.h"
#include "mulv.h"

#include "approx.h"
#include "round.h"
#include "and.h"
#include "or.h"
#include "not.h"
#include "xor.h"
#include "nand.h"
#include "nor.h"

#include "svrl.h"
#include "fill.h"
            
/*========================================================*/
/**
 *   @brief Fonction Valeur Absolue.
 *
 *   Effectue le calcul de la valeur absolue des elements 
 *   du Array passe en argument.
 *
 *   @param v1 Parametre CAML representant le  Array
 *             a traiter.
 *
 *   @return Une <i>value</i> CAML contenant le resultat
 *           du calcul.
 */
/*========================================================*/

value  CAMLG4abs  ( value  v1 )
{
  int  type;
  long size;

  CAMLG4_ARGUMENTS arg;

  CAMLparam1( v1 );
  CAMLlocal1( output );

  size = Bigarray_val( v1 )->dim[0];
  type = Bigarray_val( v1 )->flags & BIGARRAY_KIND_MASK;

  if( size != 0 )
  {
    arg.vector1 = Data_bigarray_val( v1 );
    
    switch( type )
    {

    case BIGARRAY_SINT8   :  

      ALLOC_RESULT_ARRAY( size, signed char );
      AVabss8( &arg );
      break;

    case BIGARRAY_SINT16  :  

      ALLOC_RESULT_ARRAY( size, signed short );
      AVabss16( &arg );
      break;
      
    case BIGARRAY_INT32   :  

      ALLOC_RESULT_ARRAY( size, signed long );
      AVabss32( &arg );
      break;
	
    case BIGARRAY_FLOAT32 :  

      ALLOC_RESULT_ARRAY( size, float );
      AVabsf32( &arg );
      break;

    case  BIGARRAY_FLOAT64    :
    case  BIGARRAY_UINT8      :
    case  BIGARRAY_UINT16     :
    case  BIGARRAY_INT64      :
    case  BIGARRAY_CAML_INT   :
    case  BIGARRAY_NATIVE_INT :
    default                   :  

      failwith("Error in Array.Abs() - Unsupported Type.");
      break;
    }

      output =  alloc_bigarray_dims( type | BIGARRAY_C_LAYOUT, 1, arg.result, size); 
      
      CAMLreturn( output );
  }  
  else
  {
    CAMLreturn( v1 );
  }
}

/*========================================================*/
/**
 *   @brief Fonction d'addition vectorielle.
 *
 *   Effectue le calcul de l'addition  membre a membre
 *   des elements des deux Array passes en arguments.
 *
 *   @param v1 Parametre CAML representant le 1er Array
 *             a traiter.
 *   @param v2 Parametre CAML representant le 2e Array 
 *             a traiter.
 *
 *   @return Une <i>value</i> CAML contenant le resultat
 *           du calcul.
 */
/*========================================================*/

value  CAMLG4add  ( value  v1, value  v2 )
{
  int  type;
  long size_v1, size_v2;
   
  CAMLG4_ARGUMENTS arg;

  CAMLparam2( v1, v2 );
  CAMLlocal1( output );

  size_v1 = Bigarray_val( v1 )->dim[0];
  size_v2 = Bigarray_val( v2 )->dim[0];

  type = Bigarray_val( v1 )->flags & BIGARRAY_KIND_MASK;

  if( (size_v1 != 0) && (size_v2 != 0) )
  {
    if( size_v1 == size_v2 )
    {
      arg.vector1 = Data_bigarray_val( v1 );
      arg.vector2 = Data_bigarray_val( v2 );
             
      switch( type )
      {
      case BIGARRAY_SINT8   :  

	ALLOC_RESULT_ARRAY( size_v1, signed char );	
	AVadds8( &arg );
	break;
	
      case BIGARRAY_SINT16  :
	 
	ALLOC_RESULT_ARRAY( size_v1, signed short );
	AVadds16( &arg );
	
	 break;
      
      case  BIGARRAY_UINT8      :
	 
	ALLOC_RESULT_ARRAY( size_v1, unsigned char );
	 
	 AVaddu8( &arg );
	break;


      case  BIGARRAY_UINT16     :
		
	ALLOC_RESULT_ARRAY( size_v1, unsigned short );
	AVaddu16( &arg );
	break;

      case BIGARRAY_INT32  :
	
	ALLOC_RESULT_ARRAY( size_v1, signed long );
	AVadds32( &arg );
	break;
	
      case BIGARRAY_FLOAT32 :
	
	ALLOC_RESULT_ARRAY( size_v1, float );
	AVaddf32( &arg );
	break;

      case  BIGARRAY_FLOAT64    :
      case  BIGARRAY_INT64      :
      case  BIGARRAY_CAML_INT   :
      case  BIGARRAY_NATIVE_INT :
      default                   :  
	
	failwith("Error in Array.Add() - Unsupported Type.");
	break;
      }
      
      output =  alloc_bigarray_dims( type | BIGARRAY_C_LAYOUT, 1, arg.result, size_v1); 

      CAMLreturn( output );
    }  
    else
    {
      failwith( "Error in Array.Add() - Size do not match.");
    }
  }
  else
  {
    CAMLreturn( v1 );
  }
}

/*========================================================*/
/**
 *   @brief Fonction de soustraction vectorielle.
 *
 *   Effectue le calcul de la difference membre a membre
 *   des elements des deux Array passes en arguments.
 *
 *   @param v1 Parametre CAML representant le 1er Array
 *             a traiter.
 *   @param v2 Parametre CAML representant le 2e Array 
 *             a traiter.
 *
 *   @return Une <i>value</i> CAML contenant le resultat
 *           du calcul.
 */
/*========================================================*/

value  CAMLG4sub  ( value  v1, value  v2 )
{
  int  type;
  long size_v1, size_v2;

  CAMLG4_ARGUMENTS arg;

  CAMLparam2( v1, v2 );
  CAMLlocal1( output );

  size_v1 = Bigarray_val( v1 )->dim[0];
  size_v2 = Bigarray_val( v2 )->dim[0];

  type = Bigarray_val( v1 )->flags & BIGARRAY_KIND_MASK;

  if( (size_v1 != 0) && (size_v2 != 0) )
  {
    if( size_v1 == size_v2 )
    {
      arg.vector1 = Data_bigarray_val( v1 );
      arg.vector2 = Data_bigarray_val( v2 );
     
      switch( type )
      {
      case BIGARRAY_SINT8   :  
	
	ALLOC_RESULT_ARRAY( size_v1, signed char );
	AVsubs8( &arg );
	break;
	
      case BIGARRAY_SINT16  :
	
	ALLOC_RESULT_ARRAY( size_v1, signed short );
	AVsubs16( &arg );
	break;
      
      case  BIGARRAY_UINT8      :
	
	ALLOC_RESULT_ARRAY( size_v1, unsigned char );
	AVsubu8( &arg );
	break;

      case  BIGARRAY_UINT16     :
	
	ALLOC_RESULT_ARRAY( size_v1, unsigned short );
	AVaddu16( &arg );
	break;

      case BIGARRAY_INT32  :
	
	ALLOC_RESULT_ARRAY( size_v1, signed long );
	AVsubs32( &arg );
	break;
	
      case BIGARRAY_FLOAT32 :
	
	ALLOC_RESULT_ARRAY( size_v1, float );
	AVsubf32( &arg );
	break;

      case  BIGARRAY_FLOAT64    :
      case  BIGARRAY_INT64      :
      case  BIGARRAY_CAML_INT   :
      case  BIGARRAY_NATIVE_INT :
      default                   :  
	
	failwith("Error in Array.Sub() - Unsupported Type.");
	break;
      }
      
      output =  alloc_bigarray_dims( type | BIGARRAY_C_LAYOUT, 1, arg.result, size_v1); 
      
      CAMLreturn( output );
    }  
    else
    {
      failwith( "Error in Array.Sub() - Size do not match.");
    }
  }
  else
  {
    CAMLreturn( v1 );
  }
}

/*========================================================*/
/**
 *   @brief Fonction de multipication vectorielle.
 *
 *   Effectue le calcul du produit par un scalaire
 *   des elements du Array passe en argument.
 *
 *   @param v1 Parametre CAML representant le Array a 
 *             traiter.
 *   @param v2 Parametre CAML representant le facteur 
 *             scalaire de multiplication.
 *
 *   @return Une <i>value</i> CAML contenant le resultat
 *           du calcul.
 */
/*========================================================*/

value  CAMLG4muls  ( value  v1, value  v2 )
{
  int  type;
  long size,new_size;
  
  float f;
  long  l;
  
  CAMLG4_ARGUMENTS arg;
  
  CAMLparam2( v1, v2 );
  CAMLlocal1( output );

  size = Bigarray_val( v1 )->dim[0];  
  type = Bigarray_val( v1 )->flags & BIGARRAY_KIND_MASK;
  
  if( size != 0 )
  {
    arg.size    = size;
    arg.vector1 = Data_bigarray_val( v1 );
    
    if( type == BIGARRAY_FLOAT32 )
    {
      f = Double_val( v2 );
      arg.vector2 = &f; 
    }
    else
    {
      l = Long_val( v2 );
      arg.vector2 = &l;
    }

    switch( type )
    {
    
    case BIGARRAY_SINT8   :  
	
      ALLOC_RESULT_ARRAY( size, signed char );
      AVmulss8( &arg );
      break;
	
    case BIGARRAY_SINT16  :
	
      ALLOC_RESULT_ARRAY( size, signed short );
      AVmulss16( &arg );
      break;
      
    case  BIGARRAY_UINT8      :
	
      ALLOC_RESULT_ARRAY( size, unsigned char );
      AVmulsu8( &arg );
      break;

    case  BIGARRAY_UINT16     :
	
      ALLOC_RESULT_ARRAY( size, unsigned short );
      AVmulsu16( &arg );
      break;

    case BIGARRAY_INT32  :
	
      ALLOC_RESULT_ARRAY( size, signed long );
      AVmulss32( &arg );
      break;
	
    case BIGARRAY_FLOAT32 :
	
      ALLOC_RESULT_ARRAY( size, float );
      AVmulsf32( &arg );
      break;

    case  BIGARRAY_FLOAT64    :
    case  BIGARRAY_INT64      :
    case  BIGARRAY_CAML_INT   :
    case  BIGARRAY_NATIVE_INT :
    default                   :  
      
      failwith("Error in Array.Muls() - Unsupported Type.");
      break;
    }
      
    output =  alloc_bigarray_dims( type | BIGARRAY_C_LAYOUT, 1, arg.result, size); 
    
    CAMLreturn( output );
  }  
  else
  {
    CAMLreturn( v1 );
  }
}

/*========================================================*/
/**
 *   @brief Fonction de multipication vectorielle.
 *
 *   Effectue le calcul du produit points a points
 *   des elements des deux Array passes en arguments.
 *
 *   @param v1 Parametre CAML representant le 1e  
 *             Array a traiter.
 *   @param v2 Parametre CAML representant le  2e  
 *             Array a traiter.
 *
 *   @return Une <i>value</i> CAML contenant le resultat
 *           du calcul.
 */
/*========================================================*/

value  CAMLG4mulv  ( value  v1, value  v2 )
{
  int  type;
  long size_v1, size_v2;
  
  CAMLG4_ARGUMENTS arg;
  
  CAMLparam2( v1, v2 );
  CAMLlocal1( output );

  size_v1 = Bigarray_val( v1 )->dim[0];
  size_v2 = Bigarray_val( v2 )->dim[0];
  
  type = Bigarray_val( v1 )->flags & BIGARRAY_KIND_MASK;
 
  if( (size_v1 != 0) && (size_v2 != 0) )
  {
    if( size_v1 == size_v2 )
    {
      arg.size    = size_v1;
      arg.vector1 = Data_bigarray_val( v1 );
      arg.vector2 = Data_bigarray_val( v2 );
      
      switch( type )
      {

      case BIGARRAY_SINT8   :  
    
	ALLOC_RESULT_ARRAY( size_v1, signed char );
	AVmulvs8( &arg );
	break;
	
      case BIGARRAY_SINT16  :
	
	ALLOC_RESULT_ARRAY( size_v1, signed short );
	AVmulvs16( &arg );
	break;
      
      case  BIGARRAY_UINT8      :
	
	ALLOC_RESULT_ARRAY( size_v1, unsigned char );
	AVmulvu8( &arg );
	break;

      case  BIGARRAY_UINT16     :
	
	ALLOC_RESULT_ARRAY( size_v1, unsigned short );
	AVmulvu16( &arg );
	break;

      case BIGARRAY_INT32  :
	
	ALLOC_RESULT_ARRAY( size_v1, signed long );
	AVmulvs32( &arg );
	break;
	
      case BIGARRAY_FLOAT32 :
	
	ALLOC_RESULT_ARRAY( size_v1, float );
	AVmulvf32( &arg );
	break;

      case  BIGARRAY_FLOAT64    :
      case  BIGARRAY_INT64      :
      case  BIGARRAY_CAML_INT   :
      case  BIGARRAY_NATIVE_INT :
      default                   :  
	
	failwith("Error in Array.Mulv() - Unsupported Type.");
	break;
      }
      
      output =  alloc_bigarray_dims( type | BIGARRAY_C_LAYOUT, 1, arg.result, size_v1); 
      
      CAMLreturn( output );
    }  
    else
    {
      failwith( "Error in Array.Mulv() - Size do not match.");
    }
  }
  else
  {
    CAMLreturn( v1 );
  }
}

/*========================================================*/
/**
 *   @brief Fonction Arrondi.
 *
 *   Effectue le calcul de l'arrondi des elements 
 *   du Array passe en argument.
 *
 *   @param v1 Parametre CAML representant le  Array
 *             a traiter.
 *
 *   @return Une <i>value</i> CAML contenant le resultat
 *           du calcul.
 */
/*========================================================*/

value  CAMLG4round ( value v1 )
{
  int  type;
  long size;

  CAMLG4_ARGUMENTS arg;

  CAMLparam1( v1 );
  CAMLlocal1( output );

  size = Bigarray_val( v1 )->dim[0];
  type = Bigarray_val( v1 )->flags & BIGARRAY_KIND_MASK;

  if( size != 0 )
  {
    arg.vector1 = Data_bigarray_val( v1 );

    if( type == BIGARRAY_FLOAT32 )
    {
      ALLOC_RESULT_ARRAY( size, float );
      AVroundf32( &arg );
    }
    else
    {
      failwith("Error in Array.Round() - Unsupported Type.");
    }

    output =  alloc_bigarray_dims( BIGARRAY_FLOAT32 | BIGARRAY_C_LAYOUT, 1, arg.result, size); 

    CAMLreturn( output );
  }  
  else
  {
    CAMLreturn( v1 );
  }
 }

/*========================================================*/
/**
 *   @brief Fonction Troncature.
 *
 *   Effectue le calcul de la valeur tronquee des elements 
 *   du Array passe en argument.
 *
 *   @param v1 Parametre CAML representant le  Array
 *             a traiter.
 *
 *   @return Une <i>value</i> CAML contenant le resultat
 *           du calcul.
 */
/*========================================================*/

value  CAMLG4trunc ( value v1 )
{
  int  type;
  long size;

  CAMLG4_ARGUMENTS arg;

  CAMLparam1( v1 );
  CAMLlocal1( output );

  size = Bigarray_val( v1 )->dim[0];
  type = Bigarray_val( v1 )->flags & BIGARRAY_KIND_MASK;

  if( size != 0 )
  {
    arg.vector1 = Data_bigarray_val( v1 );

    if( type == BIGARRAY_FLOAT32 )
    {
      ALLOC_RESULT_ARRAY( size, float );
      AVtruncf32( &arg );
    }
    else
    {
      failwith("Error in Array.Trunc() - Unsupported Type.");
    }

    output =  alloc_bigarray_dims( BIGARRAY_FLOAT32 | BIGARRAY_C_LAYOUT, 1, arg.result, size); 

    CAMLreturn( output );
  }  
  else
  {
    CAMLreturn( v1 );
  }
}

/*========================================================*/
/**
 *   @brief Fonction Plafond
 *
 *   Effectue le calcul de la valeur plafond des elements 
 *   du Array passe en argument.
 *
 *   @param v1 Parametre CAML representant le  Array
 *             a traiter.
 *
 *   @return Une <i>value</i> CAML contenant le resultat
 *           du calcul.
 */
/*========================================================*/

value  CAMLG4ceil  ( value v1 )
{
  int  type;
  long size;

  CAMLG4_ARGUMENTS arg;

  CAMLparam1( v1 );
  CAMLlocal1( output );

  size = Bigarray_val( v1 )->dim[0];
  type = Bigarray_val( v1 )->flags & BIGARRAY_KIND_MASK;

  if( size != 0 )
  {
    arg.vector1 = Data_bigarray_val( v1 );

    if( type == BIGARRAY_FLOAT32 )
    {
      ALLOC_RESULT_ARRAY( size, float );
      AVceilf32( &arg );
    }
    else
    {
      failwith("Error in Array.Ceil() - Unsupported Type.");
    }

    output =  alloc_bigarray_dims( BIGARRAY_FLOAT32 | BIGARRAY_C_LAYOUT, 1, arg.result, size); 

    CAMLreturn( output );
  }  
  else
  {
    CAMLreturn( v1 );
  }
}

/*========================================================*/
/**
 *   @brief Fonction Plancher.
 *
 *   Effectue le calcul de la valeur plancher des elements 
 *   du Array passe en argument.
 *
 *   @param v1 Parametre CAML representant le  Array
 *             a traiter.
 *
 *   @return Une <i>value</i> CAML contenant le resultat
 *           du calcul.
 */
/*========================================================*/

value  CAMLG4floor ( value v1 )
{
  int  type;
  long size;

  CAMLG4_ARGUMENTS arg;

  CAMLparam1( v1 );
  CAMLlocal1( output );

  size = Bigarray_val( v1 )->dim[0];
  type = Bigarray_val( v1 )->flags & BIGARRAY_KIND_MASK;

  if( size != 0 )
  {
    arg.vector1 = Data_bigarray_val( v1 );

    if( type == BIGARRAY_FLOAT32 )
    {
      ALLOC_RESULT_ARRAY( size, float );
      AVfloorf32( &arg );
    }
    else
    {
      failwith("Error in Array.Floor() - Unsupported Type.");
    }

    output =  alloc_bigarray_dims( BIGARRAY_FLOAT32 | BIGARRAY_C_LAYOUT, 1, arg.result, size); 

    CAMLreturn( output );
  }  
  else
  {
    CAMLreturn( v1 );
  }
}

/*========================================================*/
/**
 *   @brief Fonction Inverse.
 *
 *   Effectue le calcul de l'inverse des elements 
 *   du Array passe en argument.
 *
 *   @param v1 Parametre CAML representant le  Array
 *             a traiter.
 *
 *   @return Une <i>value</i> CAML contenant le resultat
 *           du calcul.
 */
/*========================================================*/

value  CAMLG4rec     ( value v1 )
{
  int  type;
  long size,new_size;

  CAMLG4_ARGUMENTS arg;

  CAMLparam1( v1 );
  CAMLlocal1( output );

  size = Bigarray_val( v1 )->dim[0];
  type = Bigarray_val( v1 )->flags & BIGARRAY_KIND_MASK;

  if( size != 0 )
  {
    arg.vector1 = Data_bigarray_val( v1 );

    if( type == BIGARRAY_FLOAT32 )
    {
      ALLOC_RESULT_ARRAY( size, float );
      AVrecf32( &arg );
    }
    else
    {
      failwith("Error in Array.Rec() - Unsupported Type.");
    }

    output =  alloc_bigarray_dims( BIGARRAY_FLOAT32 | BIGARRAY_C_LAYOUT, 1, arg.result, size); 

    CAMLreturn( output );
  }  
  else
  {
    CAMLreturn( v1 );
  }
}

/*========================================================*/
/**
 *   @brief Fonction Racine Carre Inverse.
 *
 *   Effectue le calcul de l'inverse de la racine carre
 *   des elements du Array passe en argument.
 *
 *   @param v1 Parametre CAML representant le  Array
 *             a traiter.
 *
 *   @return Une <i>value</i> CAML contenant le resultat
 *           du calcul.
 */
/*========================================================*/

value  CAMLG4recsqrt ( value v1 )
{
  int  type;
  long size;

  CAMLG4_ARGUMENTS arg;

  CAMLparam1( v1 );
  CAMLlocal1( output );

  size = Bigarray_val( v1 )->dim[0];
  type = Bigarray_val( v1 )->flags & BIGARRAY_KIND_MASK;

  if( size != 0 )
  {
    arg.vector1 = Data_bigarray_val( v1 );

    if( type == BIGARRAY_FLOAT32 )
    {
      ALLOC_RESULT_ARRAY( size, float );
      AVrecsqrtf32( &arg );
    }
    else
    {
      failwith("Error in Array.RecSqrt() - Unsupported Type.");
    }

    output =  alloc_bigarray_dims( BIGARRAY_FLOAT32 | BIGARRAY_C_LAYOUT, 1, arg.result, size); 

    CAMLreturn( output );
  }  
  else
  {
    CAMLreturn( v1 );
  }
}

/*========================================================*/
/**
 *   @brief Fonction ET Logique.
 *
 *   Effectue un ET logique sur les elements des Array
 *   passes en argument.
 *
 *   @param v1 Parametre CAML representant le  Array
 *             a traiter.
 *
 *   @param v2 Parametre CAML representant le  Array
 *             a traiter.
 *
 *   @return Une <i>value</i> CAML contenant le resultat
 *           du calcul.
 */
/*========================================================*/

value  CAMLG4and  ( value  v1, value  v2 )
{
  int  type;
  long size_v1, size_v2;

  CAMLG4_ARGUMENTS arg;

  CAMLparam2( v1, v2 );
  CAMLlocal1( output );

  size_v1 = Bigarray_val( v1 )->dim[0];
  size_v2 = Bigarray_val( v2 )->dim[0];

  type = Bigarray_val( v1 )->flags & BIGARRAY_KIND_MASK;

  if( (size_v1 != 0) && (size_v2 != 0) )
  {
    if( size_v1 == size_v2 )
    {
      arg.vector1 = Data_bigarray_val( v1 );
      arg.vector2 = Data_bigarray_val( v2 );
      
      switch( type )
      {

      case BIGARRAY_SINT8   :  
	
	ALLOC_RESULT_ARRAY( size_v1, signed char );
	AVands8( &arg );
	break;
	
      case BIGARRAY_SINT16  :
	
	ALLOC_RESULT_ARRAY( size_v1, signed short );
	AVands16( &arg );
	break;
      
      case  BIGARRAY_UINT8      :
	
	ALLOC_RESULT_ARRAY( size_v1, unsigned char );
	AVandu8( &arg );
	break;


      case  BIGARRAY_UINT16     :
		
	ALLOC_RESULT_ARRAY( size_v1, unsigned short );
	AVandu16( &arg );
	break;

      case BIGARRAY_INT32  :
		
	ALLOC_RESULT_ARRAY( size_v1, signed long );
	AVands32( &arg );
	break;
	
      case  BIGARRAY_FLOAT32    :
      case  BIGARRAY_FLOAT64    :
      case  BIGARRAY_INT64      :
      case  BIGARRAY_CAML_INT   :
      case  BIGARRAY_NATIVE_INT :
      default                   :  
	
	failwith("Error in Array.And() - Unsupported Type.");
	break;
      }
      
      output =  alloc_bigarray_dims( type | BIGARRAY_C_LAYOUT, 1, arg.result, size_v1); 
      
      CAMLreturn( output );
    }  
    else
    {
      failwith( "Error in Array.And() - Size do not match.");
    }
  }
  else
  {
    CAMLreturn( v1 );
  }
}

/*========================================================*/
/**
 *   @brief Fonction OU Logique.
 *
 *   Effectue un OU logique sur les elements des Array
 *   passes en argument.
 *
 *   @param v1 Parametre CAML representant le  Array
 *             a traiter.
 *
 *   @param v2 Parametre CAML representant le  Array
 *             a traiter.
 *
 *   @return Une <i>value</i> CAML contenant le resultat
 *           du calcul.
 */
/*========================================================*/

value  CAMLG4or  ( value  v1, value  v2 )
{
  int  type;
  long size_v1, size_v2;

  CAMLG4_ARGUMENTS arg;

  CAMLparam2( v1, v2 );
  CAMLlocal1( output );

  size_v1 = Bigarray_val( v1 )->dim[0];
  size_v2 = Bigarray_val( v2 )->dim[0];

  type = Bigarray_val( v1 )->flags & BIGARRAY_KIND_MASK;

  if( (size_v1 != 0) && (size_v2 != 0) )
  {
    if( size_v1 == size_v2 )
    {
      arg.vector1 = Data_bigarray_val( v1 );
      arg.vector2 = Data_bigarray_val( v2 );
      
      switch( type )
      {
      case BIGARRAY_SINT8   :  
		
	ALLOC_RESULT_ARRAY( size_v1, signed char);
	AVors8( &arg );
	break;
	
      case BIGARRAY_SINT16  :
			
	ALLOC_RESULT_ARRAY( size_v1, signed short );      
	AVors16( &arg );
	break;
      
      case  BIGARRAY_UINT8      :
		
	ALLOC_RESULT_ARRAY( size_v1, unsigned char );
	AVoru8( &arg );
	break;


      case  BIGARRAY_UINT16     :
		
	ALLOC_RESULT_ARRAY( size_v1, unsigned short );
	AVoru16( &arg );
	break;

      case BIGARRAY_INT32  :
		
	ALLOC_RESULT_ARRAY( size_v1, signed long );
	AVors32( &arg );
	break;
	
      case  BIGARRAY_FLOAT32    :
      case  BIGARRAY_FLOAT64    :
      case  BIGARRAY_INT64      :
      case  BIGARRAY_CAML_INT   :
      case  BIGARRAY_NATIVE_INT :
      default                   :  
	
	failwith("Error in Array.Or() - Unsupported Type.");
	break;
      }
      
      output =  alloc_bigarray_dims( type | BIGARRAY_C_LAYOUT, 1, arg.result, size_v1); 
      
      CAMLreturn( output );
    }  
    else
    {
      failwith( "Error in Array.Or() - Size do not match.");
    }
  }
  else
  {
    CAMLreturn( v1 );
  }
}

/*========================================================*/
/**
 *   @brief Fonction OU EXCLUSIF Logique.
 *
 *   Effectue un XOR logique sur les elements des Array
 *   passes en argument.
 *
 *   @param v1 Parametre CAML representant le  Array
 *             a traiter.
 *
 *   @param v2 Parametre CAML representant le  Array
 *             a traiter.
 *
 *   @return Une <i>value</i> CAML contenant le resultat
 *           du calcul.
 */
/*========================================================*/


value  CAMLG4xor  ( value  v1, value  v2 )
{
  int  type;
  long size_v1, size_v2;

  CAMLG4_ARGUMENTS arg;

  CAMLparam2( v1, v2 );
  CAMLlocal1( output );

  size_v1 = Bigarray_val( v1 )->dim[0];
  size_v2 = Bigarray_val( v2 )->dim[0];

  type = Bigarray_val( v1 )->flags & BIGARRAY_KIND_MASK;

  if( (size_v1 != 0) && (size_v2 != 0) )
  {
    if( size_v1 == size_v2 )
    {
      arg.vector1 = Data_bigarray_val( v1 );
      arg.vector2 = Data_bigarray_val( v2 );
      
      switch( type )
      {
      case BIGARRAY_SINT8   :  
		
	ALLOC_RESULT_ARRAY( size_v1, signed char );
	AVxors8( &arg );
	break;
	
      case BIGARRAY_SINT16  :
			
	ALLOC_RESULT_ARRAY( size_v1, signed short );
	AVxors16( &arg );
	break;
      
      case  BIGARRAY_UINT8      :
		
	ALLOC_RESULT_ARRAY( size_v1, unsigned char );
	AVxoru8( &arg );
	break;


      case  BIGARRAY_UINT16     :
		
	ALLOC_RESULT_ARRAY( size_v1, unsigned short );
	AVxoru16( &arg );
	break;

      case BIGARRAY_INT32  :
		
	ALLOC_RESULT_ARRAY( size_v1, signed long );
	AVxors32( &arg );
	break;
	
      case  BIGARRAY_FLOAT32    :
      case  BIGARRAY_FLOAT64    :
      case  BIGARRAY_INT64      :
      case  BIGARRAY_CAML_INT   :
      case  BIGARRAY_NATIVE_INT :
      default                   :  
	
	failwith("Error in Array.Xor() - Unsupported Type.");
	break;
      }
      
      output =  alloc_bigarray_dims( type | BIGARRAY_C_LAYOUT, 1, arg.result, size_v1); 
      
      CAMLreturn( output );
    }  
    else
    {
      failwith( "Error in Array.Xor() - Size do not match.");
    }
  }
  else
  {
    CAMLreturn( v1 );
  }
}

/*========================================================*/
/**
 *   @brief Fonction NON Logique.
 *
 *   Effectue un NON logique sur les elements du Array
 *   passe en argument.
 *
 *   @param v1 Parametre CAML representant le  Array
 *             a traiter.
 *
 *   @return Une <i>value</i> CAML contenant le resultat
 *           du calcul.
 */
/*========================================================*/


value  CAMLG4not  ( value  v1 )
{
  int  type;
  long size;

  CAMLG4_ARGUMENTS arg;

  CAMLparam1( v1 );
  CAMLlocal1( output );

  size = Bigarray_val( v1 )->dim[0];
  type = Bigarray_val( v1 )->flags & BIGARRAY_KIND_MASK;

  if( size != 0 )
  {
    arg.vector1 = Data_bigarray_val( v1 );

    switch( type )
    {
    case BIGARRAY_SINT8   :  
      
      ALLOC_RESULT_ARRAY( size, signed char );
      AVnots8( &arg );
      break;

    case BIGARRAY_SINT16  :
      
      ALLOC_RESULT_ARRAY( size, signed short );
      AVnots16( &arg );
      break;
      

    case  BIGARRAY_UINT8  :
      
      ALLOC_RESULT_ARRAY( size, unsigned char );
      AVnotu8( &arg );
      break;
	
    case  BIGARRAY_UINT16 :
      
      ALLOC_RESULT_ARRAY( size, unsigned short );
      AVnotu16( &arg );
      break;
	
    case BIGARRAY_INT32  :
      
      ALLOC_RESULT_ARRAY( size, signed long );
      AVnots32( &arg );
      break;
	
    case BIGARRAY_FLOAT32     :
    case  BIGARRAY_FLOAT64    :
    case  BIGARRAY_INT64      :
    case  BIGARRAY_CAML_INT   :
    case  BIGARRAY_NATIVE_INT :
    default                   :  

      failwith("Error in Array.Not() - Unsupported Type.");
      break;
    }

    output =  alloc_bigarray_dims( type | BIGARRAY_C_LAYOUT, 1, arg.result, size); 

    CAMLreturn( output );
  }  
  else
  {
    CAMLreturn( v1 );
  }
}

/*========================================================*/
/**
 *   @brief Fonction NON ET Logique.
 *
 *   Effectue un NON ET logique sur les elements des Array
 *   passes en argument.
 *
 *   @param v1 Parametre CAML representant le  Array
 *             a traiter.
 *
 *   @param v2 Parametre CAML representant le  Array
 *             a traiter.
 *
 *   @return Une <i>value</i> CAML contenant le resultat
 *           du calcul.
 */
/*========================================================*/

value  CAMLG4nand  ( value  v1, value  v2 )
{
  int  type;
  long size_v1, size_v2;

  CAMLG4_ARGUMENTS arg;

  CAMLparam2( v1, v2 );
  CAMLlocal1( output );

  size_v1 = Bigarray_val( v1 )->dim[0];
  size_v2 = Bigarray_val( v2 )->dim[0];

  type = Bigarray_val( v1 )->flags & BIGARRAY_KIND_MASK;

  if( (size_v1 != 0) && (size_v2 != 0) )
  {
    if( size_v1 == size_v2 )
    {
      arg.vector1 = Data_bigarray_val( v1 );
      arg.vector2 = Data_bigarray_val( v2 );
      
      switch( type )
      {
      case BIGARRAY_SINT8   :  
	
	ALLOC_RESULT_ARRAY( size_v1, signed char );
	AVnands8( &arg );
	break;
	
      case BIGARRAY_SINT16  :
	
	ALLOC_RESULT_ARRAY( size_v1, signed short );
	AVnands16( &arg );
	break;
      
      case  BIGARRAY_UINT8      :
	
	ALLOC_RESULT_ARRAY( size_v1, unsigned char );
	AVnandu8( &arg );
	break;


      case  BIGARRAY_UINT16     :
	
	ALLOC_RESULT_ARRAY( size_v1, signed short );
	AVnandu16( &arg );
	break;

      case BIGARRAY_INT32  :
	
	ALLOC_RESULT_ARRAY( size_v1, signed long );
	AVnands32( &arg );
	break;
	
      case  BIGARRAY_FLOAT32    :
      case  BIGARRAY_FLOAT64    :
      case  BIGARRAY_INT64      :
      case  BIGARRAY_CAML_INT   :
      case  BIGARRAY_NATIVE_INT :
      default                   :  
	
	failwith("Error in Array.Nand() - Unsupported Type.");
	break;
      }
      
      output =  alloc_bigarray_dims( type | BIGARRAY_C_LAYOUT, 1, arg.result, size_v1); 
      
      CAMLreturn( output );
    }  
    else
    {
      failwith( "Error in Array.Nand() - Size do not match.");
    }
  }
  else
  {
    CAMLreturn( v1 );
  }
}

/*========================================================*/
/**
 *   @brief Fonction NON OU Logique.
 *
 *   Effectue un NON OU logique sur les elements des Array
 *   passes en argument.
 *
 *   @param v1 Parametre CAML representant le  Array
 *             a traiter.
 *
 *   @param v2 Parametre CAML representant le  Array
 *             a traiter.
 *
 *   @return Une <i>value</i> CAML contenant le resultat
 *           du calcul.
 */
/*========================================================*/

value  CAMLG4nor  ( value  v1, value  v2 )
{
  int  type;
  long size_v1, size_v2;

  CAMLG4_ARGUMENTS arg;

  CAMLparam2( v1, v2 );
  CAMLlocal1( output );

  size_v1 = Bigarray_val( v1 )->dim[0];
  size_v2 = Bigarray_val( v2 )->dim[0];

  type = Bigarray_val( v1 )->flags & BIGARRAY_KIND_MASK;

  if( (size_v1 != 0) && (size_v2 != 0) )
  {
    if( size_v1 == size_v2 )
    {
      arg.vector1 = Data_bigarray_val( v1 );
      arg.vector2 = Data_bigarray_val( v2 );
    
      switch( type )
      {
      case BIGARRAY_SINT8   :  
	
	ALLOC_RESULT_ARRAY( size_v1, signed char );
	AVnors8( &arg );
	break;
	
      case BIGARRAY_SINT16  :
	
	ALLOC_RESULT_ARRAY( size_v1, signed short );
	AVnors16( &arg );
	break;
      
      case  BIGARRAY_UINT8      :
	
	ALLOC_RESULT_ARRAY( size_v1, unsigned char );
	AVnoru8( &arg );
	break;


      case  BIGARRAY_UINT16     :
	
	ALLOC_RESULT_ARRAY( size_v1, unsigned short );
	AVnoru16( &arg );
	break;

      case BIGARRAY_INT32  :
	
	ALLOC_RESULT_ARRAY( size_v1, signed long );
	AVnors32( &arg );
	break;
	
      case  BIGARRAY_FLOAT32    :
      case  BIGARRAY_FLOAT64    :
      case  BIGARRAY_INT64      :
      case  BIGARRAY_CAML_INT   :
      case  BIGARRAY_NATIVE_INT :
      default                   :  
	
	failwith("Error in Array.Nor() - Unsupported Type.");
	break;
      }
      
      output =  alloc_bigarray_dims( type | BIGARRAY_C_LAYOUT, 1, arg.result, size_v1); 
      
      CAMLreturn( output );
    }  
    else
    {
      failwith( "Error in Array.Nor() - Size do not match.");
    }
  }
  else
  {
    CAMLreturn( v1 );
  }
}

/*========================================================*/
/**
 *   @brief Fonction de d�calage d'�l�ments.
 *
 *   D�cale tous les �l�ments du tableau d'un certain nombre
 *   de position au sein du tableau vers la gauche.
 *
 *   @param v1 Parametre CAML representant le Array a 
 *             traiter.
 *   @param v2 Parametre CAML representant le facteur 
 *             de d�calage.
 *
 *   @return Une <i>value</i> CAML contenant le resultat
 *           du calcul.
 */
/*========================================================*/

value  CAMLG4shiftleft( value  v1, value  v2 )
{
  int  type;
  long size, new_size, l;
  
  CAMLG4_ARGUMENTS arg;
  
  CAMLparam2( v1, v2 );
  CAMLlocal1( output );

  size = Bigarray_val( v1 )->dim[0];  
  type = Bigarray_val( v1 )->flags & BIGARRAY_KIND_MASK;
  
  l = Long_val( v2 );

  if( size != 0 && l != 0)
  {
    arg.size    = size;
    arg.vector1 = Data_bigarray_val( v1 );
    arg.vector2 = &l;

    switch( type )
    {
    
    case BIGARRAY_SINT8   :  
	
      ALLOC_RESULT_ARRAY( size, signed char );
      AVsvls8( &arg );
      break;
	
    case BIGARRAY_SINT16  :
	
      ALLOC_RESULT_ARRAY( size, signed short );
      AVsvls16( &arg );
      break;
      
    case  BIGARRAY_UINT8      :
	
      ALLOC_RESULT_ARRAY( size, unsigned char );
      AVsvlu8( &arg );
      break;


    case  BIGARRAY_UINT16     :
	
      ALLOC_RESULT_ARRAY( size, unsigned short );
      AVsvlu16( &arg );
      break;

    case BIGARRAY_INT32  :
	
      ALLOC_RESULT_ARRAY( size, signed long );
      AVsvls32( &arg );
      break;
	
    case  BIGARRAY_FLOAT32    :
    case  BIGARRAY_FLOAT64    :
    case  BIGARRAY_INT64      :
    case  BIGARRAY_CAML_INT   :
    case  BIGARRAY_NATIVE_INT :
    default                   :  
      
	
      failwith("Error in Array.svl() - Unsupported Type.");
      break;
    }
      
    output =  alloc_bigarray_dims( type | BIGARRAY_C_LAYOUT, 1, arg.result, size); 
    
    CAMLreturn( output );
  }  
  else
  {
    CAMLreturn( v1 );
  }
}


/*========================================================*/
/**
 *   @brief Fonction de d�calage d'�l�ments.
 *
 *   D�cale tous les �l�ments du tableau d'un certain nombre
 *   de position au sein du tableau vers la droite.
 *
 *   @param v1 Parametre CAML representant le Array a 
 *             traiter.
 *   @param v2 Parametre CAML representant le facteur 
 *             de d�calage.
 *
 *   @return Une <i>value</i> CAML contenant le resultat
 *           du calcul.
 */
/*========================================================*/

value  CAMLG4shiftright( value  v1, value  v2 )
{
  int  type;
  long size, new_size, l;
  
  CAMLG4_ARGUMENTS arg;
  
  CAMLparam2( v1, v2 );
  CAMLlocal1( output );

  size = Bigarray_val( v1 )->dim[0];  
  type = Bigarray_val( v1 )->flags & BIGARRAY_KIND_MASK;
  
  l = Long_val( v2 );

  if( size != 0 && l != 0)
  {
    arg.size    = size;
    arg.vector1 = Data_bigarray_val( v1 );
    arg.vector2 = &l;

    switch( type )
    {
    
    case BIGARRAY_SINT8   :  
	
      ALLOC_RESULT_ARRAY( size, signed char );
      AVsvrs8( &arg );
      break;
	
    case BIGARRAY_SINT16  :
	
      ALLOC_RESULT_ARRAY( size, signed short );
      AVsvrs16( &arg );
      break;
      
    case  BIGARRAY_UINT8      :
	
      ALLOC_RESULT_ARRAY( size, unsigned char );
      AVsvru8( &arg );
      break;


    case  BIGARRAY_UINT16     :
	
      ALLOC_RESULT_ARRAY( size, unsigned short );
      AVsvru16( &arg );
      break;

    case BIGARRAY_INT32  :
	
      ALLOC_RESULT_ARRAY( size, signed long );
      AVsvrs32( &arg );
      break;
	
    case  BIGARRAY_FLOAT32    :
    case  BIGARRAY_FLOAT64    :
    case  BIGARRAY_INT64      :
    case  BIGARRAY_CAML_INT   :
    case  BIGARRAY_NATIVE_INT :
    default                   :  
      
	
      failwith("Error in Array.svr() - Unsupported Type.");
      break;
    }
      
    output =  alloc_bigarray_dims( type | BIGARRAY_C_LAYOUT, 1, arg.result, size); 
    
    CAMLreturn( output );
  }  
  else
  {
    CAMLreturn( v1 );
  }
}

/*========================================================*/
/**
 *   @brief Fonction de remplissage de tableau.
 *
 *   Remplis un tableau par une constante.
 *
 *   @param v1 Parametre CAML representant le Array a 
 *             traiter.
 *   @param v2 Parametre CAML representant la constante
 *             � utiliser
 *
 *   @return Une <i>value</i> CAML contenant le resultat
 *           du calcul.
 */
/*========================================================*/

void  CAMLG4fill ( value  v1, value  v2 )
{
  int  type;
  long size, new_size, l;
  float f;

  CAMLG4_ARGUMENTS arg;
  
  CAMLparam2( v1, v2 );
  CAMLlocal1( output );

  size = Bigarray_val( v1 )->dim[0];  
  type = Bigarray_val( v1 )->flags & BIGARRAY_KIND_MASK;
  
  if( size != 0 )
  {
    arg.size    = size;
    arg.vector1 = Data_bigarray_val( v1 );

    if( type == BIGARRAY_FLOAT32 )
    {
      f = Double_val( v2 );
      arg.vector2 = &f;
    }
    else
    {
      l = Long_val( v2 );
      arg.vector2 = &l;
    }

    switch( type )
    {
    
    case BIGARRAY_SINT8   :  
	
      AVfills8( &arg );
      break;
	
    case BIGARRAY_SINT16  :
	
      AVfills16( &arg );
      break;
      
    case  BIGARRAY_UINT8      :
	
      AVfillu8( &arg );
      break;


    case  BIGARRAY_UINT16     :
	
      AVfillu16( &arg );
      break;

    case BIGARRAY_INT32  :
	
      AVfills32( &arg );
      break;
	
    case BIGARRAY_FLOAT32 :
	
      AVfillf32( &arg );
      break;

    case  BIGARRAY_FLOAT64    :
    case  BIGARRAY_INT64      :
    case  BIGARRAY_CAML_INT   :
    case  BIGARRAY_NATIVE_INT :
    default                   :  
      	
      failwith("Error in Array.Fill() - Unsupported Type.");
      break;
    }
  }  
}

/*========================================================*/
/**
 *   @brief Fonction de d�calage bit � bit � droite.
 *
 *   Effectue le d�calage bit � bit des �l�ments d'un Array.
 *
 *   @param v1 Parametre CAML representant le Array a 
 *             traiter.
 *   @param v2 Parametre CAML representant le facteur 
 *             de d�calage.
 *
 *   @return Une <i>value</i> CAML contenant le resultat
 *           du calcul.
 */
/*========================================================*/

value  CAMLG4sr  ( value  v1, value  v2 )
{
  int  type;
  long size,new_size;
  
  float f;
  long  l;
  
  CAMLG4_ARGUMENTS arg;
  
  CAMLparam2( v1, v2 );
  CAMLlocal1( output );

  size = Bigarray_val( v1 )->dim[0];  
  type = Bigarray_val( v1 )->flags & BIGARRAY_KIND_MASK;
  
  if( size != 0 )
  {
    arg.size    = size;
    arg.vector1 = Data_bigarray_val( v1 );
    
    if( type == BIGARRAY_FLOAT32 )
    {
      f = Double_val( v2 );
      arg.vector2 = &f; 
    }
    else
    {
      l = Long_val( v2 );
      arg.vector2 = &l;
    }

    switch( type )
    {
    
    case BIGARRAY_SINT8   :  
	
      ALLOC_RESULT_ARRAY( size, signed char );
      AVshiftrights8( &arg );
      break;
	
    case BIGARRAY_SINT16  :
	
      ALLOC_RESULT_ARRAY( size, signed short );
      AVshiftrights16( &arg );
      break;
      
    case  BIGARRAY_UINT8      :
	
      ALLOC_RESULT_ARRAY( size, unsigned char );
      AVshiftrightu8( &arg );
      break;

    case  BIGARRAY_UINT16     :
	
      ALLOC_RESULT_ARRAY( size, unsigned short );
      AVshiftrightu16( &arg );
      break;

    case BIGARRAY_INT32  :
	
      ALLOC_RESULT_ARRAY( size, signed long );
      AVshiftrights32( &arg );
      break;
	
    case  BIGARRAY_FLOAT32    :
    case  BIGARRAY_FLOAT64    :
    case  BIGARRAY_INT64      :
    case  BIGARRAY_CAML_INT   :
    case  BIGARRAY_NATIVE_INT :
    default                   :  
      
      failwith("Error in Array.sr() - Unsupported Type.");
      break;
    }
      
    output =  alloc_bigarray_dims( type | BIGARRAY_C_LAYOUT, 1, arg.result, size); 
    
    CAMLreturn( output );
  }  
  else
  {
    CAMLreturn( v1 );
  }
}

/*========================================================*/
/**
 *   @brief Fonction de d�calage bit � bit � gauche.
 *
 *   Effectue le d�calage bit � bit des �l�ments d'un Array.
 *
 *   @param v1 Parametre CAML representant le Array a 
 *             traiter.
 *   @param v2 Parametre CAML representant le facteur 
 *             de d�calage.
 *
 *   @return Une <i>value</i> CAML contenant le resultat
 *           du calcul.
 */
/*========================================================*/

value  CAMLG4sl  ( value  v1, value  v2 )
{
  int  type;
  long size,new_size;
  
  float f;
  long  l;
  
  CAMLG4_ARGUMENTS arg;
  
  CAMLparam2( v1, v2 );
  CAMLlocal1( output );

  size = Bigarray_val( v1 )->dim[0];  
  type = Bigarray_val( v1 )->flags & BIGARRAY_KIND_MASK;
  
  if( size != 0 )
  {
    arg.size    = size;
    arg.vector1 = Data_bigarray_val( v1 );
    
    if( type == BIGARRAY_FLOAT32 )
    {
      f = Double_val( v2 );
      arg.vector2 = &f; 
    }
    else
    {
      l = Long_val( v2 );
      arg.vector2 = &l;
    }

    switch( type )
    {
    
    case BIGARRAY_SINT8   :  
	
      ALLOC_RESULT_ARRAY( size, signed char );
      AVshiftlefts8( &arg );
      break;
	
    case BIGARRAY_SINT16  :
	
      ALLOC_RESULT_ARRAY( size, signed short );
      AVshiftlefts16( &arg );
      break;
      
    case  BIGARRAY_UINT8      :
	
      ALLOC_RESULT_ARRAY( size, unsigned char );
      AVshiftleftu8( &arg );
      break;

    case  BIGARRAY_UINT16     :
	
      ALLOC_RESULT_ARRAY( size, unsigned short );
      AVshiftleftu16( &arg );
      break;

    case BIGARRAY_INT32  :
	
      ALLOC_RESULT_ARRAY( size, signed long );
      AVshiftlefts32( &arg );
      break;
	
    case  BIGARRAY_FLOAT32    :
    case  BIGARRAY_FLOAT64    :
    case  BIGARRAY_INT64      :
    case  BIGARRAY_CAML_INT   :
    case  BIGARRAY_NATIVE_INT :
    default                   :  
      
      failwith("Error in Array.sl() - Unsupported Type.");
      break;
    }
      
    output =  alloc_bigarray_dims( type | BIGARRAY_C_LAYOUT, 1, arg.result, size); 
    
    CAMLreturn( output );
  }  
  else
  {
    CAMLreturn( v1 );
  }
}

/*========================================================*/
/**
 *   @brief Fonction de masquage.
 *
 *   Effectue le masquage des �l�ments d'un Array par une valeur.
 *
 *   @param v1 Parametre CAML representant le Array a 
 *             traiter.
 *   @param v2 Parametre CAML representant le pas de masquage 
 *           
 *   @param v3 Parametre CAML representant la valeur masquante.
 *
 *
 *   @return Une <i>value</i> CAML contenant le resultat
 *           du calcul.
 */
/*========================================================*/

value  CAMLG4maskodd  ( value  v1, value  v2, value v3 )
{
  int  type;
  int  step;
  int  l;
  float f;
  long size,new_size;
  
  CAMLG4_ARGUMENTS arg;
  
  CAMLparam3( v1, v2, v3 );
  CAMLlocal1( output );

  size = Bigarray_val( v1 )->dim[0];  
  type = Bigarray_val( v1 )->flags & BIGARRAY_KIND_MASK;
  
  if( size != 0 )
  {
    arg.size    = size;
    arg.vector1 = Data_bigarray_val( v1 );
    
    if( type == BIGARRAY_FLOAT32 )
    {
      f = Double_val( v3 );
      arg.vector3 = &f; 
    }
    else
    {
      l = Long_val( v3 );
      arg.vector3 = &l;
    }

    step = Long_val(v2);
    arg.vector2 = &step;
   
    switch( type )
    {
    
    case BIGARRAY_SINT8   :  
	
      ALLOC_RESULT_ARRAY( size, signed char );
      AVmask_odds8( &arg );
      break;
	
    case BIGARRAY_SINT16  :
	
      ALLOC_RESULT_ARRAY( size, signed short );
      AVmask_odds16( &arg );
      break;
      
    case  BIGARRAY_UINT8      :
	
      ALLOC_RESULT_ARRAY( size, unsigned char );
      AVmask_oddu8( &arg );
      break;

    case  BIGARRAY_UINT16     :
	
      ALLOC_RESULT_ARRAY( size, unsigned short );
      AVmask_oddu16( &arg );
      break;

    case BIGARRAY_INT32  :
	
      ALLOC_RESULT_ARRAY( size, signed long );
      AVmask_odds32( &arg );
      break;
	
    case  BIGARRAY_FLOAT32    :
    case  BIGARRAY_FLOAT64    :
    case  BIGARRAY_INT64      :
    case  BIGARRAY_CAML_INT   :
    case  BIGARRAY_NATIVE_INT :
    default                   :  
      
      failwith("Error in Array.mask_odd() - Unsupported Type.");
      break;
    }
      
    output =  alloc_bigarray_dims( type | BIGARRAY_C_LAYOUT, 1, arg.result, size); 
    
    CAMLreturn( output );
  }  
  else
  {
    CAMLreturn( v1 );
  }
}

/*========================================================*/
/**
 *   @brief Fonction de masquage.
 *
 *   Effectue le masquage des �l�ments d'un Array par une valeur.
 *
 *   @param v1 Parametre CAML representant le Array a 
 *             traiter.
 *   @param v2 Parametre CAML representant le pas de masquage 
 *           
 *   @param v3 Parametre CAML representant la valeur masquante.
 *
 *
 *   @return Une <i>value</i> CAML contenant le resultat
 *           du calcul.
 */
/*========================================================*/

value  CAMLG4maskeven  ( value  v1, value  v2, value v3 )
{
  int  type;
  int  step;
  int  l;
  float f;
  long size,new_size;
  
  CAMLG4_ARGUMENTS arg;
  
  CAMLparam3( v1, v2, v3 );
  CAMLlocal1( output );

  size = Bigarray_val( v1 )->dim[0];  
  type = Bigarray_val( v1 )->flags & BIGARRAY_KIND_MASK;
  
  if( size != 0 )
  {
    arg.size    = size;
    arg.vector1 = Data_bigarray_val( v1 );
    
    if( type == BIGARRAY_FLOAT32 )
    {
      f = Double_val( v3 );
      arg.vector3 = &f; 
    }
    else
    {
      l = Long_val( v3 );
      arg.vector3 = &l;
    }

    step = Long_val(v2);
    arg.vector2 = &step;
   
    switch( type )
    {
    
    case BIGARRAY_SINT8   :  
	
      ALLOC_RESULT_ARRAY( size, signed char );
      AVmask_evens8( &arg );
      break;
	
    case BIGARRAY_SINT16  :
	
      ALLOC_RESULT_ARRAY( size, signed short );
      AVmask_evens16( &arg );
      break;
      
    case  BIGARRAY_UINT8      :
	
      ALLOC_RESULT_ARRAY( size, unsigned char );
      AVmask_evenu8( &arg );
      break;

    case  BIGARRAY_UINT16     :
	
      ALLOC_RESULT_ARRAY( size, unsigned short );
      AVmask_evenu16( &arg );
      break;

    case BIGARRAY_INT32  :
	
      ALLOC_RESULT_ARRAY( size, signed long );
      AVmask_evens32( &arg );
      break;
	
    case  BIGARRAY_FLOAT32    :
    case  BIGARRAY_FLOAT64    :
    case  BIGARRAY_INT64      :
    case  BIGARRAY_CAML_INT   :
    case  BIGARRAY_NATIVE_INT :
    default                   :  
      
      failwith("Error in Array.mask_even() - Unsupported Type.");
      break;
    }
      
    output =  alloc_bigarray_dims( type | BIGARRAY_C_LAYOUT, 1, arg.result, size); 
    
    CAMLreturn( output );
  }  
  else
  {
    CAMLreturn( v1 );
  }
}
