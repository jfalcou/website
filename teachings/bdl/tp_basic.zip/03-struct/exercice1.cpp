/*
  Exercice 1 - Fraction

  Fournissez une implémentation d'une structure fraction représentant un nombre
  fractionnaire. Vous implémenterez sous forme de fonction ou d'opérateur
  surchargés les fonctionnalités suivantes:

  - addition fraction/fraction, entier/fraction, fraction/entier
  - soustraction fraction/fraction, entier/fraction, fraction/entier
  - multiplication fraction/fraction, entier/fraction, fraction/entier
  - division fraction/fraction, entier/fraction, fraction/entier
  - négation de fraction
  - conversion de la fraction en nombre réel double précision
  - insertion et extraction depuis un flux
*/

#include <iostream>

int main(int, char **) {}
