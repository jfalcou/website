# APP4 - C++ - TP 7


## Exercice principal

Le sujet est donné dans `TP7 APP4.pdf`


## Exercices bonus

1) bigint
2) compression


- [Explication de std::move sur StackOverflow](https://stackoverflow.com/questions/3413470/what-is-stdmove-and-when-should-it-be-used)
