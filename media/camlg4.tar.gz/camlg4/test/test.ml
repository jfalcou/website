open Vecarray;;

let a = create ints8 10;;

fill a 2;;

let b = sr a 12;;
let c = sl a 21;;
let result = add b c;;

let result = add a c;;

for i=0 to 9 do Printf.printf "a[%d] = %d\n" i (get result i) done;;

 