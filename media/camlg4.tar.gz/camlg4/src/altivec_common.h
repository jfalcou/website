#ifndef __ALTIVEC_COMMON_H_
#define __ALTIVEC_COMMON_H_

#define u8_zero   (vector unsigned char ) vec_splat_u8(0x00)
#define u8_one    (vector unsigned char ) vec_splat_u8(0x01)

#define s8_zero   (vector signed char ) vec_splat_u8(0x00)
#define s8_one    (vector signed char ) vec_splat_u8(0x01)

#define s16_zero   (vector signed short ) vec_splat_s16(0x00)
#define s16_one    (vector signed short ) vec_splat_s16(0x01)

#define u16_zero   (vector unsigned short ) vec_splat_u16(0x00)
#define u16_one    (vector unsigned short ) vec_splat_u16(0x01)

#define u32_zero   (vector unsigned int ) vec_splat_u32(0x00)
#define u32_one    (vector unsigned int ) vec_splat_u32(0x01)

#define s32_zero   (vector signed int ) vec_splat_s32(0x00)
#define s32_one    (vector signed int ) vec_splat_s32(0x01)

#define f32_zero   (vector float ) vec_ctf(vec_splat_s32(0x00),0)
#define f32_one    (vector float ) vec_ctf(vec_splat_s32(0x01),0)

// one scalar variable  -> same type vector 

vector unsigned char generic_splat_u8(unsigned char* k); 
vector signed char generic_splat_s8(signed char* k);
vector unsigned short generic_splat_u16(unsigned short* k); 
vector signed short generic_splat_s16(signed short* k);
vector unsigned int generic_splat_u32(unsigned long* k);
vector signed int generic_splat_s32(signed long* k);
vector float generic_splat_f32(float* k);


#endif

