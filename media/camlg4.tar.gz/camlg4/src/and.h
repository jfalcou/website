/*========================================================*/
/**
 * @file   and.h
 * @author Joel FALCOU
 * @date   Tue May 14 13:33:30 2002
 * 
 * @brief  En-tete de and.c
 * 
 * Ce fichier definit les fonctions Et Logique 
 * vectorielle implementees dans and.c
 */
/*========================================================*/

#ifndef __AND_H__INCLUDED__
#define __AND_H__INCLUDED__

void  AVandu8  ( CAMLG4_ARGUMENTS* arg );
void  AVands8  ( CAMLG4_ARGUMENTS* arg );
void  AVandu16 ( CAMLG4_ARGUMENTS* arg );
void  AVands16 ( CAMLG4_ARGUMENTS* arg );
void  AVands32 ( CAMLG4_ARGUMENTS* arg );

#endif
