 /*========================================================*/
/**
 * @file   nand.h
 * @author Joel FALCOU
 * @date   Tue May 14 13:33:30 2002
 * 
 * @brief  En-tete de nand.c
 * 
 * Ce fichier definit les fonctions Non Et Logique 
 * vectorielle implementees dans nand.c
 */
/*========================================================*/

#ifndef __NAND_H__INCLUDED__
#define __NAND_H__INCLUDED__

void  AVnandu8  ( CAMLG4_ARGUMENTS* arg );
void  AVnands8  ( CAMLG4_ARGUMENTS* arg );
void  AVnandu16 ( CAMLG4_ARGUMENTS* arg );
void  AVnands16 ( CAMLG4_ARGUMENTS* arg );
void  AVnands32 ( CAMLG4_ARGUMENTS* arg );

#endif
