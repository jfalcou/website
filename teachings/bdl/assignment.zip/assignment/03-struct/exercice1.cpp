/*
  Exercise 1 - Fraction

  Provide an implementation of a struct representing a fraction (rational
  number). Implement the following operations as functions or overloaded
  operators:

  - addition: fraction/fraction, integer/fraction, fraction/integer
  - subtraction: fraction/fraction, integer/fraction, fraction/integer
  - multiplication: fraction/fraction, integer/fraction, fraction/integer
  - division: fraction/fraction, integer/fraction, fraction/integer
  - negation of a fraction
  - conversion of a fraction to a double-precision floating-point number
  - stream insertion and extraction (compatibility with std::cout and std::cin)
*/

#include <iostream>

int main(int, char **) {}
