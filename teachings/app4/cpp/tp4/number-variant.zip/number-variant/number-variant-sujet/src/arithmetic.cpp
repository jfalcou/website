#include "arithmetic.hpp"

#include "types.hpp"

// Define arithmetic operators for number_t here

/*...Fill in here ...*/


// ===
// Arithmetic operators for fraction_t
// ===

// ---
// fraction & fraction

// Define operators here:
/*...Fill in here ...*/

// ---
// fraction_t & int - ints are converted to fraction_t

fraction_t operator+(fraction_t const &f, int const &d) {
  return f + fraction_t{d, 1.};
}

fraction_t operator-(fraction_t const &f, int const &d) {
  return f - fraction_t{d, 1.};
}

fraction_t operator*(fraction_t const &f, int const &d) {
  return f * fraction_t{d, 1.};
}

fraction_t operator/(fraction_t const &f, int const &d) {
  return f / fraction_t{d, 1.};
}

fraction_t operator+(int const &d, fraction_t const &f) {
  return fraction_t{d, 1.} + f;
}

fraction_t operator-(int const &d, fraction_t const &f) {
  return fraction_t{d, 1.} - f;
}

fraction_t operator*(int const &d, fraction_t const &f) {
  return fraction_t{d, 1.} * f;
}

fraction_t operator/(int const &d, fraction_t const &f) {
  return fraction_t{d, 1.} / f;
}

// ---
// fraction_t & std::complex<double> - Fraction_t values are converted to double

std::complex<double> operator+(fraction_t const &f,
                               std::complex<double> const &c) {
  return double(f) + c;
}

std::complex<double> operator-(fraction_t const &f,
                               std::complex<double> const &c) {
  return double(f) - c;
}

std::complex<double> operator*(fraction_t const &f,
                               std::complex<double> const &c) {
  return double(f) * c;
}

std::complex<double> operator/(fraction_t const &f,
                               std::complex<double> const &c) {
  return double(f) / c;
}

std::complex<double> operator+(std::complex<double> const &c,
                               fraction_t const &f) {
  return c + double(f);
}

std::complex<double> operator-(std::complex<double> const &c,
                               fraction_t const &f) {
  return c - double(f);
}

std::complex<double> operator*(std::complex<double> const &c,
                               fraction_t const &f) {
  return c * double(f);
}

std::complex<double> operator/(std::complex<double> const &c,
                               fraction_t const &f) {
  return c / double(f);
}
