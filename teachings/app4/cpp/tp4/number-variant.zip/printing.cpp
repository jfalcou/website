#include "printing.hpp"

#include "types.hpp"

#include <variant>

// We provide operator<< for fraction_t. Note that we return a *reference* to a std::ostream.
std::ostream &operator<<(std::ostream &o, fraction_t const &n) {
  return o << n.n << '/' << n.d;
}

// Implement std::ostream &operator<<(std::ostream &o, number_t const &n) with std::visit.

/*...Fill in here ...*/
