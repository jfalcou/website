/*========================================================*/
/**
 * @file   shiftleft.h
 * @author Joel FALCOU
 * @date   Tue May 14 13:33:30 2002
 * 
 * @brief  En-tete de shiftleft.c
 * 
 * Ce fichier definit les fonctions de d�calages
 * bit � bit vectoriels implementees dans shiftleft.c
 */
/*========================================================*/

#ifndef __SHIFTLEFT_H__INCLUDED__
#define __SHIFTLEFT_H__INCLUDED__

void  AVshiftleftu8  ( CAMLG4_ARGUMENTS* arg );
void  AVshiftlefts8  ( CAMLG4_ARGUMENTS* arg );
void  AVshiftleftu16 ( CAMLG4_ARGUMENTS* arg );
void  AVshiftlefts16 ( CAMLG4_ARGUMENTS* arg );
void  AVshiftlefts32 ( CAMLG4_ARGUMENTS* arg );
void  AVshiftleftf32 ( CAMLG4_ARGUMENTS* arg );

#endif
