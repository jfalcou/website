#pragma once

#include <type_traits>

/// FR | Fonctionne comme unique_ptr, mais permet de faire une copie d'objet.
/// EN | Works like unique_ptr, with the addition of copy semantics.
/// http://en.cppreference.com/w/cpp/memory/unique_ptr
template <class T> class copy_ptr {
private:
  /// FR | Le pointeur lui-meme
  /// EN | The pointer itself
  T *ptr_;

public:
  /// FR | Implementez le destructeur.
  /// EN | Implement the destructor.

  /* A compléter... */

  /// [FR]
  /// Constructeur par pointeur de type T*. La valeur doit etre soit nullptr,
  /// soit un pointeur vers une valeur deja allouee.

  /// [EN]
  /// Constructor by pointer of type T*. Value must be either nullptr,
  /// or a pointer to a pre-allocated value.
  
  /* A compléter... */

  copy_ptr() noexcept : ptr_(nullptr) {}

  // Constructeurs (move et copy) | Constructors (move and copy)

  // Transfert | Move:
  /* A compléter... */

  // Copie | Copy
  /* A compléter... */

  // operator= (move & copy)

  // Transfert | Move
  /* A compléter... */

  // Copie | Copy
  /* A compléter... */

  /// FR | Echange le pointeur de l'objet avec celui d'other.
  /// EN | Swap the pointer held by the object with other's.
  /* A compléter... */

  /// FR | Renvoie true si le pointeur tient une valeur, sinon false.
  /// EN | Returns true if the pointer holds a value, otherwise false.
  /* A compléter... */


  /// FR | Renvoie le pointeur vers la ressource.
  /// EN | Returns a pointer to the resource.
  /* A compléter... */


  /// [FR]
  /// Renvoie une reference vers la ressource. Permet de "depointer" la valeur,
  /// comme avec un pointeur normal.
  ///
  /// [EN]
  /// Returns a reference to the resource. This allows "depointing" a value,
  /// just like a regular pointer.
  /* A compléter... */


  /// [FR]
  /// Indirection, permet d'utiliser la fleche, comme avec un pointeur normal.
  ///
  /// [EN]
  /// Indirection, allows the arrow thing, just like a regular pointer.
  /* A compléter... */
  
};
