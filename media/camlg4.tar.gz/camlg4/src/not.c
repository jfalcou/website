/*========================================================*/
/**
 * @file   not.c
 * @author Joel FALCOU 
 * @date   Wed May 15 16:24:02 2002
 * 
 * @brief  source de not.h
 * 
 * Ce fichier implemente les fonctions de Non Logique
 * vectoriel.
 *
 */
/*========================================================*/

#include <stdio.h>
#include <stdlib.h>

#include "camlg4_internal.h"
#include "altivec_common.h"
#include "not.h"

void  AVnots8  ( CAMLG4_ARGUMENTS* arg )
{
  long nb_iter, i;
  register vector signed char tampon_1, tampon_2, tampon_3, tampon_4;
  register vector signed char vrai;
                  signed char true;

  true = 0xFF;
  vrai = generic_splat_s8( &true );

  EVAL_VECTOR_SIZE( signed char );

  for( i = 0; i < nb_iter; ++i )
  {
    LOAD_REGISTER( tampon_1, i, 0, signed char, arg->vector1 );
    LOAD_REGISTER( tampon_2, i, 1, signed char, arg->vector1 );
    LOAD_REGISTER( tampon_3, i, 2, signed char, arg->vector1 );
    LOAD_REGISTER( tampon_4, i, 3, signed char, arg->vector1 );
    
    RESULTAT( arg->result, i, 0, signed char ) = vec_andc( vrai, tampon_1 );
    RESULTAT( arg->result, i, 1, signed char ) = vec_andc( vrai, tampon_2 );
    RESULTAT( arg->result, i, 2, signed char ) = vec_andc( vrai, tampon_3 );
    RESULTAT( arg->result, i, 3, signed char ) = vec_andc( vrai, tampon_4 );   
  }
}

void  AVnotu8 ( CAMLG4_ARGUMENTS* arg )
{
  long nb_iter, i;
  register vector unsigned char tampon_1, tampon_2, tampon_3, tampon_4;
  register vector unsigned char vrai;
                  unsigned char true;

  true = 0xFF;
  vrai = generic_splat_u8( &true );

  EVAL_VECTOR_SIZE( unsigned char );

  for( i = 0; i < nb_iter; ++i )
  {
    LOAD_REGISTER( tampon_1, i, 0, unsigned char, arg->vector1 );
    LOAD_REGISTER( tampon_2, i, 1, unsigned char, arg->vector1 );
    LOAD_REGISTER( tampon_3, i, 2, unsigned char, arg->vector1 );
    LOAD_REGISTER( tampon_4, i, 3, unsigned char, arg->vector1 );
    
    RESULTAT( arg->result, i, 0, unsigned char ) = vec_andc( vrai, tampon_1 );
    RESULTAT( arg->result, i, 1, unsigned char ) = vec_andc( vrai, tampon_2 );
    RESULTAT( arg->result, i, 2, unsigned char ) = vec_andc( vrai, tampon_3 );
    RESULTAT( arg->result, i, 3, unsigned char ) = vec_andc( vrai, tampon_4 );   
  }
}

void  AVnots16 ( CAMLG4_ARGUMENTS* arg )
{
  long nb_iter, i;
  register vector signed short tampon_1, tampon_2, tampon_3, tampon_4;
  register vector signed short vrai;
                  signed short true;

  true = 0xFFFF;
  vrai = generic_splat_s16( &true );

  EVAL_VECTOR_SIZE( signed short );

  for( i = 0; i < nb_iter; ++i )
  {
    LOAD_REGISTER( tampon_1, i, 0, signed short, arg->vector1 );
    LOAD_REGISTER( tampon_2, i, 1, signed short, arg->vector1 );
    LOAD_REGISTER( tampon_3, i, 2, signed short, arg->vector1 );
    LOAD_REGISTER( tampon_4, i, 3, signed short, arg->vector1 );
    
    RESULTAT( arg->result, i, 0, signed short ) = vec_andc( vrai, tampon_1 );
    RESULTAT( arg->result, i, 1, signed short ) = vec_andc( vrai, tampon_2 );
    RESULTAT( arg->result, i, 2, signed short ) = vec_andc( vrai, tampon_3 );
    RESULTAT( arg->result, i, 3, signed short ) = vec_andc( vrai, tampon_4 );   
  }
}

void  AVnotu16 ( CAMLG4_ARGUMENTS* arg )
{
  long nb_iter, i;
  register vector unsigned short tampon_1, tampon_2, tampon_3, tampon_4;
  register vector unsigned short vrai;
                  unsigned short true;

  true = 0xFFFF;
  vrai = generic_splat_u16( &true );

  EVAL_VECTOR_SIZE( unsigned short );

  for( i = 0; i < nb_iter; ++i )
  {
    LOAD_REGISTER( tampon_1, i, 0, unsigned short, arg->vector1 );
    LOAD_REGISTER( tampon_2, i, 1, unsigned short, arg->vector1 );
    LOAD_REGISTER( tampon_3, i, 2, unsigned short, arg->vector1 );
    LOAD_REGISTER( tampon_4, i, 3, unsigned short, arg->vector1 );
    
    RESULTAT( arg->result, i, 0, unsigned short ) = vec_andc( vrai, tampon_1 );
    RESULTAT( arg->result, i, 1, unsigned short ) = vec_andc( vrai, tampon_2 );
    RESULTAT( arg->result, i, 2, unsigned short ) = vec_andc( vrai, tampon_3 );
    RESULTAT( arg->result, i, 3, unsigned short ) = vec_andc( vrai, tampon_4 );   
  }
}

void  AVnots32 ( CAMLG4_ARGUMENTS* arg )
{
  long nb_iter, i;
  register vector signed long tampon_1, tampon_2, tampon_3, tampon_4;
  register vector signed long vrai;
                  signed long true;

  true = 0xFFFFFFFF;
  vrai = generic_splat_s32( &true );

  EVAL_VECTOR_SIZE( signed long );

  for( i = 0; i < nb_iter; ++i )
  {
    LOAD_REGISTER( tampon_1, i, 0, signed long, arg->vector1 );
    LOAD_REGISTER( tampon_2, i, 1, signed long, arg->vector1 );
    LOAD_REGISTER( tampon_3, i, 2, signed long, arg->vector1 );
    LOAD_REGISTER( tampon_4, i, 3, signed long, arg->vector1 );
    
    RESULTAT( arg->result, i, 0, signed long ) = vec_andc( vrai, tampon_1 );
    RESULTAT( arg->result, i, 1, signed long ) = vec_andc( vrai, tampon_2 );
    RESULTAT( arg->result, i, 2, signed long ) = vec_andc( vrai, tampon_3 );
    RESULTAT( arg->result, i, 3, signed long ) = vec_andc( vrai, tampon_4 );   
  }
}
