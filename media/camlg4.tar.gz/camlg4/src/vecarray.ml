(*********************************************************)
(*                                                       *)
(*                   Objective Caml                      *)
(*                                                       *)
(*             Joel FALCOU pour le LASMEA                *)
(*                                                       *)
(*   Module CAMLG4 : Interfacage AltiVec-Objective Caml  *)
(*                                                       *)
(*********************************************************)

(*********************************************************)
(*                                                       *)
(*                Declaration de type                    *)
(*                                                       *)
(*********************************************************)

type ('a, 'b) t = ('a, 'b, Bigarray.c_layout) Bigarray.Array1.t
type ('a, 'b) p = ('a, 'b) Bigarray.kind

let float32 = Bigarray.float32
let ints8   = Bigarray.int8_signed
let intu8   = Bigarray.int8_unsigned
let ints16  = Bigarray.int16_signed
let intu16  = Bigarray.int16_unsigned
let int32   = Bigarray.int32

(*********************************************************)
(*                                                       *)
(*                    Fonction CAML                      *)
(*                                                       *)
(*********************************************************)

let create content dim =  Bigarray.Array1.create content Bigarray.c_layout dim 

let dim v =  Bigarray.Array1.dim v

let get a x =  Bigarray.Array1.get a x

let set a x v =  Bigarray.Array1.set a x v

let of_array k a =  Bigarray.Array1.of_array k Bigarray.c_layout a

let map_file f k b n =  Bigarray.Array1.map_file f k Bigarray.c_layout b n

(*********************************************************)
(*                                                       *)
(*                 Fonction Externes                     *)
(*                                                       *)
(*********************************************************)

(*********************************************************)
(*                                                       *)
(*               Calculs Arithmetiques                   *)
(*                                                       *)
(*********************************************************)

external add   : ('a, 'b) t -> ('a, 'b) t -> ('a, 'b) t = "CAMLG4add"
external sub   : ('a, 'b) t -> ('a, 'b) t -> ('a, 'b) t = "CAMLG4sub"
external scale : ('a, 'b) t -> 'a         -> ('a, 'b) t = "CAMLG4muls"
external mult  : ('a, 'b) t -> ('a, 'b) t -> ('a, 'b) t = "CAMLG4mulv"
external vabs  : ('a, 'b) t -> ('a, 'b) t               = "CAMLG4abs"

(*********************************************************)
(*                                                       *)
(*                 Operations Logiques                   *)
(*                                                       *)
(*********************************************************)

external andl  : ('a, 'b) t -> ('a, 'b) t -> ('a, 'b) t = "CAMLG4and"
external orl   : ('a, 'b) t -> ('a, 'b) t -> ('a, 'b) t = "CAMLG4or"
external xorl  : ('a, 'b) t -> ('a, 'b) t -> ('a, 'b) t = "CAMLG4xor"
external nandl : ('a, 'b) t -> ('a, 'b) t -> ('a, 'b) t = "CAMLG4nand"
external norl  : ('a, 'b) t -> ('a, 'b) t -> ('a, 'b) t = "CAMLG4nor"
external notl  : ('a, 'b) t -> ('a, 'b) t               = "CAMLG4not"

(*********************************************************)
(*                                                       *)
(*                 Calculs sur Flottants                 *)
(*                                                       *)
(*********************************************************)

external  round   : ('a, 'b) t -> ('a, 'b) t = "CAMLG4round"
external  trunc   : ('a, 'b) t -> ('a, 'b) t = "CAMLG4trunc"
external  ceil    : ('a, 'b) t -> ('a, 'b) t = "CAMLG4ceil"
external  floor   : ('a, 'b) t -> ('a, 'b) t = "CAMLG4floor"
external  inv     : ('a, 'b) t -> ('a, 'b) t = "CAMLG4rec"
external  invsqrt : ('a, 'b) t -> ('a, 'b) t = "CAMLG4recsqrt"

(*********************************************************)
(*                                                       *)
(*                Gestion des tableaux                   *)
(*                                                       *)
(*********************************************************)

external  sr:        ('a, 'b) t -> 'a -> ('a,'b) t        = "CAMLG4sr"
external  sl:        ('a, 'b) t -> 'a -> ('a,'b) t        = "CAMLG4sl"
external  svl:       ('a, 'b) t -> int -> ('a, 'b) t      = "CAMLG4shiftleft"
external  svr:       ('a, 'b) t -> int -> ('a, 'b) t      = "CAMLG4shiftright"
external  fill:      ('a, 'b) t -> 'a -> unit             = "CAMLG4fill"
external  mask_odd : ('a, 'b) t -> int -> 'a -> ('a,'b) t = "CAMLG4maskodd"
external  mask_even: ('a, 'b) t -> int -> 'a -> ('a,'b) t = "CAMLG4maskeven"
