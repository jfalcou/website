/*========================================================*/
/**
 * @file   fill.c
 * @author Joel FALCOU
 * @date   Tue July 14 13:23:13 2002
 * 
 * @brief  Source de fill.h
 * 
 * Ce fichier contient le code des differentes versions
 * de l'op�ration de remplissage de tableaux.
 *
 */
/*========================================================*/

#include <stdio.h>
#include <stdlib.h>

#include "camlg4_internal.h"
#include "altivec_common.h"
#include "fill.h"

void AVfillu8( CAMLG4_ARGUMENTS* arg )
{
  register vector unsigned char tampon1, tampon2, tampon3, tampon4;
  register vector unsigned char pattern;

  unsigned char value;
  long i,nb_iter;

  EVAL_VECTOR_SIZE( unsigned char );

  value = *((int*)(arg->vector2));
  pattern = generic_splat_u8( &value );

  for( i = 0; i < nb_iter; i ++ )
  {      
    RESULTAT( arg->vector1, i, 0, unsigned char ) = pattern;
    RESULTAT( arg->vector1, i, 1, unsigned char ) = pattern;
    RESULTAT( arg->vector1, i, 2, unsigned char ) = pattern;
    RESULTAT( arg->vector1, i, 3, unsigned char ) = pattern;  
  }
}

void AVfills8( CAMLG4_ARGUMENTS* arg )
{
  register vector signed char tampon1, tampon2, tampon3, tampon4;
  register vector signed char pattern;

  signed char value;
  long i,nb_iter;

  EVAL_VECTOR_SIZE( signed char );

  value = *((int*)(arg->vector2));
  pattern = generic_splat_s8( &value );

  for( i = 0; i < nb_iter; i ++ )
  {
    RESULTAT( arg->vector1, i, 0, signed char ) = pattern;
    RESULTAT( arg->vector1, i, 1, signed char ) = pattern;
    RESULTAT( arg->vector1, i, 2, signed char ) = pattern;
    RESULTAT( arg->vector1, i, 3, signed char ) = pattern;  
  }
}

void AVfillu16( CAMLG4_ARGUMENTS* arg )
{
  register vector unsigned short tampon1, tampon2, tampon3, tampon4;
  register vector unsigned short pattern;

  unsigned short value;
  long i,nb_iter;

  EVAL_VECTOR_SIZE( unsigned short );

  value = *((int*)(arg->vector2));
  pattern = generic_splat_u16( &value );

  for( i = 0; i < nb_iter; i ++ )
  {
    RESULTAT( arg->vector1, i, 0, unsigned short ) = pattern;
    RESULTAT( arg->vector1, i, 1, unsigned short ) = pattern;
    RESULTAT( arg->vector1, i, 2, unsigned short ) = pattern;
    RESULTAT( arg->vector1, i, 3, unsigned short ) = pattern;  
  }
}

void AVfills16( CAMLG4_ARGUMENTS* arg )
{
  register vector signed short tampon1, tampon2, tampon3, tampon4;
  register vector signed short pattern;

  signed short value;
  long i,nb_iter;

  EVAL_VECTOR_SIZE( signed short );

  value = *((int*)(arg->vector2));
  pattern = generic_splat_s16( &value );

  for( i = 0; i < nb_iter; i ++ )
  {
    RESULTAT( arg->vector1, i, 0, signed short ) = pattern;
    RESULTAT( arg->vector1, i, 1, signed short ) = pattern;
    RESULTAT( arg->vector1, i, 2, signed short ) = pattern;
    RESULTAT( arg->vector1, i, 3, signed short ) = pattern;  
  }
}

void AVfills32( CAMLG4_ARGUMENTS* arg )
{
  register vector signed long tampon1, tampon2, tampon3, tampon4;
  register vector signed long pattern;

  signed long value;
  long i,nb_iter;

  EVAL_VECTOR_SIZE( signed long );

  value = *((int*)(arg->vector2));
  pattern = generic_splat_s32( &value );

  for( i = 0; i < nb_iter; i ++ )
  {
    RESULTAT( arg->vector1, i, 0, signed long ) = pattern;
    RESULTAT( arg->vector1, i, 1, signed long ) = pattern;
    RESULTAT( arg->vector1, i, 2, signed long ) = pattern;
    RESULTAT( arg->vector1, i, 3, signed long ) = pattern;  
  }
}

void AVfillf32( CAMLG4_ARGUMENTS* arg )
{
  register vector float tampon1, tampon2, tampon3, tampon4;
  register vector float pattern;

  float value;
  long i,nb_iter;

  EVAL_VECTOR_SIZE( float );

  value = *((float*)(arg->vector2));
  pattern = generic_splat_f32( &value );

  for( i = 0; i < nb_iter; i ++ )
  {
    RESULTAT( arg->vector1, i, 0, float ) = pattern;
    RESULTAT( arg->vector1, i, 1, float ) = pattern;
    RESULTAT( arg->vector1, i, 2, float ) = pattern;
    RESULTAT( arg->vector1, i, 3, float ) = pattern;  
  }
}
