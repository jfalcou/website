/*========================================================*/
/**
 * @file   shiftleft.c
 * @author Joel FALCOU
 * @date   Tue May 14 13:37:13 2002
 * 
 * @brief  Source de shiftleft.h
 * 
 * Ce fichier contient le code des differentes versions
 * du decalage bit � bit � gauche.
 *
 */
/*========================================================*/

#include <stdio.h>
#include <stdlib.h>

#include "camlg4_internal.h"
#include "altivec_common.h"
#include "shiftleft.h"

void  AVshiftleftu8  ( CAMLG4_ARGUMENTS* arg )
{
  long  nb_iter, i;
  register vector unsigned char  tampon1 , tampon2 , tampon3 , tampon4;
  register vector unsigned char  value;
  unsigned char val;

  EVAL_VECTOR_SIZE( unsigned char );

  val = *( (int*)(arg->vector2) );
  value = generic_splat_u8( &val );

  for( i = 0; i < nb_iter; ++i )
  {      
    LOAD_REGISTER( tampon1, i, 0, unsigned char, arg->vector1 );
    LOAD_REGISTER( tampon2, i, 1, unsigned char, arg->vector1 );
    LOAD_REGISTER( tampon3, i, 2, unsigned char, arg->vector1 );
    LOAD_REGISTER( tampon4, i, 3, unsigned char, arg->vector1 );
    
    RESULTAT( arg->result, i, 0, unsigned char ) = vec_sl( tampon1, value );
    RESULTAT( arg->result, i, 1, unsigned char ) = vec_sl( tampon2, value );
    RESULTAT( arg->result, i, 2, unsigned char ) = vec_sl( tampon3, value );
    RESULTAT( arg->result, i, 3, unsigned char ) = vec_sl( tampon4, value );
  }
}

void  AVshiftlefts8  ( CAMLG4_ARGUMENTS* arg )
{
  long  nb_iter, i;
  register vector signed char  tampon1 , tampon2 , tampon3 , tampon4;
  register vector unsigned char  value;
  unsigned char val;

  EVAL_VECTOR_SIZE( signed char );

  val = *( (int*)(arg->vector2) );
  value = generic_splat_u8( &val );

  for( i = 0; i < nb_iter; ++i )
  {      
    LOAD_REGISTER( tampon1, i, 0, signed char, arg->vector1 );
    LOAD_REGISTER( tampon2, i, 1, signed char, arg->vector1 );
    LOAD_REGISTER( tampon3, i, 2, signed char, arg->vector1 );
    LOAD_REGISTER( tampon4, i, 3, signed char, arg->vector1 );
    
    RESULTAT( arg->result, i, 0, signed char ) = vec_sl( tampon1, value );
    RESULTAT( arg->result, i, 1, signed char ) = vec_sl( tampon2, value );
    RESULTAT( arg->result, i, 2, signed char ) = vec_sl( tampon3, value );
    RESULTAT( arg->result, i, 3, signed char ) = vec_sl( tampon4, value );
  }
}

void  AVshiftleftu16  ( CAMLG4_ARGUMENTS* arg )
{
  long  nb_iter, i;
  register vector unsigned short  tampon1 , tampon2 , tampon3 , tampon4;
  register vector unsigned short  value;
  unsigned short val;

  EVAL_VECTOR_SIZE( unsigned short );

  val = *( (int*)(arg->vector2) );
  value = generic_splat_u16( &val );

  for( i = 0; i < nb_iter; ++i )
  {      
    LOAD_REGISTER( tampon1, i, 0, unsigned short, arg->vector1 );
    LOAD_REGISTER( tampon2, i, 1, unsigned short, arg->vector1 );
    LOAD_REGISTER( tampon3, i, 2, unsigned short, arg->vector1 );
    LOAD_REGISTER( tampon4, i, 3, unsigned short, arg->vector1 );
    
    RESULTAT( arg->result, i, 0, unsigned short ) = vec_sl( tampon1, value );
    RESULTAT( arg->result, i, 1, unsigned short ) = vec_sl( tampon2, value );
    RESULTAT( arg->result, i, 2, unsigned short ) = vec_sl( tampon3, value );
    RESULTAT( arg->result, i, 3, unsigned short ) = vec_sl( tampon4, value );
  }
}

void  AVshiftlefts16  ( CAMLG4_ARGUMENTS* arg )
{
  long  nb_iter, i;
  register vector signed short  tampon1 , tampon2 , tampon3 , tampon4;
  register vector unsigned short  value;
  unsigned short val;

  EVAL_VECTOR_SIZE( signed short );

  val = *( (int*)(arg->vector2) );
  value = generic_splat_u16( &val );

  for( i = 0; i < nb_iter; ++i )
  {      
    LOAD_REGISTER( tampon1, i, 0, signed short, arg->vector1 );
    LOAD_REGISTER( tampon2, i, 1, signed short, arg->vector1 );
    LOAD_REGISTER( tampon3, i, 2, signed short, arg->vector1 );
    LOAD_REGISTER( tampon4, i, 3, signed short, arg->vector1 );
    
    RESULTAT( arg->result, i, 0, signed short ) = vec_sl( tampon1, value );
    RESULTAT( arg->result, i, 1, signed short ) = vec_sl( tampon2, value );
    RESULTAT( arg->result, i, 2, signed short ) = vec_sl( tampon3, value );
    RESULTAT( arg->result, i, 3, signed short ) = vec_sl( tampon4, value );
  }
}

void  AVshiftlefts32  ( CAMLG4_ARGUMENTS* arg )
{
  long  nb_iter, i;
  register vector signed long  tampon1 , tampon2 , tampon3 , tampon4;
  register vector unsigned long  value;
  unsigned long val;

  EVAL_VECTOR_SIZE( signed long );

  val = *( (int*)(arg->vector2) );
  value = generic_splat_u32( &val );

  for( i = 0; i < nb_iter; ++i )
  {      
    LOAD_REGISTER( tampon1, i, 0, signed long, arg->vector1 );
    LOAD_REGISTER( tampon2, i, 1, signed long, arg->vector1 );
    LOAD_REGISTER( tampon3, i, 2, signed long, arg->vector1 );
    LOAD_REGISTER( tampon4, i, 3, signed long, arg->vector1 );
    
    RESULTAT( arg->result, i, 0, signed long ) = vec_sl( tampon1, value );
    RESULTAT( arg->result, i, 1, signed long ) = vec_sl( tampon2, value );
    RESULTAT( arg->result, i, 2, signed long ) = vec_sl( tampon3, value );
    RESULTAT( arg->result, i, 3, signed long ) = vec_sl( tampon4, value );
  }
}
