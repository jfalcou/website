#include "altivec_common.h"

// one scalar variable  -> same type vector 

vector unsigned char generic_splat_u8(unsigned char* k) 
{

  register vector unsigned char ref,mask;

  ref = vec_lde(0,k);
  mask = vec_splat(vec_lvsl(0,k),0);
  return vec_perm(ref,ref,mask);// |k|k|k|k|k|k|k|k|k|k|k|k|k|k|k|k|

}

vector signed char generic_splat_s8(signed char* k) 
{

  register vector unsigned char mask;
  register vector signed char ref;

  ref = vec_lde(0,k);
  mask = vec_splat(vec_lvsl(0,k),0);
  return vec_perm(ref,ref,mask);

}

vector unsigned short generic_splat_u16(unsigned short* k) 
{
  register vector unsigned char  mask;
  register vector unsigned short source;

  source = vec_lde(0,k);
  (vector unsigned short)mask =  vec_splat((vector unsigned short)vec_lvsl(0,k),0);

  return vec_perm(source,source,mask);

}

vector signed short generic_splat_s16(signed short* k) 
{
  register vector unsigned char mask;
  register vector signed short source;

  source = vec_lde(0,k);
  (vector signed short) mask = vec_splat((vector signed short)vec_lvsl(0,k),0);

  return vec_perm(source,source,mask);

}

vector unsigned int generic_splat_u32(unsigned long* k) 
{
  register vector unsigned int source;
  register vector unsigned char mask;

  source = vec_lde(0,k); 
  (vector unsigned long) mask = vec_splat((vector unsigned long)vec_lvsl(0,k),0);

  return vec_perm(source,source,mask);   // |k|k|k|k|              

}

vector signed int generic_splat_s32(signed long* k) 
{
  register vector signed int source;
  register vector unsigned char mask;

  source = vec_lde(0,k); 
  (vector signed long) mask = vec_splat((vector signed long)vec_lvsl(0,k),0);
  return vec_perm(source,source,mask);   // |k|k|k|k|   

 

}

vector float generic_splat_f32(float* k) 
{
  register vector float source;
  register vector unsigned char mask;

  source = vec_lde(0,k); 
  (vector float) mask = vec_splat((vector float)vec_lvsl(0,k),0);
  return vec_perm(source,source,mask);   // |k|k|k|k|   

}
