/*========================================================*/
/**
 * @file   add.h
 * @author Joel FALCOU
 * @date   Tue May 14 13:33:30 2002
 * 
 * @brief  En-tete de add.c
 * 
 * Ce fichier definit les fonctions d'addition
 * vectorielle implementees dans add.c
 */
/*========================================================*/

#ifndef __ADD_H__INCLUDED__
#define __ADD_H__INCLUDED__

void  AVaddu8  ( CAMLG4_ARGUMENTS* arg );
void  AVadds8  ( CAMLG4_ARGUMENTS* arg );
void  AVaddu16 ( CAMLG4_ARGUMENTS* arg );
void  AVadds16 ( CAMLG4_ARGUMENTS* arg );
void  AVadds32 ( CAMLG4_ARGUMENTS* arg );
void  AVaddf32 ( CAMLG4_ARGUMENTS* arg );

#endif
