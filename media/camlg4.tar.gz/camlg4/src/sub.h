/*========================================================*/
/**
 * @file   sub.h
 * @author Joel FALCOU
 * @date   Tue May 14 13:33:30 2002
 * 
 * @brief  En-tete de sub.c
 * 
 * Ce fichier definit les fonctions de soustraction
 * vectorielle implementees dans sub.c
 *
 */
/*========================================================*/

#ifndef __SUB_H__INCLUDED__
#define __SUB_H__INCLUDED__

void  AVsubu8  ( CAMLG4_ARGUMENTS* arg );
void  AVsubs8  ( CAMLG4_ARGUMENTS* arg );
void  AVsubu16 ( CAMLG4_ARGUMENTS* arg );
void  AVsubs16 ( CAMLG4_ARGUMENTS* arg );
void  AVsubs32 ( CAMLG4_ARGUMENTS* arg );
void  AVsubf32 ( CAMLG4_ARGUMENTS* arg );

#endif
