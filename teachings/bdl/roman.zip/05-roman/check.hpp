#ifndef CHECK_HPP
#define CHECK_HPP

#include <cassert>
#include <cstddef>
#include <string>
#include <vector>

static std::size_t tests = 21;
static std::size_t success = 0;

void display_results() {
  std::cout << success << "/" << tests << " tests passes avec success\n";
}

void report_error(std::string msg) {
  std::cout << "[[ERREUR]] - " << msg << "\n";
}

void test_q1() {
  if (simple_numerals_to_roman(1) == "I")
    success++;
  else
    report_error("erreur Q1-1");
  if (simple_numerals_to_roman(2) == "II")
    success++;
  else
    report_error("erreur Q1-2");
  if (simple_numerals_to_roman(3) == "III")
    success++;
  else
    report_error("erreur Q1-3");

  if (simple_numerals_to_roman(10) == "X")
    success++;
  else
    report_error("erreur Q2-1");
  if (simple_numerals_to_roman(20) == "XX")
    success++;
  else
    report_error("erreur Q2-2");
  if (simple_numerals_to_roman(30) == "XXX")
    success++;
  else
    report_error("erreur Q2-3");

  if (simple_numerals_to_roman(12) == "XII")
    success++;
  else
    report_error("erreur Q3-1");
  if (simple_numerals_to_roman(23) == "XXIII")
    success++;
  else
    report_error("erreur Q3-2");
  if (simple_numerals_to_roman(31) == "XXXI")
    success++;
  else
    report_error("erreur Q3-3");

  if (simple_numerals_to_roman(5) == "V")
    success++;
  else
    report_error("erreur Q4-1");
  if (simple_numerals_to_roman(50) == "L")
    success++;
  else
    report_error("erreur Q4-2");
  if (simple_numerals_to_roman(100) == "C")
    success++;
  else
    report_error("erreur Q4-3");
  if (simple_numerals_to_roman(200) == "CC")
    success++;
  else
    report_error("erreur Q4-4");
  if (simple_numerals_to_roman(300) == "CCC")
    success++;
  else
    report_error("erreur Q4-5");
  if (simple_numerals_to_roman(1000) == "M")
    success++;
  else
    report_error("erreur Q4-6");
  if (simple_numerals_to_roman(2000) == "MM")
    success++;
  else
    report_error("erreur Q4-7");
  if (simple_numerals_to_roman(3000) == "MMM")
    success++;
  else
    report_error("erreur Q4-8");

  if (simple_numerals_to_roman(4) == "IV")
    success++;
  else
    report_error("erreur Q5-1");
  if (simple_numerals_to_roman(9) == "IX")
    success++;
  else
    report_error("erreur Q5-2");
  if (simple_numerals_to_roman(40) == "XL")
    success++;
  else
    report_error("erreur Q5-3");
  if (simple_numerals_to_roman(90) == "XC")
    success++;
  else
    report_error("erreur Q5-3");
}

void test_q6() {
  /*
    Reprenez les tests de q5 pour vérifier votre fonction
    struct_numerals_to_roman
  */
}

void test_automatic() {
  /*
    Désignez un système permettant de tester automatiquement
    une série de valeurs converties par notre fonction to_roman.

    Le système doit être extensible de l'extérieur de cette fonction
    et le plus simple possible.
  */
}

void run_tests() {
  test_q1();
  test_q6();
  test_automatic();
  display_results();
}

#endif
