#pragma once

#include "types.hpp"

#include <variant>

// Declare arithmetic operators for number_t here

fraction_t operator+(fraction_t const &, fraction_t const &);
fraction_t operator-(fraction_t const &, fraction_t const &);
fraction_t operator*(fraction_t const &, fraction_t const &);
fraction_t operator/(fraction_t const &, fraction_t const &);

fraction_t operator+(fraction_t const &, double const &);
fraction_t operator-(fraction_t const &, double const &);
fraction_t operator*(fraction_t const &, double const &);
fraction_t operator/(fraction_t const &, double const &);

fraction_t operator+(double const &, fraction_t const &);
fraction_t operator-(double const &, fraction_t const &);
fraction_t operator*(double const &, fraction_t const &);
fraction_t operator/(double const &, fraction_t const &);

std::complex<double> operator+(fraction_t const &,
                               std::complex<double> const &);
std::complex<double> operator-(fraction_t const &,
                               std::complex<double> const &);
std::complex<double> operator*(fraction_t const &,
                               std::complex<double> const &);
std::complex<double> operator/(fraction_t const &,
                               std::complex<double> const &);

std::complex<double> operator+(std::complex<double> const &,
                               fraction_t const &);
std::complex<double> operator-(std::complex<double> const &,
                               fraction_t const &);
std::complex<double> operator*(std::complex<double> const &,
                               fraction_t const &);
std::complex<double> operator/(std::complex<double> const &,
                               fraction_t const &);

/*...Compléter ici ...*/