/* Entiers arbitraires */
#include <cassert>
#include <cstdint>
#include <iostream>
#include <sstream>
#include <stdexcept>
#include <string>
#include <vector>

// REMINDER: do not change the function signatures

// step 1

enum class digit {
  // please write your answer here
};

digit to_digit(int i) {
  // please write your answer here
  return {};
}
int to_int(digit d) {
  // please write your answer here
  return 0;
}

void test_digit() {
  // please write your answer here
}

// step 2

std::vector<digit> decompose(std::uint64_t n) {
  // please write your answer here
  return {};
}

void test_decompose() {
  // please write your answer here
}

// step 3

struct number {
  // please write your answer here
  // REMINDER: start by the unit number
};

number as_number(std::int64_t n) {
  // please write your answer here
  return {};
}

number as_number(std::string const &s) {
  // please write your answer here
  return {};
}

void test_as_number() {
  // please write your answer here
}

// step 4

std::ostream &operator<<(std::ostream &os, number const &n) {
  // please write your answer here
  return os;
}

void test_stream() {
  // please write your answer here
}

// step 5

number operator+(number const &a, number const &b) {
  // please write your answer here
  return {};
}

void test_add() {
  // please write your answer here
}

// step 6

number abs(number const &n) {
  // please write your answer here
  return {};
}
bool is_even(number const &n) {
  // please write your answer here
  return {};
}
bool is_divisible_by_3(number const &n) {
  // please write your answer here
  return {};
}
bool is_divisible_by_5(number const &n) {
  // please write your answer here
  return {};
}
bool is_divisible_by_10(number const &n) {
  // please write your answer here
  return {};
}
int magnitude(number const &n) {
  // please write your answer here
  return {};
}

void test_tests() {
  // please write your answer here
}

int main() {
  test_digit();
  test_decompose();
  test_as_number();
  test_stream();
  test_add();
  test_tests();

  return 0;
}
