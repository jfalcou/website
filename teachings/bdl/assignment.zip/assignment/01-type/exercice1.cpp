/*
  Exercise 1 - Basic types

  The following program calculates the average of 10 numeric values.
  The result is then printed to the console.

  Q1 - Is the printed result correct?

  Q2 - What is the source of the error?

  Q3 - Fix the code so that it prints the correct average.
*/

#include <iostream>

int main(int, char **) {
  int average = 0;

  average = average + 3;
  average = average + 5;
  average = average + 1;
  average = average + 9;
  average = average + 4;
  average = average + 2;
  average = average + 8;
  average = average + 17;
  average = average + 9;
  average = average + 11;

  average = average / 10;

  std::cout << "Average is: " << average << "\n";

  return 0;
}
