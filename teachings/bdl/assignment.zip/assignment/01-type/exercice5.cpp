#include <array>
#include <iostream>
#include <vector>

/**
Exercise 5 - Control structures and vectors

  For each function, use the appropriate container interfaces and control
  structures to solve the stated problem.

  Remember to test potential corner cases.
**/

std::array<int, 4> revert(std::array<int, 4> const &arr) {
  // Return an array containing the values of `arr` in reverse order
}

/* ??? */ find_all(std::array<int, 4> const &arr, int value) {
  // Return a container containing all indices where `arr` has the given value
}

/* ??? */ uniques(std::array<int, 4> const &arr) {
  // Return a container with the unique values contained in `arr`.
  // Example (for a larger collection):
  //  arr = [ 1 2 5 4 4 1 2 3 6 2 1 5 8 ]
  // returns
  //  [ 1 2 5 4 3 6 8 ]
}

/* ??? */ unique_sum(std::array<int, 4> const &arr) {
  // Return the sum of the unique values contained in `arr`
}

int main() {
  std::array<int, 4> arr = {1, 2, 2, 3};
  // you can pass this array as a function argument like this:
  revert(arr);
  return 0;
}
