// /////////////////////////////////////////////////////////////////////////////
// player.cpp
// Sample use of the C+Fox Library
// 
// Created by Joel Falcou on 03/10/05.
// Copyright 2005 LASMEA. All rights reserved.
// /////////////////////////////////////////////////////////////////////////////

#include <iostream>
#include <sstream>
#include <cfox/cfox.h>

using namespace std;
using namespace cfox;

int main( int argc ,char** argv)
{
  size_t nbFrame;
  
  // Retrieve number of frame to acquire from command line
  if(argc != 2) { nbFrame = 500;                              }
  else          { istringstream str(argv[1]); str >> nbFrame; }

  // Setup main camera instance
  Camera        myCam(Mode_640x480_Mono8,FPS_30,0,BasicCamera);
  Camera::Frame img;
  myCam.start();

  for(int i =0;i < nbFrame;i++ )
  {
    CFRunLoopRunInMode(kCFRunLoopDefaultMode,1, true);
    myCam >> img;
    cout << "extracted image #" << i << " - Pixel@(0,0) = " << size_t(img[0]) << endl;
  }
}

