/*========================================================*/
/**
 * @file   round.h
 * @author Joel FALCOU
 * @date   Tue May 14 13:33:30 2002
 * 
 * @brief  En-tete de round.c
 * 
 * Ce fichier definit les fonctions d'arrondis
 * vectoriels implementees dans round.c
 */
/*========================================================*/

#ifndef __ROUND_H__INCLUDED__
#define __ROUND_H__INCLUDED__

void  AVroundf32 ( CAMLG4_ARGUMENTS* arg );
void  AVtruncf32 ( CAMLG4_ARGUMENTS* arg );
void  AVceilf32  ( CAMLG4_ARGUMENTS* arg );
void  AVfloorf32 ( CAMLG4_ARGUMENTS* arg );

#endif
