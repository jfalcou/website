/*
  Exercise 2 - Tic-tac-toe

  We will implement a simple tic-tac-toe game. Tic-tac-toe is a two-player game
  where players alternate placing a cross (X) or a circle (O) on a 3x3 grid.
  A player wins if they align 3 identical symbols in a row, column or diagonal.

  Q1 - Define a 'grid' type using std::array to represent the game board.

  Q2 - Create a boolean variable 'finished' initialized to false. Use it in a
  while loop where the loop ends when this variable is true. Verify the
  program does not stop immediately.

  Q3 - Create a variable 'symbol' of type char. Initialize it to 'X'. Make it
  alternate between 'X' and 'O' on each iteration of the while loop.

  Q4 - Update the loop to prompt the current symbol to enter its position.
  Read a pair of integers (between 0 and 2) representing the coordinates (x,y)
  in the grid where the current symbol should be placed.

  Q5 - Create a variable of type 'grid' at the appropriate place, update it
  after each move and print it on every iteration.

  Q6 - Implement a series of tests that check after each move if the current
  player has won. If so, announce the victory and set 'finished' to true to
  stop the game.

  BONUS - Add tests to handle input errors: coordinates out of range, cell
  already taken, etc.
*/

#include <array>
#include <iostream>

int main(int, char **) { return 0; }
