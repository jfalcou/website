#pragma once

#include "types.hpp"

#include <string>

number_t number_factory(std::string const &kind, std::string const &text);
