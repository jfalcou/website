#include <fstream>
#include <iostream>
#include <iterator>
#include <map>
#include <sstream>
#include <string>
#include <vector>

std::vector<std::string> load() {
  // A FAIRE
}

typedef std::map<std::string, int> occs;

occs count(std::vector<std::string> const &words) {
  // A FAIRE
}

typedef std::map<std::string, std::string> codes;

std::pair<std::string, std::string>
prefix(std::pair<std::string, std::string> const &root,
       std::string const &pref) {
  // A FAIRE
}

codes merge(codes const &x, codes const &y) {
  // A FAIRE
}

typedef std::multimap<int, codes> partial_codes;

auto extract(partial_codes &pc) {
  // A FAIRE
}

void reduce(partial_codes &res) {
  // A FAIRE
}

codes create(occs const &occ) {
  // A FAIRE
}

std::string compress(std::vector<std::string> const &words, codes &c) {
  // A FAIRE
}

codes shorten(codes const &c) {
  // A FAIRE
}

// A NE PAS DEPLACER
#include "check_1984.hpp"

int main() {
  // FAITES VOS TESTS PERSOS ICI

  // A NE PAS EFFACER
  run_tests();

  return 0;
}
