#pragma once

#include <complex>
#include <variant>

// Represents the fraction n/d
struct fraction_t {
  int n;
  int d;

  // Explicit conversion operator to double
  inline explicit operator double() const { return static_cast<double(n) / d; }
};

// Polymorphic type to represent a number.

using number_t = /*...Compléter ici ...*/;
