/*========================================================*/
/**
 * @file   svrl.c
 * @author Joel FALCOU
 * @date   Tue July 14 13:23:13 2002
 * 
 * @brief  Source de svrl.h
 * 
 * Ce fichier contient le code des differentes versions
 * de l'op�ration de d�calage �l�ments par �l�ments vectorielle.
 *
 */
/*========================================================*/

#include <stdio.h>
#include <stdlib.h>

#include "camlg4_internal.h"
#include "altivec_common.h"
#include "svrl.h"

void AVsvlu8( CAMLG4_ARGUMENTS* arg )
{
  register vector unsigned char tampon1 , tampon2 , tampon3 , tampon4;
  register vector unsigned char tampons1, tampons2, tampons3, tampons4;
  register vector unsigned char adjust, decal, external;
  long s, k, i, p,q;
  long limit, nb_iter;
  unsigned char r,d;

  s = (*(int*)(arg->vector2));
  k = s / vec_step( vector unsigned char );
  r = s % vec_step( vector unsigned char );

  EVAL_VECTOR_SIZE( unsigned char );
  limit = 4*nb_iter;

  /* Decalage grossier */

  for( p = k; p < limit; p++ )
  {
    LOAD_REGISTER( tampon1, 0, p, unsigned char, arg->vector1 );
    RESULTAT( arg->result, 0, (p-k), unsigned char ) = tampon1;
  }

  /* Decalage fin */

  d  = vec_step( vector signed char ) - r;
  r *= 8*sizeof( unsigned char ); 
  d *= 8*sizeof( unsigned char ); 
  
  adjust = generic_splat_u8( &d );
  decal  = generic_splat_u8( &r );
  
  for( i = 0; i < nb_iter; i ++ )
  {
    LOAD_REGISTER( tampons2, i, 1, unsigned char, arg->result );
    LOAD_REGISTER( tampons3, i, 2, unsigned char, arg->result );
    LOAD_REGISTER( tampons4, i, 3, unsigned char, arg->result );
    LOAD_REGISTER( tampons1, i, 4, unsigned char, arg->result );

    LOAD_REGISTER( tampon1, i, 0, unsigned char, arg->result );
    LOAD_REGISTER( tampon2, i, 1, unsigned char, arg->result );
    LOAD_REGISTER( tampon3, i, 2, unsigned char, arg->result );
    LOAD_REGISTER( tampon4, i, 3, unsigned char, arg->result );
    
    tampon1 = vec_slo( tampon1, decal );
    tampon2 = vec_slo( tampon2, decal );
    tampon3 = vec_slo( tampon3, decal );
    tampon4 = vec_slo( tampon4, decal );
    
    tampons2 = vec_sro( tampons2, adjust );
    tampons3 = vec_sro( tampons3, adjust );
    tampons4 = vec_sro( tampons4, adjust );
    external = vec_sro( tampons1, adjust );

    RESULTAT( arg->result, i, 0, unsigned char ) = vec_add( tampon1, tampons2 );
    RESULTAT( arg->result, i, 1, unsigned char ) = vec_add( tampon2, tampons3 );
    RESULTAT( arg->result, i, 2, unsigned char ) = vec_add( tampon3, tampons4 );
    RESULTAT( arg->result, i, 3, unsigned char ) = vec_add( tampon4, external );
  }
}

void AVsvls8( CAMLG4_ARGUMENTS* arg )
{
  register vector signed char tampon1 , tampon2 , tampon3 , tampon4;
  register vector signed char tampons1, tampons2, tampons3, tampons4;
  register vector signed char adjust, decal, external;
  long s, k, i, p,q;
  long limit, nb_iter;
  signed char r,d;

  s = (*(int*)(arg->vector2));
  k = s / vec_step( vector signed char );
  r = s % vec_step( vector signed char );

  EVAL_VECTOR_SIZE( signed char );
  limit = 4*nb_iter;

  /* Decalage grossier */

  for( p = k; p < limit; p++ )
  {
    LOAD_REGISTER( tampon1, 0, p, signed char, arg->vector1 );
    RESULTAT( arg->result, 0, (p-k), signed char ) = tampon1;
  }

  /* Decalage fin */

  d  = vec_step( vector signed char ) - r;
  r *= 8*sizeof( signed char ); 
  d *= 8*sizeof( signed char ); 
  
  adjust = generic_splat_s8( &d );
  decal  = generic_splat_s8( &r );
  
  for( i = 0; i < nb_iter; i ++ )
  {
    LOAD_REGISTER( tampons2, i, 1, signed char, arg->result );
    LOAD_REGISTER( tampons3, i, 2, signed char, arg->result );
    LOAD_REGISTER( tampons4, i, 3, signed char, arg->result );
    LOAD_REGISTER( tampons1, i, 4, signed char, arg->result );

    LOAD_REGISTER( tampon1, i, 0, signed char, arg->result );
    LOAD_REGISTER( tampon2, i, 1, signed char, arg->result );
    LOAD_REGISTER( tampon3, i, 2, signed char, arg->result );
    LOAD_REGISTER( tampon4, i, 3, signed char, arg->result );
    
    tampon1 = vec_slo( tampon1, decal );
    tampon2 = vec_slo( tampon2, decal );
    tampon3 = vec_slo( tampon3, decal );
    tampon4 = vec_slo( tampon4, decal );
    
    tampons2 = vec_sro( tampons2, adjust );
    tampons3 = vec_sro( tampons3, adjust );
    tampons4 = vec_sro( tampons4, adjust );
    external = vec_sro( tampons1, adjust );

    RESULTAT( arg->result, i, 0, signed char ) = vec_add( tampon1, tampons2 );
    RESULTAT( arg->result, i, 1, signed char ) = vec_add( tampon2, tampons3 );
    RESULTAT( arg->result, i, 2, signed char ) = vec_add( tampon3, tampons4 );
    RESULTAT( arg->result, i, 3, signed char ) = vec_add( tampon4, external );
  }
}

void AVsvlu16( CAMLG4_ARGUMENTS* arg )
{  
  register vector unsigned short tampon1 , tampon2 , tampon3 , tampon4;
  register vector unsigned short tampons1, tampons2, tampons3, tampons4, external;
  register vector unsigned char  adjust, decal;
  long s, k, i, p,q;
  long limit, nb_iter;
  unsigned char r,d;

  s = (*(int*)(arg->vector2));
  k = s / vec_step( vector unsigned short );
  r = s % vec_step( vector unsigned short );

  EVAL_VECTOR_SIZE( unsigned short );
  limit = 4*nb_iter;

  /* Decalage grossier */

  for( p = k; p < limit; p++ )
  {
    LOAD_REGISTER( tampon1, 0, p, unsigned short, arg->vector1 );
    RESULTAT( arg->result, 0, (p-k), unsigned short ) = tampon1;
  }
  /* Decalage fin */

  d  = vec_step( vector signed short ) - r;
  r *= 8*sizeof( unsigned short ); 
  d *= 8*sizeof( unsigned short ); 
  
  adjust = generic_splat_u8( &d );
  decal  = generic_splat_u8( &r );
  
  for( i = 0; i < nb_iter; i ++ )
  {
    LOAD_REGISTER( tampons2, i, 1, unsigned short, arg->result );
    LOAD_REGISTER( tampons3, i, 2, unsigned short, arg->result );
    LOAD_REGISTER( tampons4, i, 3, unsigned short, arg->result );
    LOAD_REGISTER( tampons1, i, 4, unsigned short, arg->result );

    LOAD_REGISTER( tampon1, i, 0, unsigned short, arg->result );
    LOAD_REGISTER( tampon2, i, 1, unsigned short, arg->result );
    LOAD_REGISTER( tampon3, i, 2, unsigned short, arg->result );
    LOAD_REGISTER( tampon4, i, 3, unsigned short, arg->result );
    
    tampon1 = vec_slo( tampon1, decal );
    tampon2 = vec_slo( tampon2, decal );
    tampon3 = vec_slo( tampon3, decal );
    tampon4 = vec_slo( tampon4, decal );
    
    tampons2 = vec_sro( tampons2, adjust );
    tampons3 = vec_sro( tampons3, adjust );
    tampons4 = vec_sro( tampons4, adjust );
    external = vec_sro( tampons1, adjust );

    RESULTAT( arg->result, i, 0, unsigned short ) = vec_add( tampon1, tampons2 );
    RESULTAT( arg->result, i, 1, unsigned short ) = vec_add( tampon2, tampons3 );
    RESULTAT( arg->result, i, 2, unsigned short ) = vec_add( tampon3, tampons4 );
    RESULTAT( arg->result, i, 3, unsigned short ) = vec_add( tampon4, external );
  }
}

void AVsvls16( CAMLG4_ARGUMENTS* arg )
{
  register vector signed short tampon1 , tampon2 , tampon3 , tampon4;
  register vector signed short tampons1, tampons2, tampons3, tampons4, external;
  register vector unsigned char  adjust, decal;
  long s, k, i, p,q;
  long limit, nb_iter;
  unsigned char r,d;

  s = (*(int*)(arg->vector2));
  k = s / vec_step( vector signed short );
  r = s % vec_step( vector signed short );

  EVAL_VECTOR_SIZE( signed short );
  limit = 4*nb_iter;

  /* Decalage grossier */

  for( p = k; p < limit; p++ )
  {
    LOAD_REGISTER( tampon1, 0, p, signed short, arg->vector1 );
    RESULTAT( arg->result, 0, (p-k), signed short ) = tampon1;
  }

  /* Decalage fin */

  d  = vec_step( vector signed short ) - r;
  r *= 8*sizeof( signed short ); 
  d *= 8*sizeof( signed short ); 
  
  adjust = generic_splat_u8( &d );
  decal  = generic_splat_u8( &r );
  
  for( i = 0; i < nb_iter; i ++ )
  {
    LOAD_REGISTER( tampons2, i, 1, signed short, arg->result );
    LOAD_REGISTER( tampons3, i, 2, signed short, arg->result );
    LOAD_REGISTER( tampons4, i, 3, signed short, arg->result );
    LOAD_REGISTER( tampons1, i, 4, signed short, arg->result );

    LOAD_REGISTER( tampon1, i, 0, signed short, arg->result );
    LOAD_REGISTER( tampon2, i, 1, signed short, arg->result );
    LOAD_REGISTER( tampon3, i, 2, signed short, arg->result );
    LOAD_REGISTER( tampon4, i, 3, signed short, arg->result );
    
    tampon1 = vec_slo( tampon1, decal );
    tampon2 = vec_slo( tampon2, decal );
    tampon3 = vec_slo( tampon3, decal );
    tampon4 = vec_slo( tampon4, decal );
    
    tampons2 = vec_sro( tampons2, adjust );
    tampons3 = vec_sro( tampons3, adjust );
    tampons4 = vec_sro( tampons4, adjust );
    external = vec_sro( tampons1, adjust );

    RESULTAT( arg->result, i, 0, signed short ) = vec_add( tampon1, tampons2 );
    RESULTAT( arg->result, i, 1, signed short ) = vec_add( tampon2, tampons3 );
    RESULTAT( arg->result, i, 2, signed short ) = vec_add( tampon3, tampons4 );
    RESULTAT( arg->result, i, 3, signed short ) = vec_add( tampon4, external );
  }
}

void AVsvls32( CAMLG4_ARGUMENTS* arg )
{
  register vector signed long tampon1 , tampon2 , tampon3 , tampon4;
  register vector signed long tampons1, tampons2, tampons3, tampons4, external;
  register vector unsigned char  adjust, decal;
  long s, k, i, p,q;
  long limit, nb_iter;
  unsigned char r,d;

  s = (*(int*)(arg->vector2));
  k = s / vec_step( vector signed long );
  r = s % vec_step( vector signed long );

  EVAL_VECTOR_SIZE( signed long );
  limit = 4*nb_iter;

  /* Decalage grossier */

  for( p = k; p < limit; p++ )
  {
    LOAD_REGISTER( tampon1, 0, p, signed long, arg->vector1 );
    RESULTAT( arg->result, 0, (p-k), signed long ) = tampon1;
  }

  /* Decalage fin */

  d  = vec_step( vector signed long ) - r;
  r *= 8*sizeof( signed long ); 
  d *= 8*sizeof( signed long ); 
  
  adjust = generic_splat_u8( &d );
  decal  = generic_splat_u8( &r );
  
  for( i = 0; i < nb_iter; i ++ )
  {
    LOAD_REGISTER( tampons2, i, 1, signed long, arg->result );
    LOAD_REGISTER( tampons3, i, 2, signed long, arg->result );
    LOAD_REGISTER( tampons4, i, 3, signed long, arg->result );
    LOAD_REGISTER( tampons1, i, 4, signed long, arg->result );

    LOAD_REGISTER( tampon1, i, 0, signed long, arg->result );
    LOAD_REGISTER( tampon2, i, 1, signed long, arg->result );
    LOAD_REGISTER( tampon3, i, 2, signed long, arg->result );
    LOAD_REGISTER( tampon4, i, 3, signed long, arg->result );
    
    tampon1 = vec_slo( tampon1, decal );
    tampon2 = vec_slo( tampon2, decal );
    tampon3 = vec_slo( tampon3, decal );
    tampon4 = vec_slo( tampon4, decal );
    
    tampons2 = vec_sro( tampons2, adjust );
    tampons3 = vec_sro( tampons3, adjust );
    tampons4 = vec_sro( tampons4, adjust );
    external = vec_sro( tampons1, adjust );

    RESULTAT( arg->result, i, 0, signed long ) = vec_add( tampon1, tampons2 );
    RESULTAT( arg->result, i, 1, signed long ) = vec_add( tampon2, tampons3 );
    RESULTAT( arg->result, i, 2, signed long ) = vec_add( tampon3, tampons4 );
    RESULTAT( arg->result, i, 3, signed long ) = vec_add( tampon4, external );
  }
}


void AVsvru8( CAMLG4_ARGUMENTS* arg )
{
  register vector unsigned char tampon1 , tampon2 , tampon3 , tampon4;
  register vector unsigned char tampons1, tampons2, tampons3, tampons4, external;
  register vector unsigned char  adjust, decal;
  long s, k, l,i, p,q;
  long limit, nb_iter;
  unsigned char r,d;

  s = (*(int*)(arg->vector2));
  k = s / vec_step( vector unsigned char );
  r = s % vec_step( vector unsigned char );

  EVAL_VECTOR_SIZE( unsigned char );
  limit = 4*nb_iter;
 
  /* Decalage grossier */

  for( p = 0; p < limit-k; p++ )
  {
    LOAD_REGISTER( tampon1, 0, p, unsigned char, arg->vector1 );
    RESULTAT( arg->result, 0, (p+k), unsigned char ) = tampon1; 
  }

  for( l=0; l < k; l++ )
  {
    RESULTAT( arg->result, 0, l, unsigned char ) = u8_zero; 
  }

  /* Decalage fin */

  d  = vec_step( vector unsigned char ) - r;
  r *= 8*sizeof( unsigned char ); 
  d *= 8*sizeof( unsigned char ); 
  
  adjust   = generic_splat_u8( &d );
  decal    = generic_splat_u8( &r );
  external = u8_zero;

  for( i = 0; i < nb_iter; i ++ )
  {
    LOAD_REGISTER( tampons1, i, 0, unsigned char, arg->result );
    LOAD_REGISTER( tampons2, i, 1, unsigned char, arg->result );
    LOAD_REGISTER( tampons3, i, 2, unsigned char, arg->result );
    LOAD_REGISTER( tampons4, i, 3, unsigned char, arg->result );

    LOAD_REGISTER( tampon1, i, 0, unsigned char, arg->result );
    LOAD_REGISTER( tampon2, i, 1, unsigned char, arg->result );
    LOAD_REGISTER( tampon3, i, 2, unsigned char, arg->result );
    LOAD_REGISTER( tampon4, i, 3, unsigned char, arg->result );
    
    tampon1 = vec_sro( tampon1, decal );
    tampon2 = vec_sro( tampon2, decal );
    tampon3 = vec_sro( tampon3, decal );
    tampon4 = vec_sro( tampon4, decal );
    
    tampons1 = vec_slo( tampons1, adjust );
    tampons2 = vec_slo( tampons2, adjust );
    tampons3 = vec_slo( tampons3, adjust );
    tampons4 = vec_slo( tampons4, adjust );

    RESULTAT( arg->result, i, 0, unsigned char ) = vec_add( tampon1, external );
    RESULTAT( arg->result, i, 1, unsigned char ) = vec_add( tampon2, tampons1 );
    RESULTAT( arg->result, i, 2, unsigned char ) = vec_add( tampon3, tampons2 );
    RESULTAT( arg->result, i, 3, unsigned char ) = vec_add( tampon4, tampons3 );

    external = tampons4;
  }
}

void AVsvrs8( CAMLG4_ARGUMENTS* arg )
{
  register vector signed char tampon1 , tampon2 , tampon3 , tampon4;
  register vector signed char tampons1, tampons2, tampons3, tampons4, external;
  register vector unsigned char  adjust, decal;
  long s, k, l,i, p,q;
  long limit, nb_iter;
  unsigned char r,d;

  s = (*(int*)(arg->vector2));
  k = s / vec_step( vector signed char );
  r = s % vec_step( vector signed char );

  EVAL_VECTOR_SIZE( signed char );
  limit = 4*nb_iter;
 
  /* Decalage grossier */

  for( p = 0; p < limit-k; p++ )
  {
    LOAD_REGISTER( tampon1, 0, p, signed char, arg->vector1 );
    RESULTAT( arg->result, 0, (p+k), signed char ) = tampon1; 
  }

  for( l=0; l < k; l++ )
  {
    RESULTAT( arg->result, 0, l, signed char ) = s8_zero; 
  }

  /* Decalage fin */

  d  = vec_step( vector signed char ) - r;
  r *= 8*sizeof( signed char ); 
  d *= 8*sizeof( signed char ); 
  
  adjust   = generic_splat_u8( &d );
  decal    = generic_splat_u8( &r );
  external = s8_zero;

  for( i = 0; i < nb_iter; i ++ )
  {
    LOAD_REGISTER( tampons1, i, 0, signed char, arg->result );
    LOAD_REGISTER( tampons2, i, 1, signed char, arg->result );
    LOAD_REGISTER( tampons3, i, 2, signed char, arg->result );
    LOAD_REGISTER( tampons4, i, 3, signed char, arg->result );

    LOAD_REGISTER( tampon1, i, 0, signed char, arg->result );
    LOAD_REGISTER( tampon2, i, 1, signed char, arg->result );
    LOAD_REGISTER( tampon3, i, 2, signed char, arg->result );
    LOAD_REGISTER( tampon4, i, 3, signed char, arg->result );
    
    tampon1 = vec_sro( tampon1, decal );
    tampon2 = vec_sro( tampon2, decal );
    tampon3 = vec_sro( tampon3, decal );
    tampon4 = vec_sro( tampon4, decal );
    
    tampons1 = vec_slo( tampons1, adjust );
    tampons2 = vec_slo( tampons2, adjust );
    tampons3 = vec_slo( tampons3, adjust );
    tampons4 = vec_slo( tampons4, adjust );

    RESULTAT( arg->result, i, 0, signed char ) = vec_add( tampon1, external );
    RESULTAT( arg->result, i, 1, signed char ) = vec_add( tampon2, tampons1 );
    RESULTAT( arg->result, i, 2, signed char ) = vec_add( tampon3, tampons2 );
    RESULTAT( arg->result, i, 3, signed char ) = vec_add( tampon4, tampons3 );

    external = tampons4;
  }
}

void AVsvru16( CAMLG4_ARGUMENTS* arg )
{
  register vector unsigned short tampon1 , tampon2 , tampon3 , tampon4;
  register vector unsigned short tampons1, tampons2, tampons3, tampons4, external;
  register vector unsigned char  adjust, decal;
  long s, k, l,i, p,q;
  long limit, nb_iter;
  unsigned char r,d;

  s = (*(int*)(arg->vector2));
  k = s / vec_step( vector unsigned short );
  r = s % vec_step( vector unsigned short );

  EVAL_VECTOR_SIZE( unsigned short );
  limit = 4*nb_iter;
 
  /* Decalage grossier */

  for( p = 0; p < limit-k; p++ )
  {
    LOAD_REGISTER( tampon1, 0, p, unsigned short, arg->vector1 );
    RESULTAT( arg->result, 0, (p+k), unsigned short ) = tampon1; 
  }

  for( l=0; l < k; l++ )
  {
    RESULTAT( arg->result, 0, l, unsigned short ) = u16_zero; 
  }

  /* Decalage fin */

  d  = vec_step( vector unsigned short ) - r;
  r *= 8*sizeof( unsigned short ); 
  d *= 8*sizeof( unsigned short ); 
  
  adjust   = generic_splat_u8( &d );
  decal    = generic_splat_u8( &r );
  external = u16_zero;

  for( i = 0; i < nb_iter; i ++ )
  {
    LOAD_REGISTER( tampons1, i, 0, unsigned short, arg->result );
    LOAD_REGISTER( tampons2, i, 1, unsigned short, arg->result );
    LOAD_REGISTER( tampons3, i, 2, unsigned short, arg->result );
    LOAD_REGISTER( tampons4, i, 3, unsigned short, arg->result );

    LOAD_REGISTER( tampon1, i, 0, unsigned short, arg->result );
    LOAD_REGISTER( tampon2, i, 1, unsigned short, arg->result );
    LOAD_REGISTER( tampon3, i, 2, unsigned short, arg->result );
    LOAD_REGISTER( tampon4, i, 3, unsigned short, arg->result );
    
    tampon1 = vec_sro( tampon1, decal );
    tampon2 = vec_sro( tampon2, decal );
    tampon3 = vec_sro( tampon3, decal );
    tampon4 = vec_sro( tampon4, decal );
    
    tampons1 = vec_slo( tampons1, adjust );
    tampons2 = vec_slo( tampons2, adjust );
    tampons3 = vec_slo( tampons3, adjust );
    tampons4 = vec_slo( tampons4, adjust );

    RESULTAT( arg->result, i, 0, unsigned short ) = vec_add( tampon1, external );
    RESULTAT( arg->result, i, 1, unsigned short ) = vec_add( tampon2, tampons1 );
    RESULTAT( arg->result, i, 2, unsigned short ) = vec_add( tampon3, tampons2 );
    RESULTAT( arg->result, i, 3, unsigned short ) = vec_add( tampon4, tampons3 );

    external = tampons4;
  }
}

void AVsvrs16( CAMLG4_ARGUMENTS* arg )
{
  register vector signed short tampon1 , tampon2 , tampon3 , tampon4;
  register vector signed short tampons1, tampons2, tampons3, tampons4, external;
  register vector unsigned char  adjust, decal;
  long s, k, l,i, p,q;
  long limit, nb_iter;
  unsigned char r,d;

  s = (*(int*)(arg->vector2));
  k = s / vec_step( vector signed short );
  r = s % vec_step( vector signed short );

  EVAL_VECTOR_SIZE( signed short );
  limit = 4*nb_iter;
 
  /* Decalage grossier */

  for( p = 0; p < limit-k; p++ )
  {
    LOAD_REGISTER( tampon1, 0, p, signed short, arg->vector1 );
    RESULTAT( arg->result, 0, (p+k), signed short ) = tampon1; 
  }

  for( l=0; l < k; l++ )
  {
    RESULTAT( arg->result, 0, l, signed short ) = s16_zero; 
  }

  /* Decalage fin */

  d  = vec_step( vector signed short ) - r;
  r *= 8*sizeof( signed short ); 
  d *= 8*sizeof( signed short ); 
  
  adjust   = generic_splat_u8( &d );
  decal    = generic_splat_u8( &r );
  external = s16_zero;

  for( i = 0; i < nb_iter; i ++ )
  {
    LOAD_REGISTER( tampons1, i, 0, signed short, arg->result );
    LOAD_REGISTER( tampons2, i, 1, signed short, arg->result );
    LOAD_REGISTER( tampons3, i, 2, signed short, arg->result );
    LOAD_REGISTER( tampons4, i, 3, signed short, arg->result );

    LOAD_REGISTER( tampon1, i, 0, signed short, arg->result );
    LOAD_REGISTER( tampon2, i, 1, signed short, arg->result );
    LOAD_REGISTER( tampon3, i, 2, signed short, arg->result );
    LOAD_REGISTER( tampon4, i, 3, signed short, arg->result );
    
    tampon1 = vec_sro( tampon1, decal );
    tampon2 = vec_sro( tampon2, decal );
    tampon3 = vec_sro( tampon3, decal );
    tampon4 = vec_sro( tampon4, decal );
    
    tampons1 = vec_slo( tampons1, adjust );
    tampons2 = vec_slo( tampons2, adjust );
    tampons3 = vec_slo( tampons3, adjust );
    tampons4 = vec_slo( tampons4, adjust );

    RESULTAT( arg->result, i, 0, signed short ) = vec_add( tampon1, external );
    RESULTAT( arg->result, i, 1, signed short ) = vec_add( tampon2, tampons1 );
    RESULTAT( arg->result, i, 2, signed short ) = vec_add( tampon3, tampons2 );
    RESULTAT( arg->result, i, 3, signed short ) = vec_add( tampon4, tampons3 );

    external = tampons4;
  }
}

void AVsvrs32( CAMLG4_ARGUMENTS* arg )
{
  register vector signed long tampon1 , tampon2 , tampon3 , tampon4;
  register vector signed long tampons1, tampons2, tampons3, tampons4, external;
  register vector unsigned char  adjust, decal;
  long s, k, l,i, p,q;
  long limit, nb_iter;
  unsigned char r,d;

  s = (*(int*)(arg->vector2));
  k = s / vec_step( vector signed long );
  r = s % vec_step( vector signed long );

  EVAL_VECTOR_SIZE( signed long );
  limit = 4*nb_iter;
 
  /* Decalage grossier */

  for( p = 0; p < limit-k; p++ )
  {
    LOAD_REGISTER( tampon1, 0, p, signed long, arg->vector1 );
    RESULTAT( arg->result, 0, (p+k), signed long ) = tampon1; 
  }

  for( l=0; l < k; l++ )
  {
    RESULTAT( arg->result, 0, l, signed long ) = s32_zero; 
  }

  /* Decalage fin */

  d  = vec_step( vector signed long ) - r;
  r *= 8*sizeof( signed long ); 
  d *= 8*sizeof( signed long ); 
  
  adjust   = generic_splat_u8( &d );
  decal    = generic_splat_u8( &r );
  external = s32_zero;

  for( i = 0; i < nb_iter; i ++ )
  {
    LOAD_REGISTER( tampons1, i, 0, signed long, arg->result );
    LOAD_REGISTER( tampons2, i, 1, signed long, arg->result );
    LOAD_REGISTER( tampons3, i, 2, signed long, arg->result );
    LOAD_REGISTER( tampons4, i, 3, signed long, arg->result );

    LOAD_REGISTER( tampon1, i, 0, signed long, arg->result );
    LOAD_REGISTER( tampon2, i, 1, signed long, arg->result );
    LOAD_REGISTER( tampon3, i, 2, signed long, arg->result );
    LOAD_REGISTER( tampon4, i, 3, signed long, arg->result );
    
    tampon1 = vec_sro( tampon1, decal );
    tampon2 = vec_sro( tampon2, decal );
    tampon3 = vec_sro( tampon3, decal );
    tampon4 = vec_sro( tampon4, decal );
    
    tampons1 = vec_slo( tampons1, adjust );
    tampons2 = vec_slo( tampons2, adjust );
    tampons3 = vec_slo( tampons3, adjust );
    tampons4 = vec_slo( tampons4, adjust );

    RESULTAT( arg->result, i, 0, signed long ) = vec_add( tampon1, external );
    RESULTAT( arg->result, i, 1, signed long ) = vec_add( tampon2, tampons1 );
    RESULTAT( arg->result, i, 2, signed long ) = vec_add( tampon3, tampons2 );
    RESULTAT( arg->result, i, 3, signed long ) = vec_add( tampon4, tampons3 );

    external = tampons4;
  }
}
